-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 07, 2018 at 10:29 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `developer`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_fname` varchar(25) DEFAULT NULL,
  `admin_lname` varchar(25) DEFAULT NULL,
  `admin_gender` char(1) DEFAULT NULL,
  `admin_address` varchar(50) DEFAULT NULL,
  `admin_contact` varchar(15) DEFAULT NULL,
  `admin_email` varchar(25) DEFAULT NULL,
  `admin_password` varchar(25) DEFAULT NULL,
  `admin_img` blob,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_fname`, `admin_lname`, `admin_gender`, `admin_address`, `admin_contact`, `admin_email`, `admin_password`, `admin_img`) VALUES
(1, 'Ransom', 'Carino', 'M', 'Talisay', NULL, NULL, NULL, NULL),
(2, 'Ransom', 'Carino', 'M', 'Talisay', '09234815395', 'ransom@yahoo.com', 'ransom', 0x2e2e2f426f6f7473747261702f696d672f31353431393738385f3335353337383136313532313432335f3931383833303738393436303331353138355f6f2e6a7067),
(3, 'Recca Jane', 'Valencia', 'F', 'Lahug Cebu City', '09123242222', 'recca@yahoo.com', 'recca', 0x2e2e2f426f6f7473747261702f696d672f3535393534365f3737373635393039323237333539335f323831353431353838383138323236313033305f6e2e6a7067),
(4, 'Rico', 'Valencio', 'M', 'Bulacao', '09234815395', 'rico@yahoo.com', 'rico', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE IF NOT EXISTS `announcement` (
  `an_id` int(11) NOT NULL AUTO_INCREMENT,
  `an_details` varchar(999) DEFAULT NULL,
  `an_time` datetime DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`an_id`),
  KEY `code` (`co_id`),
  KEY `admin` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `assessment`
--

CREATE TABLE IF NOT EXISTS `assessment` (
  `info_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `info_region` varchar(50) DEFAULT NULL,
  `info_province` varchar(50) DEFAULT NULL,
  `info_district` varchar(50) DEFAULT NULL,
  `info_city` varchar(50) DEFAULT NULL,
  `info_provider` varchar(50) DEFAULT NULL,
  `info_address` varchar(100) DEFAULT NULL,
  `info_typeofprovider` varchar(50) DEFAULT NULL,
  `info_classification_provider` varchar(50) DEFAULT NULL,
  `info_industry_sector` varchar(50) DEFAULT NULL,
  `info_prog_reg_stat` varchar(50) DEFAULT NULL,
  `info_prog_title` varchar(80) DEFAULT NULL,
  `info_ctpr` varchar(50) DEFAULT NULL,
  `info_training_calendar_mode` varchar(50) DEFAULT NULL,
  `info_delivery_mode` varchar(80) DEFAULT NULL,
  `info_voucher_no` varchar(25) DEFAULT NULL,
  `info_date_started` varchar(25) DEFAULT NULL,
  `info_date_finished` varchar(25) DEFAULT NULL,
  `info_date_assessed` varchar(25) DEFAULT NULL,
  `info_assessment_result` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`info_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `assessment`
--

INSERT INTO `assessment` (`info_id`, `user_id`, `info_region`, `info_province`, `info_district`, `info_city`, `info_provider`, `info_address`, `info_typeofprovider`, `info_classification_provider`, `info_industry_sector`, `info_prog_reg_stat`, `info_prog_title`, `info_ctpr`, `info_training_calendar_mode`, `info_delivery_mode`, `info_voucher_no`, `info_date_started`, `info_date_finished`, `info_date_assessed`, `info_assessment_result`) VALUES
(4, 1003, 'sdfdsf', 'dfdsf', 'kjlkjkjklj', 'kjlkjkjkl', 'kjlkjkjkjk', 'lklkjkjkljkl', 'lkjkjlkjlk', 'lkjkljkjlkjlk', 'jkjlkjlkjkl', 'kjkljlkjlkjkl', 'lkjkljkljlk', 'jkljlkjkj', 'kjlkjlkjkljk', 'ljlkjkljkljk', 'klkjlk', '2018-03-17', '2018-03-16', '2018-03-23', 'fdsfsdf');

-- --------------------------------------------------------

--
-- Table structure for table `course_offer`
--

CREATE TABLE IF NOT EXISTS `course_offer` (
  `co_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_code` int(11) NOT NULL,
  `co_name` varchar(25) DEFAULT NULL,
  `co_desc` varchar(100) DEFAULT NULL,
  `co_limit` int(11) DEFAULT NULL,
  `co_img` blob,
  PRIMARY KEY (`co_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `course_offer`
--

INSERT INTO `course_offer` (`co_id`, `co_code`, `co_name`, `co_desc`, `co_limit`, `co_img`) VALUES
(1, 1001, 'HouseKeeping NCII', 'HouseKeeping NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f686f7573652e6a7067),
(2, 1002, 'Cookery NCII', 'Cookery NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f636f6f6b2e6a7067),
(3, 1003, 'Food & Beverage Services ', 'Food & Beverage Services NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f6261722e6a7067),
(4, 1004, 'Bartending NCII', 'Bartending NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f6261722e6a7067),
(5, 1005, 'Welding (SMAW) NC I & II', 'Welding (SMAW) NC I & II', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f494d475f32303138303130385f3133323535355f427572737430312e6a7067),
(6, 1006, 'Computer System Servicing', 'Computer System Servicing NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f636f6d2e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

CREATE TABLE IF NOT EXISTS `enrollment` (
  `en_id` int(11) NOT NULL AUTO_INCREMENT,
  `en_fname` varchar(25) DEFAULT NULL,
  `en_lname` varchar(25) DEFAULT NULL,
  `en_mi` varchar(25) DEFAULT NULL,
  `en_num_street` varchar(50) DEFAULT NULL,
  `en_barangay` varchar(50) DEFAULT NULL,
  `en_district` varchar(25) DEFAULT NULL,
  `en_city` varchar(25) DEFAULT NULL,
  `en_province` varchar(50) DEFAULT NULL,
  `en_region` varchar(50) DEFAULT NULL,
  `en_email_add` varchar(50) DEFAULT NULL,
  `en_contact` varchar(15) DEFAULT NULL,
  `en_nationality` varchar(25) DEFAULT NULL,
  `en_gender` char(1) DEFAULT NULL,
  `en_civilstatus` varchar(15) DEFAULT NULL,
  `en_empstatus` varchar(15) DEFAULT NULL,
  `en_bdate` date DEFAULT NULL,
  `en_age` int(3) DEFAULT NULL,
  `en_birthplace` varchar(100) DEFAULT NULL,
  `en_father_fname` varchar(25) DEFAULT NULL,
  `en_father_lname` varchar(25) DEFAULT NULL,
  `en_mother_fname` varchar(25) DEFAULT NULL,
  `en_mother_lname` varchar(25) DEFAULT NULL,
  `en_edattainment` varchar(70) DEFAULT NULL,
  `en_lts` varchar(70) DEFAULT NULL,
  `en_taken_where` varchar(25) DEFAULT NULL,
  `en_taken_when` varchar(25) DEFAULT NULL,
  `en_stud_voucher_no` varchar(25) DEFAULT NULL,
  `en_scholar_package` varchar(70) DEFAULT NULL,
  `en_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ref_id` int(11) DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `en_status` int(1) DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `en_active` int(1) DEFAULT NULL,
  PRIMARY KEY (`en_id`),
  KEY `ref_id` (`ref_id`),
  KEY `co_id` (`co_id`),
  KEY `session` (`session_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=47 ;

--
-- Dumping data for table `enrollment`
--

INSERT INTO `enrollment` (`en_id`, `en_fname`, `en_lname`, `en_mi`, `en_num_street`, `en_barangay`, `en_district`, `en_city`, `en_province`, `en_region`, `en_email_add`, `en_contact`, `en_nationality`, `en_gender`, `en_civilstatus`, `en_empstatus`, `en_bdate`, `en_age`, `en_birthplace`, `en_father_fname`, `en_father_lname`, `en_mother_fname`, `en_mother_lname`, `en_edattainment`, `en_lts`, `en_taken_where`, `en_taken_when`, `en_stud_voucher_no`, `en_scholar_package`, `en_date`, `ref_id`, `co_id`, `en_status`, `session_id`, `en_active`) VALUES
(32, 'Ransom', 'Ransom', 'Padilla', '090', 'Biasong', 'II', 'Talisay', 'Cebu', 'VII', 'padillaransom@gmail.com', '09234815395', 'Pilipino', 'M', 'Single', 'Unemployed', '0055-05-05', 22, 'ZN Del Norte', 'Necomedes', 'Carino', 'Editha', 'Carino', 'College Undergraduate', 'Others', '', '', '123224232323232323', 'none', '2018-03-05 17:59:32', 12, 6, 1, 12, 1),
(46, 'Christopher', 'Barro', 'Alejaga', '090', 'Biasong', 'II', 'Talisay', 'Cebu', 'VII', 'barro@yahoo.com', '09234815395', 'Pilipino', 'M', 'Married', 'Employed', '2018-03-08', 22, 'Mohon Talisay City Cebu', 'Rodel', 'Barro', 'Marna', 'Barro', 'College Graduate or Higher', 'Others', '', '', '', '', '2018-03-07 16:56:54', NULL, 6, 0, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `sched_id` int(11) NOT NULL AUTO_INCREMENT,
  `sched_week_start` varchar(15) DEFAULT NULL,
  `sched_week_end` varchar(15) DEFAULT NULL,
  `sched_time_start` varchar(20) DEFAULT NULL,
  `sched_time_end` varchar(20) DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`sched_id`),
  KEY `session_schedule` (`session_id`),
  KEY `course_id` (`co_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
  `session_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `session_status` int(1) DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  KEY `co_id_session` (`co_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`session_id`, `co_id`, `start_date`, `end_date`, `session_status`) VALUES
(10, 2, '2018-03-01', '2018-09-06', 0),
(11, 2, '2018-03-08', '2018-12-13', 1),
(12, 6, '2018-03-09', '2018-07-12', 1),
(13, 4, '2018-03-02', '2018-03-22', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fname` varchar(25) DEFAULT NULL,
  `user_lname` varchar(25) DEFAULT NULL,
  `user_gender` char(1) DEFAULT NULL,
  `user_address` varchar(50) DEFAULT NULL,
  `user_bdate` date DEFAULT NULL,
  `user_age` int(11) DEFAULT NULL,
  `user_contact` varchar(15) DEFAULT NULL,
  `user_email` varchar(25) DEFAULT NULL,
  `user_password` varchar(25) DEFAULT NULL,
  `user_img` blob,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1006 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_fname`, `user_lname`, `user_gender`, `user_address`, `user_bdate`, `user_age`, `user_contact`, `user_email`, `user_password`, `user_img`) VALUES
(12, 'Ransom', 'Carino', 'M', 'Biasong, Talisay City, Cebu', '1995-05-05', 22, '09234815395', 'padillaransom@gmail.com', 'ransom', NULL),
(1003, 'Jhudey', 'Carino', 'M', 'Talisay', '2001-02-03', NULL, '09234815395', 'jhudey@yahoo.com', 'jhudey', NULL),
(1004, 'Recca Jane', 'Valencia', 'F', 'Sibonga', '1997-03-31', NULL, '09123242222', 'recca@yahoo.com', 'recca', NULL),
(1005, 'Ronald', 'Bonje', 'M', 'Lahug Cebu City', '1994-03-22', NULL, '09233026191', 'ronald@yahoo.com', 'ronald', NULL);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcement`
--
ALTER TABLE `announcement`
  ADD CONSTRAINT `admin` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `code` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE;

--
-- Constraints for table `assessment`
--
ALTER TABLE `assessment`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD CONSTRAINT `co_id` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `ref_id` FOREIGN KEY (`ref_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `session` FOREIGN KEY (`session_id`) REFERENCES `session` (`session_id`) ON UPDATE CASCADE;

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `course_id` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `session_schedule` FOREIGN KEY (`session_id`) REFERENCES `session` (`session_id`) ON UPDATE CASCADE;

--
-- Constraints for table `session`
--
ALTER TABLE `session`
  ADD CONSTRAINT `co_id_session` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
