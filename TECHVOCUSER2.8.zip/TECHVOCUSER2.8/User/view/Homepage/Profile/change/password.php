<div class="content" style="margin-top: 150px;">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header" style="background-color: #3063ad;">
                                    <h4 class="title">Change Password</h4>
                                    <p class="category">Complete your profile</p>
                                </div>
                                <div class="card-content">
                                    <form name="change_password_form" method="POST" onsubmit="return validatePassword()">
                                        <div class="row">
                                           <input type="hidden" name="user_id" value="<?php echo $user_id?>" class="form-control">
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Enter you old password</label>
                                                    <input type="password" name="current_password"  class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">New Password</label>
                                                    <input type="password" name="new-pass" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Confirm Password</label>
                                                    <input type="password" name="re-pass" class="form-control">
                                                </div>
                                            </div>
                                        </div>

                                        <button type="submit" name="change_user_password" class="btn btn-primary pull-right">Submit</button>
                                        <div class="clearfix"></div>
                                    </form>
                                    <p id="validatePassword" class="category">
                                        <?php 
                                                if($update == "ok"){
                                                  echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Your password successfully Changed..</div>';
                                                }
                                                else if($update == "notok"){
                                                  echo '<div class="alert alert-warning alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Invalid current password..</div>';
                                                }
                                              ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-profile">
                                <div class="card-avatar">
                                    <a href="#pablo">

                                        <img class="img" src="<?php echo $userInfo['user_img']?>" />

                                    </a>
                                </div>
                                <div class="content">
                                    <h6 class="category text-gray"></h6>
                                    <h4 class="card-title"><?php echo $userInfo['user_fname']." ".$userInfo['user_lname'] ?></h4>
                                    <p class="card-content">
                                        Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
                                    </p>
                                    <a href="index.php?q=Profile/change/email" class="btn btn-dander">Change Email</a><a href="index.php?q=Profile/change/password" class="btn btn-info ">Change Password</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>