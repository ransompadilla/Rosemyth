<div class="content" style="margin-top: 150px;">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header" style="background-color: #3063ad;">
                                    <h4 class="title">Change Email</h4>
                                    <p class="category">Complete your profile</p>
                                </div>
                                <div class="card-content">
                                    <form name="change_user_email_form" method="POST" onsubmit="return validateEmail();">
                                        <div class="row">
                                           <input type="hidden" name="user_id" value="<?php echo $user_id?>" class="form-control">
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Your Email</label>
                                                    <input type="email" name="user_email" value="<?php echo $userInfo['user_email']?>" class="form-control" readonly>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">New Email</label>
                                                    <input type="email" name="new-email" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Confirm Email</label>
                                                    <input type="email" name="retype-email" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Enter your password</label>
                                                    <input type="password" name="current_password"  class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" name="change_user_email" class="btn btn-primary pull-right">Submit</button>
                                        <div class="clearfix"></div>
                                    </form>
                                    <p id="validateEmail" class="category">
                                        <?php 
                                                if($update == "ok"){
                                                  echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Your email successfully updated..</div>';
                                                }
                                                else if($update == "notok"){
                                                  echo '<div class="alert alert-warning alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Invalid password..</div>';
                                                }
                                                else if($update == "used"){
                                                  echo '<div class="alert alert-warning alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Email Already in used..</div>';
                                                }
                                              ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-profile">
                                <div class="card-avatar">
                                    <a href="#pablo">

                                        <img class="img" src="<?php echo $userInfo['user_img']?>" />

                                    </a>
                                </div>
                                <div class="content">
                                    <h6 class="category text-gray"></h6>
                                    <h4 class="card-title"><?php echo $userInfo['user_fname']." ".$userInfo['user_lname'] ?></h4>
                                    <p class="card-content">
                                        Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
                                    </p>
                                    <a href="index.php?q=Profile/change/email" class="btn btn-dander">Change Email</a><a href="index.php?q=Profile/change/password" class="btn btn-info ">Change Password</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>