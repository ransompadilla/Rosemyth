<?php 
    if(isset($_COOKIE['update'])){
          $update=$_COOKIE['update'];
    }
    else $update = null;
    
?>
<!DOCTYPE html>
<html lang="en-us">
    <head>
      <?php include "model/BootstrapHeader.php";

      ?>

    
  
  <script src="../Bootstrap/lib/jquery/jquery.min.js"></script>
  <script src="../Bootstrap/lib/bootstrap/js/bootstrap.min.js"></script>

  <link href="../Admin/assets/css/material-dashboard.css?v=1.2.0" rel="stylesheet" />
    <link href="../Admin/assets/css/demo.css" rel="stylesheet" />
  <style type="text/css">
    .xProfile{
      width: 400px;
      height: 400px;
    }
    body{
      background-color: #dce3ed;
    /*background-image: url(../Bootstrap/img/info/info3.jpg);
    background-repeat: no-repeat;
    background-size: cover;*/
    }

  </style>
  <script type="text/javascript">
    function validatePassword() {
        var form = document.forms["change_password_form"];
        var password = form["new-pass"].value;
        var c_password = form["re-pass"].value;
        if (c_password != password) {
            document.getElementById('validatePassword').innerHTML = "<div class='alert alert-danger alert-dismissable'><button type='button' class='close' data-dismiss='alert'aria-hidden='true'>&times;</button>Warning ! Password did not much!</div>";
            return false;
        }
        else{
            password = c_password;
        }

    }
     function validateEmail() {
        var form = document.forms["change_user_email_form"];
        var email = form["new-email"].value;
        var re_email = form["retype-email"].value;
        if (email != re_email) {
            document.getElementById('validateEmail').innerHTML = "<div class='alert alert-danger alert-dismissable'><button type='button' class='close' data-dismiss='alert'aria-hidden='true'>&times;</button>Warning ! Email did not much!</div>";
            return false;
        }
        else{
            password = c_password;
        }

    }
  </script>
    </head>
    <body >
      <header id="header" style="background-color: #3063ad;">
    <div class="container-fluid">

      <div id="logo" class="pull-left">
        <h1><a href="#intro" class="scrollto">TECHVOC</a></h1>
        
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="index.php?q=Home">Home</a></li>
          <li><a href="index.php?q=Profile/Profile"><?php echo $name;?></a></li>
          <li><a href="index.php?logout=1">Logout</a></li>
        </ul>
      </nav>
    </div>
  </header>
  
