<!DOCTYPE html>
<html lang="en-us">
    <head>
      <?php include "model/BootstrapHeader.php";?>
      <style type="text/css">
		input[type="email"],
		input[type="password"]{
			display: block;
			margin: 0 auto;
			width: 100%;
			background-color: #fff;
			border: 1px solid #fff;
			padding: 12px 15px;
			margin-bottom: 30px;
		}
      </style>
    </head>
    <body>