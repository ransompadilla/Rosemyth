<!--admission-->
	<!--------------->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/navbar.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	
	
<!-- Start WOWSlider.com HEAD section --> <!-- add to the <head> of your page -->
	<link rel="stylesheet" type="text/css" href="slider/engine1/style.css" />
	<script type="text/javascript" src="slider/engine1/jquery.js"></script>
	<!-- End WOWSlider.com HEAD section -->
	
  </head>
  
	<!--/ header-->
	<!-- ACADEMICS section -->
	<section id = "academics" class="padding-top5 bgadmissions" style="background-color: #0000CD;" style=>
		<div class = "container">	
			<div class="row padding-top55">
			<h2 class = "size36">&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<b>Application Requirements</b></h2>
				<hr>
			</div>
		</div>
	<br>
		<div class = "col-md-3 padding-top5">
					<div class="row">
						<div class="col-md-12">
							<img src="img/info1.jpg" height="350px" width="450px">
						</div>
					</div>
				</div>

		
			<div class="row">
				<div class = "col-md-25 century padding-top10 indent ">
							<div class = " size20">
							&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; <a href = "javascript:void(0)" id = "techvoc_showhide" class = "gray"><i id = "techvoc_btn_showhide" class="fa fa-plus-square-o" aria-hidden="true"></i></a>&nbsp; TECHNICAL VOCATIONAL COURSES ENROLLMENT REQUIREMENTS<br><br>
							</div>
								<div class = "row padding-top15 hidden" id = "techvoc_requirements">
									<div class = "col-md-8">
										<p class = "indent size24">
											<ul class = "admission size20">
												&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;<b>Birth Certificate<br>
												&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Medical Certificate<br>
												&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;Certificate of Good Moral Character<br>
												&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;High School Diploma (If Applicable)<br>
												&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;2X2 Colored Picture with White Background (4 Pcs.)<br>
											</ul>
										</p>
									</div>
								</div>
				</div>
			</div>
	</section>
	<script src="js/sidebar.js"></script>
  </body>
</html>