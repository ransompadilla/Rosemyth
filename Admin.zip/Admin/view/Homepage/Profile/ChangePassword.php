<div class="container" style="margin-top: 10%;">
  
<form class="login-form" name="AuthForm" method="POST"  onsubmit="return validatePassword();"  enctype="multipart/form-data">  
  <p id="validatePassword"></p>    
      
        <div class="row" >
            
            
            
            <div class="col-md-3"></div>
            <div class="col-md-6" >
              <p>
              <?php 
              if($update == "notok"){
                  echo '<div class="alert alert-warning alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Invalid Typing Current Password..</div>';

                }
                
              ?>
                
              
            </p> 
                  <label><h1>Change Password</h1> </label>
                  
                  <input type="hidden" name="user_id" value="<?php echo $user_id?>" />
                  <div class="form-group">
                    <input class="form-control" name="current_password" type="password" placeholder="Your Current Password *" required="">
                    
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="password" type="password" placeholder="Your Password *" required="">
                    
                  </div>
                  <div class="form-group">
                    <input class="form-control" name="c_pass" type="password" placeholder="Retype Password *" required="">
                    
                  </div>
                  <button type="submit" name="change_user_password" class="btn btn-info" style="width: 49%">
                    Submit</button>
                  <a href="index.php?homepage=Profile/Profile" class="btn btn-danger" style="width: 49%">
                    Cancel</a>
                </div>
        </div>
      </form>

</div>