<div class="container" style="margin-top: 100px;">
    <div class="row">
      <div class="col-lg-3">
        
<!-- 
        <div class="panel-group">
          <div class="panel panel-primary">
            <div class="panel-heading">PROGRAMS</div>
            <div class="panel-body">
              <ul class="list-group">
                <li class="list-group-item"><a href="#">Announcement</a></li>
                <li class="list-group-item"><a href="#"> Activity</a></li>
                <li class="list-group-item"><a href="#"> Vocational Courses</a></li>
              </ul>
            </div>
          </div>
        </div> -->

        <div class="panel-group">
          <div class="panel panel-primary">
            <div class="panel-heading">Students</div>
            <div class="panel-body">
              <ul class="list-group" >
                <li class="list-group-item" ><a id="en_stud" href="index.php?q=vocational/student-wants-to-enroll" >Students wants to enroll (<?php echo count($en_student);?>)</a></li>
                <li class="list-group-item"><a href="index.php?q=vocational/student-enrolled">List of Students Enrolled</a></li>
                
              </ul>
            </div>
          </div>
        </div>
        
      </div>
      
    