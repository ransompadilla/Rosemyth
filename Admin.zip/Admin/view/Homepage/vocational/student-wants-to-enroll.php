<?php include "view/Homepage/Home.php";?>
<div class="col-lg-9">
        <div class="panel-group">
          <div class="panel panel-primary">
            <div class="panel-heading">List Of Students wants to Enroll (<?php echo count($en_student);?>)</div>
            <div class="panel-body">
              <form method="POST">
              <div class="row">
                <div class="pull-right">
                <div class="col-sm-3 form-group">
                  <label>FROM: </label>
                  <?php
                    if(isset($_GET['from']) != ""){
                       echo '<input type="date" name="from_date" value="'.$_GET['from'].'"  class="form-control">';
                    }
                    else{
                      echo '<input type="date" name="from_date" class="form-control">';
                    }
                  ?>
                 
                </div>  
                <div class="col-sm-3 form-group">
                  <label>TO:</label>
                  <?php
                    if(isset($_GET['from']) != ""){
                       echo '<input type="date" name="to_date" value="'.$_GET['to'].'"  class="form-control">';
                    }
                    else{
                      echo '<input type="date" name="to_date" class="form-control">';
                    }
                  ?>
                </div>  
                <div class="col-sm-3 form-group">
                  <label>Select Course:</label>
                  <select name="course" class="form-control" >
                    <option value=""> All Courses</option>
                    <?php 
                    if(isset($_GET['course'])){
                      if(count($v_courses) > 0){
                        foreach ($v_courses as $vc) {
                          if($_GET['course'] == $vc['co_id']){
                            echo '
                              <option value="'.$vc['co_id'].'" Selected>'.$vc['co_name'].'</option>
                            ';
                          }
                          else{
                            echo '
                              <option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>
                            ';
                          }
                        }
                      }
                    }
                    else{
                      if(count($v_courses) > 0){
                        foreach ($v_courses as $vc) {
                          echo '
                            <option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>
                          ';
                        }
                      }
                    }
                    ?>
                  </select>
                  <!-- <input type="search" class="light-table-filter" data-table="order-table" placeholder="Filter"> -->
                </div>  
                 <div class="col-sm-9 form-group">
                  <br>
                   <button type="submit" name="btn-search" class="btn btn-default" style="width: 100%;">Search</button>
                </div>   
              </div>
              </div>
              </form>
                 <table class="order-table table table-stripped" id="myTable">
                  <thead>
                    <tr>
                      <th>IDNO</th><th>NAME</th><th>AGE</th><th>GENDER</th><th>CITY</th><th>STATE</th><th>ZIP</th><th>COURSE</th><th>DATE</th>
                    </tr>
                  </thead>
                  <tbody>
                  
                  <?php
                    if(isset($_GET['from']) !="" || isset($_GET['to']) !="" || isset($_GET['course']) !="" ){
                      $search = $this->model->Search($_GET['from'],$_GET['to'],$_GET['course'],0);
                      if(count($search) > 0){
                        foreach ($search as $ens) {
                          //if($ens['en_status'] === 0){
                            echo '<tr>
                                  <td>'.$ens['ref_id'].'</td>
                                  <td>'.$ens['en_lname'].', '.$ens['en_fname'].'</td>
                                  <td>'.$ens['en_age'].'</td>
                                  <td>'.$ens['en_gender'].'</td>
                                  <td>'.$ens['en_city'].'</td>
                                  <td>'.$ens['en_state'].'</td>
                                  <td>'.$ens['en_zip'].'</td>
                                  <td>'.$ens['co_name'].'</td>
                                  <td>'.$ens['en_date'].'</td>
                                  </tr>';
                            } 
                          //}
                        }
                    }
                    else{
                      if(count($en_student) > 0){
                        foreach ($en_student as $ens) {
                          echo '<tr>
                                <td>'.$ens['ref_id'].'</td>
                                <td>'.$ens['en_lname'].', '.$ens['en_fname'].'</td>
                                <td>'.$ens['en_age'].'</td>
                                <td>'.$ens['en_gender'].'</td>
                                <td>'.$ens['en_city'].'</td>
                                <td>'.$ens['en_state'].'</td>
                                <td>'.$ens['en_zip'].'</td>
                                <td>'.$ens['co_name'].'</td>
                                <td>'.$ens['en_date'].'</td>
                                </tr>';
                          } 
                        }
                    }
                      
                    
                        
                      ?>
                  </tbody>
                </table> 
          </div>
        </div>
        </div>
      </div>
     