<?php
	include_once("Crud.php");
	class Model{
		private $crud;
		public function __construct(){
			$this->crud = new Crud();
		}
        //REGISTER
		public function RegisterAdmin($data){
            $query = "INSERT INTO admin(admin_fname,admin_lname,admin_gender, admin_address, admin_contact, admin_email, admin_password) VALUES(?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);

        }
		public function AddSchedule($data){
			$query = "INSERT INTO schedule(sched_week_start, sched_week_end, sched_time_start, sched_time_end, session_id, co_id,stud_limit) VALUES(?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);
		}
        public function AddActivities($data){
            $query = "INSERT INTO activities(act_title, act_desc, act_img,co_id) VALUES(?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function AddCourse($data){
            $query = "INSERT INTO course_offer(co_name, co_desc, co_limit, co_img,co_active) VALUES(?,?,?,?,1)";
            $this->crud->Insert($query,$data);
        }
        public function AddToDrop($data){
            $query = "INSERT INTO drop_retrieve(st_d_remark, st_d_date,en_id) VALUES(?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function AddTrainorCourse($data){
            $query = "INSERT INTO trainor_course(tr_id, co_id,hr_limit, tr_course_date) VALUES(?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function AddTrainorSchedule($data){
            $query = "INSERT INTO trainor_schedule(tr_sched_day, tr_sched_start_time, tr_sched_end_time,tr_hour, tr_id, co_id, tr_sched_date) VALUES(?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function AddSession($data){
            $query = "INSERT INTO session(start_date, co_id,session_status) VALUES(?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function AddTrainer($data){
            $query = "INSERT INTO trainor(tr_fname, tr_lname,tr_gender,tr_age,tr_contact,tr_address, tr_active) VALUES(?,?,?,?,?,?,1)";
            $this->crud->Insert($query,$data);
        }
        public function RegisterAssessment($data){
            $query = "INSERT INTO assessment(
            info_region,
            info_province,
            info_district,
            info_city,
            info_provider,
            info_address,
            info_typeofprovider,
            info_classification_provider,
            info_industry_sector,
            info_prog_reg_stat,
            info_prog_title,
            info_ctpr,
            info_training_calendar_mode,
            info_delivery_mode,
            info_voucher_no,
            info_date_started,
            info_date_finished,
            info_date_assessed,
            info_assessment_result,
            user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        //ENROLLMENT STUDENT
        public function EnrollStudent($data){
            $query = "INSERT INTO enrollment(
            en_fname,
            en_lname,
            en_mi,
            en_num_street,
            en_barangay,
            en_district,
             en_city, 
             en_province,
              en_region,
              en_email_add,
              en_contact,
              en_nationality,
              en_gender,
              en_civilstatus,
              en_empstatus,
               en_bdate,
               en_age,
               en_birthplace,
               en_father_fname,
               en_father_lname,
               en_mother_fname,
               en_mother_lname,
               en_edattainment,
               en_lts,
               en_taken_where,
               en_taken_when,
               en_stud_voucher_no,
               en_scholar_package,
                 co_id,
                 en_status,en_active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function OpenSession($data){
            $query = "INSERT INTO session(co_id,start_date, end_date, session_status) VALUES(?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function ChangeEmail($table,$data){
            $query = "UPDATE $table set cust_email=? where cust_id=?";
            $this->crud->Update($query,$data);

        }
        public function CheckadminPassword($data){
            $query = "SELECT admin_password FROM admin WHERE admin_password=? and admin_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        public function ChangeadminPassword($data){
            $query = "UPDATE admin set admin_password=? where admin_id=?";
            $this->crud->Update($query,$data);

        }
        //
        public function GetAlladmin($data){
            $query = "SELECT * FROM admin WHERE admin_id != $data; ";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //CHECK EMAIL
        public function CheckEmail($data){
            $check=NULL;
            $query = "SELECT * FROM admin where admin_email=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        //CHECK PASSWORD
        public function CheckPassword($data){
            $check=NULL;
            $query = "SELECT * FROM admin where admin_id=? and admin_password=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        //VALIDATE LOGIN
        public function ValidateadminLogin($data){
            $query = "SELECT * FROM admin where admin_email=? and admin_password=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //LOGOUT
        public function admin_Logout(){
            if(isset($_COOKIE['admin_id'])){
                setcookie("admin_id",$_COOKIE['admin_id'], time() - 86400 ,"/");
                header("Location: index.php");
            }
        }
        
        public function getadminInformation($data){
             
            $query = "SELECT * FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            
            return $row;
        }
       
        //AMDIN SIDE
        public function getAdminNameByID($data){
            $name=null;
            $query = "SELECT admin_fname, admin_lname FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['admin_fname']." ".$row['admin_lname'];
            }
            return $name;
        }
        // public function getAdminImgByID($data){
        //     $img=null;
        //     $query = "SELECT admin_img FROM admin where admin_id=?";
        //     $row = $this->crud->Select($query,$data);
        //     if(count($row) > 0){
        //         $img = $row['admin_img'];
        //     }
        //     else $img=null;
        //     return $img;
        // }
        //
        //
        //GET STUDENT WANTS TO ENROLL
        public function GetStudentWantTOEnroll(){
            $query = "SELECT  e.*, c.* FROM enrollment e, course_offer c WHERE e.en_status=0 and e.co_id=c.co_id;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetRegistrantPayment(){
            $query = "SELECT  e.*, c.* FROM enrollment e, course_offer c WHERE e.co_id=c.co_id;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetStudentEnrolled(){
            $query = "SELECT e.*, c.* FROM enrollment e, course_offer c WHERE e.en_status > 0 and e.co_id=c.co_id;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetAllStudentEnrollies(){
            $query = "SELECT e.*, c.* FROM enrollment e, course_offer c WHERE e.co_id=c.co_id;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
    
        public function CountUser(){
            $query = "SELECT * FROM user;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET VOCATIONAL COURSES OFFERED
        public function GetVocationalCourses(){
            $query = "SELECT * FROM course_offer WHERE co_active=1";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        // public function GetCourseByCode($data){
        //     $query = "SELECT * FROM course_offer WHERE co_code=?";
        //     $row = $this->crud->Select($query,$data);
        //     return $row;
        // }
         public function GetCourseByID($data){
            $query = "SELECT * FROM course_offer WHERE co_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
         //VIEW ENROLLIES
        public function GetEnrolliesByENID($data){
            $query = "SELECT * FROM enrollment WHERE en_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //GET STUDENT BY COURSE
        public function GetUnSchedStudenyByCourse($data){
            $query = "SELECT * FROM enrollment WHERE co_id=$data and en_status > 0 and tr_id is null;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET ASSESSMENT
        public function GetAssessment(){
            $query = "SELECT a.*, u.*, e.* FROM assessment a , user u, enrollment e WHERE a.user_id=u.user_id and e.ref_id=u.user_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetDoneSchedStudenyByCourse($data){
            $query = "SELECT e.*, c.*, tr.* FROM enrollment e, course_offer c, trainor tr WHERE e.co_id=$data and e.en_status > 0 and e.co_id=c.co_id and e.tr_id=tr.tr_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //CHECK SESSION BY COURSE
        public function CheckSession($data){
            $found="false";
            $query = "SELECT * FROM session WHERE co_id=? and session_status=?";
            $row = $this->crud->Select($query, $data);
            if($row > 0){
                $found = "true";
            }
            return $found;
        }
        //GET ALL USERS
        public function GetAllUsers(){
            $query = "SELECT u.*, e.*, c.* FROM user u LEFT JOIN enrollment e ON u.user_id=e.ref_id lEFT JOIN course_offer c ON e.co_id=c.co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetStudentTraining(){
            $query = "SELECT e.*, c.* FROM  enrollment e, course_offer c WHERE e.co_id=c.co_id and e.en_status > 0";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //TO DROP USER
        public function ToDropUser(){
            $query = "SELECT e.*, c.* FROM user u LEFT JOIN enrollment e,course_offer c WHERE e.co_id=c.co_id and e.en_status=1";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET OPEN SESSION BY COURSE
        public function GetOpenSessionByCourse($data){
            $query = "SELECT * FROM session WHERE co_id=? and session_status=1";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //GET ANNOUNCEMENT
        public function GetAnnouncement(){
            $query = "SELECT * FROM announcement";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET REGISTRANT BYID
        public function GetRegistrantByID($data){
            $query = "SELECT * FROM enrollment WHERE en_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //COUNT ENROLLED BY COURSE
        public function CountEnrolledByCourse($data){
            $query = "SELECT e.*, c.* FROM enrollment e, course_offer c  WHERE e.co_id=c.co_id and e.co_id=$data and e.en_status > 0 and e.tr_id is not null ";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function CountEnrolledDropByCourse($data){
            $query = "SELECT e.*, c.* FROM enrollment e, course_offer c  WHERE e.co_id=c.co_id and e.co_id=$data and e.en_status = 2 ";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
         public function CountRegistrantByCourse($data){
            $query = "SELECT e.*, c.* FROM enrollment e, course_offer c  WHERE e.co_id=c.co_id and e.co_id=$data and e.en_status=0";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET SESSION ID
        public function GetSessionID(){
            $data = array(1);
            $query = "SELECT * FROM session WHERE session_status=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //GET SCHEDULE
        public function GetSchedule(){
             $query = "SELECT ses.*, c.*, sched.* FROM session ses, course_offer c, schedule sched  WHERE sched.co_id=c.co_id and sched.session_id=ses.session_id ORDER BY sched.sched_id asc";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetTrainorSchedule(){
             $query = "SELECT * FROM trainor_schedule";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET MAX SCHED ID
        public function GetMaxScheduleID(){
            $query = "SELECT max(sched_id) as maxSchedID FROM schedule";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetMaxEnrollmentID(){
            $query = "SELECT max(en_id) as max_en FROM enrollment";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetEnrollmentID(){
            $query = "SELECT * FROM enrollment";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetScheduleByID($data){
            $query = "SELECT * FROM schedule WHERE sched_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }

        public function GetScheduleByCourse($data){
            $query = "SELECT * FROM schedule WHERE co_id=$data";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetScheduleByTrainorCourse($tr_id,$co_id){
            $query = "SELECT tr.*, trc.*, trs.*, c.* FROM trainor tr, trainor_course trc, trainor_schedule trs, course_offer c WHERE trs.tr_id=tr.tr_id and trs.co_id=c.co_id and trs.tr_id=$tr_id and trs.co_id=$co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetCourseByTrainer($data){
            $query = "SELECT trc.*, c.* FROM trainor_course trc, course_offer c WHERE trc.co_id=c.co_id and tr_id=$data";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetTrainorScheduleByCourse($tr_id,$co_id){
            $query = "SELECT trs.*, ses.* FROM trainor_schedule trs, session ses WHERE trs.tr_id=$tr_id and trs.co_id=$co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //
        public function GetDropRetrieveRemarks($data){
             $query = "SELECT * FROM drop_retrieve WHERE en_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        public function GetDropCount($data){
             $query = "SELECT * FROM drop_retrieve WHERE en_id=$data";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetDropCountAll(){
             $query = "SELECT * FROM enrollment WHERE en_status=2";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function CheckDropExist($data){
            $checked = 0;
             $query = "SELECT * FROM drop_retrieve WHERE en_id=?";
            $row = $this->crud->Select($query,$data);
            if($row > 0){
                $checked = 1;
            }
            return $checked;
        }
        //GET ALL ACTIVITEIES
        public function GetAllActivities(){
             $query = "SELECT * FROM activities";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET ALL ACTIVITEIES
        public function GetAllActivitiesByCOID($data){
             $query = "SELECT * FROM activities WHERE co_id=$data";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET ALL TRAINORS
        public function GetTrainors(){
             $query = "SELECT * FROM trainor";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetTrainorByID($data){
             $query = "SELECT * FROM trainor WHERE tr_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //GET COURSE WITH TRAINOR
        public function GetCourseWithTrainor(){
             $query = "SELECT c_tr.*, tr.*, c.* FROM trainor tr, course_offer c, trainor_course c_tr WHERE c_tr.tr_id=tr.tr_id and c_tr.co_id=c.co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //CHECK TRAINORS COURSE
        public function CheckTrainorCourse($data){
            $checked = 0;
             $query = "SELECT * FROM trainor_course WHERE tr_id=? and co_id=?";
            $row = $this->crud->Select($query,$data);
            if($row > 0){
                $checked = 1;
            }
            return $checked;
        }
        //GET TRAINOR COURSE BY ID
        public function GetTrainorCourseByID($data){
             $query = "SELECT trc.*, c.* FROM trainor_course trc, course_offer c WHERE trc.co_id=c.co_id and trc.tr_id=$data";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET SCHEDULE DETAILS
        public function GetScheduleDetails(){
             $query = "SELECT trs.*, c.*, tr.* FROM trainor_schedule trs, course_offer c, trainor tr WHERE trs.co_id=c.co_id and trs.tr_id=tr.tr_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetSessionOpen(){
             $query = "SELECT * FROM session WHERE session_status=1;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }

        public function GetTrainerStudent($data){
             $query = "SELECT * FROM enrollment WHERE tr_id=$data";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetMonitorSchedule(){
             $query = "SELECT ses.*, trs.*, c.*, tr.*,trc.*, sum(trs.tr_hour) as t_hour FROM session ses, trainor_schedule trs, course_offer c, trainor tr, trainor_course trc WHERE trs.session_id=ses.session_id and trs.co_id=c.co_id and trc.tr_id=trs.tr_id and trc.co_id=trs.co_id and trs.tr_id=tr.tr_id and ses.session_status <> 2 GROUP BY trs.tr_id, trs.co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }

        public function GetMonitorScheduleDetails(){
             $query = "SELECT trs.*, c.*, tr.*,trc.* FROM trainor_schedule trs, course_offer c, trainor tr, trainor_course trc WHERE trs.co_id=c.co_id and trc.tr_id=trs.tr_id and trc.co_id=trs.co_id and trs.tr_id=tr.tr_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetMonitorScheduleByCourseID($data){
             $query = "SELECT ses.*, trs.*, c.*, tr.*,trc.*, sum(trs.tr_hour) as t_hour FROM session ses, trainor_schedule trs, course_offer c, trainor tr, trainor_course trc WHERE trs.session_id=ses.session_id and trs.co_id=c.co_id and trc.tr_id=trs.tr_id and trc.co_id=trs.co_id and trs.tr_id=tr.tr_id and trs.co_id=$data and ses.session_status=1 GROUP BY trs.tr_id, trs.co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function CountScheduleEnrolled($tr_id,$co_id){
            $query = "SELECT tr_id FROM enrollment WHERE tr_id=$tr_id and co_id=$co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //COUNT STUDEN WITH SCHEDULE
        public function CountStudentBySchedule($data){
            $query = "SELECT * FROM enrollment WHERE sched_id=$data";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //SEARCH
        public function Search($from, $to, $course, $status){
            $row="";
                $query = "SELECT e.*, c.* FROM enrollment e, course_offer c WHERE e.co_id=c.co_id  and e.co_id=$course and  e.en_date BETWEEN( LIKE '$%from' AND LIKE '$%to')  and en_status=$status  ORDER BY en_date;";
                $row = $this->crud->SelectAll($query);
            
           
            
            return $row;
            
        }
        //UPDATE
        public function UpdateadminInfo($data){
            $query = "UPDATE admin SET admin_fname=?,admin_lname=?, admin_address=?, admin_gender=?, admin_contact=?, admin_img=? WHERE admin_id=?";
            $this->crud->Update($query, $data);
        }
        //PAYMENT
        public function UpdatePaymentStatus($data){
            $query = "UPDATE enrollment SET en_status=1 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        //DROP
        public function DropStudent($data){
            $query = "UPDATE enrollment SET en_status=2 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        public function RetrieveDropStudent($data){
            $query = "UPDATE enrollment SET en_status=1 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        //CLOSE SESSION ENROLLMENT
        public function CloseSession($data){
            $query = "UPDATE session SET session_status=2 WHERE session_status=1 and co_id=?";
            $this->crud->Update($query, $data);
        }
        //SET SESSION
        public function SetSessionSched($data){
            $query = "UPDATE enrollment SET tr_id=? WHERE en_id=?";
            $this->crud->Update($query, $data);
        }

        //DELETE REGISTRANTS
        public function DeleteRegistrant($data){
            $query = "UPDATE enrollment SET en_active=0 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        //ACTIVATE REGISTRANTS
        public function ActivateRegistrant($data){
            $query = "UPDATE enrollment SET en_active=1 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        //DELETE SCHEDULE
        public function DeleteSchedule($data){
            $query = "DELETE FROM trainor_schedule WHERE tr_sched=?";
            $this->crud->Delete($query, $data);
        }
        public function DeleteCourse($data){
            $query = "UPDATE course_offer SET co_active=0 WHERE co_id=?";
            $this->crud->Update($query, $data);
        }
        public function DeleteTrainer($data){
            $query = "UPDATE trainor SET tr_active=0 WHERE tr_id=?";
            $this->crud->Update($query, $data);
        }
        //UDPATE REGISTRANTS
        public function UpdateRegistrant($data){
            $query = "UPDATE enrollment SET en_fname=?,
            en_lname=?,
            en_mi=?,
            en_num_street=?,
            en_barangay=?,
            en_district=?,
             en_city=?, 
             en_province=?,
              en_region=?,
              en_email_add=?,
              en_contact=?,
              en_nationality=?,
              en_gender=?,
              en_civilstatus=?,
              en_empstatus=?,
               en_bdate=?,
               en_age=?,
               en_birthplace=?,
               en_father_fname=?,
               en_father_lname=?,
               en_mother_fname=?,
               en_mother_lname=?,
               en_edattainment=?,
               en_lts=?,
               en_taken_where=?,
               en_taken_when=?,
               en_stud_voucher_no=?,
               en_scholar_package=?,
                 co_id=? WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        //UPDATE SCHEDULE
        public function UpdateSchedule($data){
            $query = "UPDATE schedule SET sched_week_start=?, sched_week_end=?, sched_time_start=?, sched_time_end=?, co_id=?,stud_limit=? WHERE sched_id=?";
            $this->crud->Update($query, $data);
        }
         public function UpdateCourse($data){
            $query = "UPDATE course_offer SET co_name=?, co_desc=?, co_limit=?, co_img=? WHERE co_id=?";
            $this->crud->Update($query, $data);
        }
        public function UpdateScheduleSession($data){
            $query = "UPDATE trainor_schedule SET session_id=? WHERE co_id=?";
            $this->crud->Update($query, $data);
        }
        public function UpdateTrainorSchedule($data){
            $query = "UPDATE trainor_schedule SET tr_sched_day=?, tr_sched_start_time=?, tr_sched_end_time=?,tr_hour=?,tr_id=?, co_id=?, tr_sched_date=? WHERE tr_sched=?";
            $this->crud->Update($query, $data);
        }
        public function UpdatePaymentPartial($data){
            $query = "UPDATE enrollment SET en_status=3 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        public function UpdatePaymentFullypaid($data){
            $query = "UPDATE enrollment SET en_status=1 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        public function RetrieveStudent($data){
            $query = "UPDATE drop_retrieve SET st_r_remark=?, st_r_date=? WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        public function UpdateTrainer($data){
            $query = "UPDATE trainor SET tr_fname=?, tr_lname=?, tr_gender=?, tr_age=?, tr_contact=?, tr_address=? WHERE tr_id=?";
            $this->crud->Update($query, $data);
        }
        public function ActivateTrainer($data){
            $query = "UPDATE trainor SET tr_active=1 WHERE tr_id=?";
            $this->crud->Update($query, $data);
        }
	}
?>