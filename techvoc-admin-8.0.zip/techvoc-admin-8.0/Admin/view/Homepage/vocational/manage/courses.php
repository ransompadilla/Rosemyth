<?php
$str="";$flag="";
if(isset($_COOKIE['flag'])){
	$flag=$_COOKIE['flag'];
}
else{$flag=$flag;}
  if(isset($_GET['id'])){
    $course = $this->model->GetCourseByID(array($_GET['id']));
      $unsched_student_course = $this->model->GetUnSchedStudenyByCourse($_GET['id']);
      $donesched_student_course = $this->model->GetDoneSchedStudenyByCourse($_GET['id']);
      $gen = ""; 
      $session = $this->model->GetOpenSessionByCourse(array($_GET['id']));
      if($session){
        $start = strtotime($session['start_date']);
        $end = strtotime($session['end_date']);
        $start_d = Date('F/d/Y', $start);
        $end_d = Date('F/d/Y', $end);

        $str = $start_d." - ".$end_d;
      }
      else{$str="<b>NOTE: Please set a new Session to set SCHEDULE.</b>";}
    }
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
        
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <div class="nav-tabs-navigation">
                                        <div class="nav-tabs-wrapper">
                                           <h3>MANAGE COURSES</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-content">

                                    <div class="row">
                                    	
                                        <div class="well col-lg-4" id=""  style="background-color: #e8eaea; padding: 20px; border: 1px;">
                                        <div class="card-header" data-background-color="purple">
		                                    <div class="nav-tabs-navigation">
		                                        <div class="nav-tabs-wrapper">
		                                           <h3>ADD COURSE</h3>
		                                        </div>
		                                    </div>
		                                </div>
          										<form method="POST" enctype="multipart/form-data">
          										  
          										  <div class="row">
          											
          											<div class="col-md-12">
          												<input type="text" name="co_name" class="form-control" placeholder="Course Name" required="">
          											</div>
          											<div class="col-md-12">
          												<input type="text" name="co_desc" class="form-control" placeholder="Course Description" required="">
          											</div>
          											<div class="col-md-12">
          												<input type="text" name="co_limit" class="form-control" placeholder="Course Limit" required="">
          											</div>
          											<div class="col-md-12">
                                                    <div class="form-group">
                                                    <label>Course Image</label>
                                                    <div class="input-group">
                                                        <span class="input-group-btn">
                                                            <span class="btn btn-default btn-file">
                                                                Browse… <input type="file" name="course_img" id="course_img" required="">
                                                            </span>
                                                        </span>
                                                        <input type="text" class="form-control" readonly>
                                                    </div>
                                                    </div>
                                                </div>
										  </div>
										  
										<div class="row">
											<div class="col-md-12">
										  <button type="submit" name="add_course" class="btn btn-primary" style="width:100%;">Submit</button>
										    </div>
										</div>

										</form>
										<div class="row">
											<div class="col-md-12">
										  
											<p>
											  <?php if($flag == "ok"){

												echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Register </div>';
											  }
											  else if($flag == "a"){

												echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> file is not an image </div>';
											  }
											  else if($flag == "b"){

												echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Sorry, file already exists. </div>';
											  }
											  else if($flag == "c"){

												echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Sorry, your file is too large. </div>';
											  }
											  else if($flag == "d"){

												echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Sorry, only JPG, JPEG, PNG & GIF files are allowed. </div>';
											  }
											  else if($flag == "e"){

												echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Sorry, your file was not uploaded. </div>';
											  }
											  else if($flag == "f"){

												echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Sorry, there was an error uploading your file. </div>';
											  }
											  
											  ?>
											  
											</p>
											</div>
										</div>
										<hr>
                                        <div class="card-header" data-background-color="purple">
		                                    <div class="nav-tabs-navigation">
		                                        <div class="nav-tabs-wrapper">
		                                           <h3>TRAINOR COURSE</h3>
		                                        </div>
		                                    </div>
		                                </div>
		                                 <div class="row">
		                                    	<div class="col-md-12">
		                                    		<form method="POST" name="trainor_course_form" >
		                                    		<select name="co_id"  class="form-control" required="">
		                                    			<option value="">Select Course</option>
		                                    			<?php
		                                    				if(count($v_courses) > 0){
		                                    					foreach ($v_courses as $vc) {
		                                    						echo '<option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>';
		                                    					}
		                                    				}
		                                    				
		                                    			?>
		                                    		</select>
		                                    		<select name="tr_id" class="form-control" required="">
		                                    			<option value="">Choose Trainor</option>
		                                    			<?php
		                                    				if(count($trainor) > 0){
		                                    					foreach ($trainor as $tr) {
		                                    						echo '<option value="'.$tr['tr_id'].'">'.$tr['tr_fname'].'  '.$tr['tr_lname'].'</option>';
		                                    					}
		                                    				}
		                                    				
		                                    			?>
		                                    		</select>
                                            <input type="text" name="hr_limit" class="form-control" placeholder="Hour Limit" required="">
		                                    		<button type="submit" name="add_trainor_course" class="btn btn-primary" style="width: 100%;">Submit</button>
		                                    		</form>
		                                    		<p>
		                                    			<?php
		                                    				if($flag == "tr_ok"){

                																echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Register </div>';
                															  }
                															 else if($flag == "tr_notok"){

                																echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Sorry, Already Taken. </div>';
                															  }
		                                    			?>
		                                    		</p>
		                                    	</div>
		                                    </div>
                           	</div>
                            <div class="col-lg-8" style="background-color: #f0f0f0; padding: 20px; border: 1px;">
                            	<div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <div class="nav-tabs-navigation">
                                        <div class="nav-tabs-wrapper">
                                            <ul class="nav nav-tabs" data-tabs="tabs">
                                                <li class="active">
                                                    <a href="#courses" data-toggle="tab">
                                                    	Courses
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                                <li class="">
                                                    <a href="#course_with_trainor" data-toggle="tab">
                                                        Course with Trainor
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                               
                                            </ul>
                                            <!-- <i id="result" class="float-right">result</i> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="card-content" >
                                    <div class="tab-content">
                                       	<div class="tab-pane active" id="courses">
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>IMG</th>
                                                        <th>CODE</th>
                                                        <th>NAME</th>
                                                        <th>DESCRIPTION</th>
                                                        <th>LIMIT</th>
                                                        <th><span class="fa fa-cog"></span></th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                   		if(count($v_courses) > 0){
                                                   			foreach ($v_courses as $vc) {
                                                   				echo '
                                                   					<tr>
                                                   						<td><img src="'.$vc['co_img'].'" style="height: 100px; width: 140px;"></td>
                                                   						<td>'.$vc['co_id'].'</td>
                                                   						<td>'.$vc['co_name'].'</td>
                                                   						<td>'.$vc['co_desc'].'</td>
                                                   						<td>'.$vc['co_limit'].'</td>
                                                   						<td><a data-toggle="modal" href="#vcourse'.$vc['co_id'].'" class="fa fa-edit"></a> <a id="'.$vc['co_id'].'" href="#" class="delete-course fa fa-trash"></a></td>
                                                   					</tr>
                                                   				';
                                                   			}
                                                   		}
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="tab-pane" id="course_with_trainor">
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>TRAINOR</th>
                                                        <th>COURSE</th>
                                                        <th>HOUR LIMIT</th>
                                                        <th>DATE</th>
                                                        <th><span class="fa fa-cog"></span></th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                   		if(count($courseWithTrainor) > 0){
                                                   			foreach ($courseWithTrainor as $tc) {
                                                   				echo '
                                                   					<tr>
                                                   						<td>'.$tc['tr_fname'].' '.$tc['tr_lname'].'</td>
                                                   						<td>'.$tc['co_name'].'</td>
                                                              <td>'.$tc['hr_limit'].'</td>
                                                   						<td>'.$tc['tr_course_date'].'</td>
                                                   						<td><a href="#" class="fa fa-edit"></a> <a href="#" class="fa fa-trash"></a></td>
                                                   					</tr>
                                                   				';
                                                   			}
                                                   		}
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                        </div>

                                        </div>
                                        
                                </div>
                            </div>
                            </div>
                             </div>
                                     	</div>
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>

 <?php 
 	foreach ($v_courses as $vc) {
 		echo '
 			<div class="modal fade" id="vcourse'.$vc['co_id'].'" role="dialog" style="margin-top: -70px;">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">UPDATE COURSE</h4>
                </div>
                <div class="modal-body" >
                 	<form method="POST" enctype="multipart/form-data">
                                
                                <div class="row">
                                
                                <div class="col-md-12">
                                <input type="hidden" name="co_id" value="'.$vc['co_id'].'" >
                                  <input type="text" name="co_name" value="'.$vc['co_name'].'" class="form-control" placeholder="Course Name" required="">
                                </div>
                                <div class="col-md-12">
                                  <input type="text" name="co_desc" value="'.$vc['co_desc'].'" class="form-control" placeholder="Course Description" required="">
                                </div>
                                <div class="col-md-12">
                                  <input type="text" name="co_limit" value="'.$vc['co_limit'].'" class="form-control" placeholder="Course Limit" required="">
                                </div>
                                <div class="col-md-12">
                                                    <div class="form-group">
                                                    <label>Course Image</label>
                                                    <div class="input-group">
                                                        <span class="input-group-btn">
                                                            <span class="btn btn-default btn-file">
                                                                Browse… <input type="file" name="course_img" id="course_img" value="'.$vc['co_img'].'" required="">
                                                            </span>
                                                        </span>
                                                        <input type="text" class="form-control" readonly>
                                                    </div>
                                                    </div>
                                                </div>
                      </div>
                      
                    <div class="row">
                      <div class="col-md-12">
                      <button type="submit" name="update_course" class="btn btn-primary" style="width:100%;">Submit</button>
                        </div>
                    </div>

                    </form>
                </div>

                <div class="modal-footer">
                
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
              
            </div>
          </div>
 		';
 	}
 ?>

 
