<?php
$str="";$flag="";
if(isset($_COOKIE['flag'])){
	$flag=$_COOKIE['flag'];
}
else{$flag=$flag;}
  if(isset($_GET['id'])){
    $course = $this->model->GetCourseByID(array($_GET['id']));
      $unsched_student_course = $this->model->GetUnSchedStudenyByCourse($_GET['id']);
      $donesched_student_course = $this->model->GetDoneSchedStudenyByCourse($_GET['id']);
      $gen = ""; 
      $session = $this->model->GetOpenSessionByCourse(array($_GET['id']));
      if($session){
        $start = strtotime($session['start_date']);
        $end = strtotime($session['end_date']);
        $start_d = Date('F/d/Y', $start);
        $end_d = Date('F/d/Y', $end);

        $str = $start_d." - ".$end_d;
      }
      else{$str="<b>NOTE: Please set a new Session to set SCHEDULE.</b>";}
    }
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
        
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <div class="nav-tabs-navigation">
                                        <div class="nav-tabs-wrapper">
                                           <h3>MANAGE COURSES</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-content">

                                    <div class="row">
                                    	
                                        <div class="well col-lg-4" id=""  style="background-color: #e8eaea; padding: 20px; border: 1px;">
                                        <div class="card-header" data-background-color="purple">
		                                    <div class="nav-tabs-navigation">
		                                        <div class="nav-tabs-wrapper">
		                                           <h3>ADD TRAINER</h3>
		                                        </div>
		                                    </div>
		                                </div>
          										<form method="POST" enctype="multipart/form-data">
          										  
          										  <div class="row">
          											
          											<div class="col-md-12">
          												<input type="text" name="tr_fname" class="form-control" placeholder="First Name" required="">
          											</div>
          											<div class="col-md-12">
          												<input type="text" name="tr_lname" class="form-control" placeholder="Last Name" required="">
          											</div>
          											<div class="col-md-12">
                                  <select name="tr_gender" class="form-control">
                                    <option value="">Choose Gender</option>
                                    <option value="M">Male</option>
                                    <option value="F">Female</option>
                                  </select>
                                </div>
                                <div class="col-md-12">
                                  <input type="text" name="tr_age" class="form-control" placeholder="Age" required="">
                                </div>
                                <div class="col-md-12">
                                  <input type="text" name="tr_contact" class="form-control" placeholder="Contact" required="">
                                </div>
                                <div class="col-md-12">
                                  <input type="text" name="tr_address" class="form-control" placeholder="Address" required="">
                                </div>
										  </div>
										  
										<div class="row">
											<div class="col-md-12">
										  <button type="submit" name="add_trainer" class="btn btn-primary" style="width:100%;">Submit</button>
										    </div>
										</div>

										</form>
										<div class="row">
											<div class="col-md-12">
										  
											<p>
											  <?php if($flag == "ok"){

												echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Register </div>';
											  }
											
											  ?>
											  
											</p>
											</div>
										</div>
                            
                           	</div>
                            <div class="col-lg-8" style="background-color: #f0f0f0; padding: 20px; border: 1px;">
                            	<div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <div class="nav-tabs-navigation">
                                        <div class="nav-tabs-wrapper">
                                            <ul class="nav nav-tabs" data-tabs="tabs">
                                                <li class="active">
                                                    <a href="#trainer" data-toggle="tab">
                                                    	Trainer
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                                <li class="">
                                                    <a href="#trainer-sched" data-toggle="tab">
                                                        Trainer Schedule
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                               <li class="">
                                                    <a href="#unactive-trainer" data-toggle="tab">
                                                      Unactive Trainer
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                            </ul>
                                            <!-- <i id="result" class="float-right">result</i> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="card-content" >
                                    <div class="tab-content">
                                       	<div class="tab-pane active" id="trainer">
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>NAME</th>
                                                        <th>GENDER</th>
                                                        <th>AGE</th>
                                                        <th>CONTACT</th>
                                                        <th>ADDRESS</th>
                                                        <th><span class="fa fa-cog"></span></th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                   		if(count($trainor) > 0){
                                                   			foreach ($trainor as $tr) {
                                                          if($tr['tr_active'] == 1){
                                                   				echo '
                                                   					<tr>
                                                   						
                                                   						<td>'.$tr['tr_fname'].' '.$tr['tr_lname'].'</td>
                                                   						<td>'.$tr['tr_gender'].'</td>
                                                   						<td>'.$tr['tr_age'].'</td>
                                                              <td>'.$tr['tr_contact'].'</td>
                                                              <td>'.$tr['tr_address'].'</td>
                                                   						<td><a data-toggle="modal" href="#trainer'.$tr['tr_id'].'" class="fa fa-edit"></a> <a id="'.$tr['tr_id'].'" href="#" class="delete-trainer fa fa-trash"></a></td>
                                                   					</tr>
                                                   				';
                                                   			}
                                                      }
                                                   		}
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                        <div class="tab-pane" id="trainer-sched">
                                            <div id="printTrainer">
                                                    <?php
                                                        $t_hours=0;
                                                        $enddate = "";
                                                        $stat="";
                                                   		if(count($trainor) > 0){
                                                   			foreach ($trainor as $tr) {
                                                          $tr_student = $this->model->GetTrainerStudent($tr['tr_id']);
                                                          if($tr['tr_active']==1){
                                                            $stat = '<button type="button" class="btn btn-xs btn-success">Active</button>';
                                                          }
                                                          else{
                                                            $stat = '<button type="button" class="btn btn-xs btn-danger">Unactive</button>';
                                                          }
                                                          $tr_course = $this->model->GetCourseByTrainer($tr['tr_id']);
                                                   				if(count($tr_course) > 0){
                                                            foreach ($tr_course as $trc) {
                                                              echo '<div class="panel panel-info">
                                                            <div class="panel-heading">NAME: '.$tr['tr_fname'].' '.$tr['tr_lname'].' <span class="pull-right">'.$stat.'</span><br>COURSE: '.$trc['co_name'].' </div>';
                                                            
                                                              
                                                           
                                                         
                                                                  $tr_sched = $this->model->GetTrainorScheduleByCourse($tr['tr_id'], $trc['co_id']);

                                                                  echo '<div class="panel-body">';
                                                                  if(count($tr_sched) > 0){

                                                     $t_hours=0;
                                                                    echo'<table class="table" id="enrolled-table" >
                                                                      <thead >
                                                                          <tr>
                                                                              <th>DAY</th>
                                                                              <th>TIME</th>
                                                                              <th>HOUR</th>
                                                                              <th><span class="fa fa-cog"></span></th>
                                                                          </tr>
                                                                      </thead>
                                                                     
                                                                      <tbody>';
                                                                    foreach ($tr_sched as $trs) {
                                                                      
                                      $start1 = strtotime($trs['start_date']);
                                                          
                                                          $start_d1 = Date('M/d/Y', $start1);

                                  $sdate = strtotime($trs['start_date']);
                                                        $startdate = strtotime($trs['tr_sched_day'], $sdate);
                                                        $startdate1 = strtotime($trs['tr_sched_day'], $sdate);
                                                        $t_hours += $trs['tr_hour'];
                                                        $hr_limit = $trc['hr_limit'] / 24;
                                                        $ddd =  $startdate1 + (86400 * $hr_limit) * 168 / $t_hours;
                              while ($startdate <= $ddd) {
                                $enddate = date("M/d/Y", $startdate);
                                $startdate = strtotime("+1 week", $startdate);
                              }
                                                                      echo'<tr>
                                                                          <td>'.$trs['tr_sched_day'].'</td>
                                                                          <td>'.$trs['tr_sched_start_time'].' - '.$trs['tr_sched_end_time'].'</td>
                                                                          <td>'.$trs['tr_hour'].'</td>
                                                                        </tr>';

                                                                    }
                                                                    echo'</tbody>
                                                                     </table>';

                                                                  }
                                                                  echo '<br><span class="pull-left"><a data-toggle="modal" href="#trainer_student'.$tr['tr_id'].'" class="btn btn-xs btn-info">Student Enrolled ('.count($tr_student).')</a></span>';
                                                                  echo '<span class="pull-right"><br>START: '.$start_d1.'<br>END: '.$enddate.'<br>HOURS: '.$t_hours.'</span>';
                                                                echo '</div><hr>';
                                                                
                                                            }
                                                            echo ' </div>';
                                                          }
                                                   			}
                                                   		}
                                                    ?>
                                                  
                                          
                                          </div>     
                                          <a class="btn btn-primary" href="#" id="print" onclick="javascript:printLayer('printTrainer')"><i class="fa fa-print"> Print</i></a> 
                                        </div>
                                        <div class="tab-pane" id="unactive-trainer">
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>NAME</th>
                                                        <th>GENDER</th>
                                                        <th>AGE</th>
                                                        <th>CONTACT</th>
                                                        <th>ADDRESS</th>
                                                        <th><span class="fa fa-cog"></span></th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                      if(count($trainor) > 0){
                                                        foreach ($trainor as $tr) {
                                                          if($tr['tr_active'] == 0){
                                                          echo '
                                                            <tr>
                                                              
                                                              <td>'.$tr['tr_fname'].' '.$tr['tr_lname'].'</td>
                                                              <td>'.$tr['tr_gender'].'</td>
                                                              <td>'.$tr['tr_age'].'</td>
                                                              <td>'.$tr['tr_contact'].'</td>
                                                              <td>'.$tr['tr_address'].'</td>
                                                              <td><a id="'.$tr['tr_id'].'" href="#" class="activate-trainer btn btn-xs btn-danger">Activate</a></td>
                                                            </tr>
                                                          ';
                                                        }
                                                      }
                                                      }
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                        </div>
                                        
                                </div>
                            </div>
                            </div>
                             </div>
                                     	</div>
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>

 <?php 
 	foreach ($trainor as $trainer) {

    $tr = $this->model->GetTrainorByID(array($trainer['tr_id']));
    $tr_student = $this->model->GetTrainerStudent($tr['tr_id']);
 		echo '
 			<div class="modal fade" id="trainer'.$trainer['tr_id'].'" role="dialog" style="margin-top: -70px;">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">UPDATE COURSE</h4>
                </div>
                <form method="POST" enctype="multipart/form-data">
                <div class="modal-body" >
                                
                                <div class="row">
                                
                                <div class="col-md-12">
                                  <input type="hidden" name="tr_id" value="'.$tr['tr_id'].'" >
                                  <input type="text" name="tr_fname" value="'.$tr['tr_fname'].'" class="form-control" placeholder="First Name" required="">
                                </div>
                                <div class="col-md-12">
                                  <input type="text" name="tr_lname" value="'.$tr['tr_lname'].'" class="form-control" placeholder="Last Name" required="">
                                </div>
                                <div class="col-md-12">
                                  <select name="tr_gender" class="form-control">
                                    <option value="">Choose Gender</option>';
                                    if($tr['tr_gender'] == "M"){
                                      echo '<option value="M" selected>Male</option>';
                                    }
                                    else{echo '<option value="M">Male</option>';}
                                    if($tr['tr_gender'] == "F"){
                                      echo '<option value="F" selected>Female</option>';
                                    }
                                    else{echo '<option value="F">Female</option>';}
                                  echo '</select>
                                </div>
                                <div class="col-md-12">
                                  <input type="text" name="tr_age" value="'.$tr['tr_age'].'" class="form-control" placeholder="Age" required="">
                                </div>
                                <div class="col-md-12">
                                  <input type="text" name="tr_contact" value="'.$tr['tr_contact'].'" class="form-control" placeholder="Contact" required="">
                                </div>
                                <div class="col-md-12">
                                  <input type="text" name="tr_address" value="'.$tr['tr_address'].'" class="form-control" placeholder="Address" required="">
                                </div>
                      </div>
                   

                    
                </div>

                <div class="modal-footer">
                <button type="submit" name="update_trainer" class="btn btn-primary">Update</button>
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
                </form>
              </div>
              
            </div>
          </div>
 		';

    echo '
      <div class="modal fade" id="trainer_student'.$trainer['tr_id'].'" role="dialog" style="margin-top: -70px;">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Student Enrolled</h4>
                </div>
                <div class="modal-body" >
                  <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>NAME</th>
                                                        <th>GENDER</th>
                                                        <th>AGE</th>
                                                        <th>CONTACT</th>
                                                        <th>ADDRESS</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>';
                                                      if(count($tr_student) > 0){
                                                        foreach ($tr_student as $tr_stud) {
                                                          echo '
                                                            <tr>
                                                              
                                                              <td>'.$tr_stud['en_fname'].' '.$tr_stud['en_lname'].'</td>
                                                              <td>'.$tr_stud['en_gender'].'</td>
                                                              <td>'.$tr_stud['en_age'].'</td>
                                                              <td>'.$tr_stud['en_contact'].'</td>
                                                              <td>'.$tr_stud['en_num_street'].', '.$tr_stud['en_barangay'].', '.$tr_stud['en_city'].' City, '.$tr_stud['en_province'].'</td>
                                                              
                                                            </tr>
                                                          ';
                                                        }
                                                      
                                                      }
                                               
                                                  
                                                    
                                                echo'</tbody>
                                            </table>
                </div>

                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
              
            </div>
          </div>
    ';
 	}
 ?>

 
