<?php
$str="";$flag="";
if(isset($_COOKIE['flag'])){
	$flag=$_COOKIE['flag'];
}
else{$flag=$flag;}
  if(isset($_GET['id'])){
    $course = $this->model->GetCourseByID(array($_GET['id']));
      $unsched_student_course = $this->model->GetUnSchedStudenyByCourse($_GET['id']);
      $donesched_student_course = $this->model->GetDoneSchedStudenyByCourse($_GET['id']);
      $gen = ""; 
      $session = $this->model->GetOpenSessionByCourse(array($_GET['id']));
      if($session){
        $start = strtotime($session['start_date']);
        $end = strtotime($session['end_date']);
        $start_d = Date('F/d/Y', $start);
        $end_d = Date('F/d/Y', $end);

        $str = $start_d." - ".$end_d;
      }
      else{$str="<b>NOTE: Please set a new Session to set SCHEDULE.</b>";}
    }

    $open_session = $this->model->GetSessionOpen();
    if(count($open_session) > 0){
    	foreach ($open_session as $os) {
    		$this->model->UpdateScheduleSession(array($os['session_id'], $os['co_id']));
    	}
    }
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
        
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <div class="nav-tabs-navigation">
                                        <div class="nav-tabs-wrapper">
                                           <h3>MANAGE SCHEDULE</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-content">

                                    <div class="row">
                                    	
                                        <div class="well col-lg-4" id=""  style="background-color: #e8edec; padding: 20px; border: 1px;">
                                        <div class="card-header" data-background-color="purple">
		                                    <div class="nav-tabs-navigation">
		                                        <div class="nav-tabs-wrapper">
		                                           <h3>ADD SCHEDULE</h3>
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="row">
		                                	<div class="col-md-12">
		                                	<form method="POST">
		                                		<select id="trainor" name="tr_id" class="form-control" required="">
		                                    			<option value="">Choose Trainer</option>
		                                    			<?php
		                                    				if(count($trainor) > 0){
		                                    					foreach ($trainor as $tr) {
		                                    						if(isset($_GET['tr_id'])){

		                                    						
		                                    						if($_GET['tr_id'] == $tr['tr_id']){
		                                    							echo '<option value="'.$tr['tr_id'].'" selected>'.$tr['tr_fname'].'  '.$tr['tr_lname'].'</option>';
		                                    						}
		                                    						else{
		                                    							echo '<option value="'.$tr['tr_id'].'">'.$tr['tr_fname'].'  '.$tr['tr_lname'].'</option>';
		                                    						}
		                                    						}
		                                    						else{
		                                    							echo '<option value="'.$tr['tr_id'].'">'.$tr['tr_fname'].'  '.$tr['tr_lname'].'</option>';
		                                    						}
		                                    					}
		                                    				}
		                                    				
		                                    			?>
		                                    	</select>
		                                    	<select id="course" name="co_id" class="form-control" required="">
		                                    		<option value="">Select Course</option>
		                                    		<?php
		                                    			
		                                    			if(isset($_GET['tr_id'])){
		                                    				$tr_course = $this->model->GetTrainorCourseByID($_GET['tr_id']);
		                                    				foreach ($tr_course as $trc) {
		                                    					if(isset($_GET['co_id'])){
			                                    					if($_GET['co_id'] == $trc['co_id']){
			                                    						echo '<option value="'.$trc['co_id'].'" selected>'.$trc['co_name'].'</option>';
			                                    					}
			                                    					else{
			                                    						echo '<option value="'.$trc['co_id'].'">'.$trc['co_name'].'</option>';
			                                    					}
		                                    					}
		                                    			 	}
		                                    			 	
		                                    			}
		                                    			else{
		                                    				
		                                    				if(count($v_courses) > 0){
			                                    				foreach ($v_courses as $vc) {
			                                    					echo '<option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>';
			                                    				}
		                                    				}
		                                    			}
		                                    			
		                                    		?>	
		                                    	</select>
		                                		<select name="day" class="form-control" required="">
		                                			<option value="">Select Day</option>
		                                			<?php
		                                			$day = array("Sunday", "Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
			                                			for ($i=0; $i < count($day); $i++) { 
			                                				echo '<option value="'.$day[$i].'">'.$day[$i].'</option>';
			                                			}
		                                			?>
		                                		</select>
		                                		<div class="row">
		                                			<div class="col-md-6">
		                                				<label>Start Time: </label>
		                                				<input type="time" name="start_time" class="form-control" placeholder="Start Time" required="">
		                                			</div>
		                                			<div class="col-md-6">
		                                				<label>End Time: </label>
		                                				<input type="time" name="end_time" class="form-control" placeholder="End Time" required="">
		                                			</div>
		                                		</div>
		                                		
		                                		
		                                		<button type="submit" name="trainor_sched" class="btn btn-primary" style="width: 100%;">Submit</button>
		                                	</form>
		                                	<p>
		                                		<?php
		                                			if($flag == "tr_ok"){
                									echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Register </div>';
                									}
		                                		?>
		                                	</p>
		                                	</div>
		                                </div>
										<hr>
										 <div class="card-header" data-background-color="purple">
		                                    <div class="nav-tabs-navigation">
		                                        <div class="nav-tabs-wrapper">
		                                           <h3>SESSION</h3>
		                                        </div>
		                                    </div>
		                                </div>
		                                <div class="row">
		                                	<div class="col-md-12">
		                                	<form method="POST">
		                                		
		                                    	<select name="co_id" class="form-control" required="">
		                                    		<option value="">Select Course</option>
		                                    		<?php
		                                    			
		                                    			if(isset($_GET['tr_id'])){
		                                    				$tr_course = $this->model->GetTrainorCourseByID($_GET['tr_id']);
		                                    				foreach ($tr_course as $trc) {
		                                    					if(isset($_GET['co_id'])){
			                                    					if($_GET['co_id'] == $trc['co_id']){
			                                    						echo '<option value="'.$trc['co_id'].'" selected>'.$trc['co_name'].'</option>';
			                                    					}
			                                    					else{
			                                    						echo '<option value="'.$trc['co_id'].'">'.$trc['co_name'].'</option>';
			                                    					}
		                                    					}
		                                    			 	}
		                                    			 	
		                                    			}
		                                    			else{
		                                    				
		                                    				if(count($v_courses) > 0){
			                                    				foreach ($v_courses as $vc) {
			                                    					echo '<option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>';
			                                    				}
		                                    				}
		                                    			}
		                                    			
		                                    		?>	
		                                    	</select>
		                                		
		                                		<div class="row">
		                                			<div class="col-md-12">
		                                				<label>Start Time: </label>
		                                				<input type="date" name="start_time" class="form-control" placeholder="Start Time" required="">
		                                			</div>
		                                			
		                                		</div>
		                                		
		                                		
		                                		<button type="submit" name="start_session" class="btn btn-info">Start Session</button>
		                                		<a data-toggle="modal" href="#close_session" class="btn btn-default">Close Session</a>
		                                	</form>
		                                	<p>
		                                		<?php
		                                			if($flag == "ses_ok"){
                									echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Register </div>';
                									}
		                                		?>
		                                	</p>
		                                	
		                                	</div>
		                                </div>
                                    </div>
                           
                            <div class="col-lg-8" style="background-color: #f0f0f0; padding: 20px; border: 1px;">
                            	<div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <div class="nav-tabs-navigation">
                                        <div class="nav-tabs-wrapper">
                                            <ul class="nav nav-tabs" data-tabs="tabs">
                                                <!-- <li class="active">
                                                    <a href="#shortcut" data-toggle="tab"> SHORTCUT
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li> -->
                                                <li class="active">
                                                    <a href="#details" data-toggle="tab">
                                                    	DETAILS
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                               
                                            </ul>
                                            <!-- <i id="result" class="float-right">result</i> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="card-content" >
                                    <div class="tab-content">
                                       	<div class="tab-pane" id="shortcut">
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>COURSE</th>
                                                        <th>TRAINER</th>
                                                        <th>START DATE</th>
                                                        <th>END DATE</th>
                                                        <th>HOUR</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    
                                                    $stat="";$s_time="";$e_time="";$time="";$f_time=0;
                                                    if(count($monitor_sched) > 0){
                                                        
                                                        foreach ($monitor_sched as $sched) {
                                                        	$start1 = strtotime($sched['start_date']);
                                                          
                                                          $start_d1 = Date('M/d/Y', $start1);

													        $sdate = strtotime($sched['start_date']);
		                                                    $startdate = strtotime($sched['tr_sched_day'], $sdate);
		                                                    $startdate1 = strtotime($sched['tr_sched_day'], $sdate);
		                                                    $enddate = "";
		                                                    $hr_limit = $sched['hr_limit'] / 24;
		                                                   	$ddd =  $startdate1 + (86400 * $hr_limit) * 168 / $sched['t_hour'];
															while ($startdate <= $ddd) {
																$enddate = date("M/d/Y", $startdate);
															  $startdate = strtotime("+1 week", $startdate);
															}
			         							
                                                        	   echo '<tr data-toggle="modal" data-target="#tr'.$sched['tr_id'].'co'.$sched['co_id'].'">
                                                        		
                                                        		<td>'.$sched['co_name'].'</td>
                                                        		<td>'.$sched['tr_fname'].' '.$sched['tr_lname'].'</td>
                                                        		<td>'.$start_d1.'</td>
                                                        		<td>'.$enddate.'</td>
                                                        		<td>'.$sched['t_hour'].'</td>
                                                        	</tr>';
                                                            }                                                         
                                                          }
                                                        

                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                            
                                        </div>
                                        <div class="tab-pane active" id="details">
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>DAY</th>
                                                        <th>TIME</th>
                                                        <th>COURSE</th>
                                                        <th>TRAINER</th>
                                                        <th>HOUR</th>

                                                        <th><span class="fa fa-cog"></span></th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    
                                                    $stat="";$s_time="";$e_time="";$time="";$f_time=0;
                                                    if(count($detail_sched) > 0){
                                                        
                                                        foreach ($detail_sched as $sched) {
                                                        	if($sched['tr_sched_start_time'] < 12){
																$s_time = $sched['tr_sched_start_time']." AM";
															}
															else{
															   	$s_time = $sched['tr_sched_start_time']." PM";
															}
															if($sched['tr_sched_end_time'] < 12){
															  	$e_time = $sched['tr_sched_end_time']." AM";
															}
															else{
															  	$e_time = $sched['tr_sched_end_time']." PM";
															}
                                                        	   echo '<tr data-toggle="modal" data-target="#tr'.$sched['tr_id'].'co'.$sched['co_id'].'">
                                                        		<td>'.$sched['tr_sched_day'].'</td>
                                                        		<td>'.$s_time.' - '.$e_time.'</td>
                                                        		<td>'.$sched['co_name'].'</td>
                                                        		<td>'.$sched['tr_fname'].' '.$sched['tr_lname'].'</td>
                                                        		<td>'.$sched['tr_hour'].'</td>
                                                        		<td><a data-toggle="modal" href="#update-sched'.$sched['tr_sched'].'" class="fa fa-edit"></a> <a id="'.$sched['tr_sched'].'" href="#" class="delete-sched fa fa-trash"></a></td>
                                                        	</tr>';
                                                            }                                                         
                                                          }
                                                        

                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                            
                                        </div>
                                        </div>

                                        
                                        </div>
                                </div>
                            </div>
                            </div>
                             </div>
                                     	</div>
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>
<?php
	if(count($tr_sched) > 0){
		foreach ($tr_sched as $trs) {
			# code...
		
		echo '<div class="modal fade" id="update-sched'.$trs['tr_sched'].'" role="dialog">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content" style="width:100%; margin-left: -80px; margin-top: -80px;">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Update Schedule</h4>
                </div>
                <div class="modal-body" >
					<div class="row">
		                                	<div class="col-md-12">
		                                	<form method="POST">
		                                		<input type="hidden" name="tr_sched" value="'.$trs['tr_sched'].'">
		                                		<select  name="tr_id" class="form-control" required="">
		                                    			<option value="">Choose Trainer</option>';
		                                    			
		                                    				if(count($trainor) > 0){
		                                    					foreach ($trainor as $tr) {

		                                    						
		                                    						if($trs['tr_id'] == $tr['tr_id']){
		                                    							echo '<option value="'.$tr['tr_id'].'" selected>'.$tr['tr_fname'].'  '.$tr['tr_lname'].'</option>';
		                                    						}
		                                    						else{
		                                    							echo '<option value="'.$tr['tr_id'].'">'.$tr['tr_fname'].'  '.$tr['tr_lname'].'</option>';
		                                    						}
		                                    						
		                                    					}
		                                    				}
		                                    				
		                                    			
		                                    	echo '</select>
		                                    	<select  name="co_id" class="form-control" required="">
		                                    		<option value="">Select Course</option>';
		                                    		
		                                    				$tr_course = $this->model->GetTrainorCourseByID($trs['tr_id']);
		                                    				foreach ($tr_course as $trc) {
			                                    					if($trs['co_id'] == $trc['co_id']){
			                                    						echo '<option value="'.$trc['co_id'].'" selected>'.$trc['co_name'].'</option>';
			                                    					}
			                                    					else{
			                                    						echo '<option value="'.$trc['co_id'].'">'.$trc['co_name'].'</option>';
			                                    					}
		                                    					
		                                    			 	}
		                                    			 	
		                                    		
		                                    	echo '</select>
		                                		<select name="day" class="form-control" required="">
		                                			<option value="">Select Day</option>';
		                                			
		                                			$day = array("Sunday", "Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
			                                			for ($i=0; $i < count($day); $i++) { 
			                                				if($trs['tr_sched_day'] == $day[$i]){
			                                					echo '<option value="'.$day[$i].'" selected>'.$day[$i].'</option>';
			                                				}	
			                                				else{
			                                					echo '<option value="'.$day[$i].'">'.$day[$i].'</option>';
			                                				}
			                                			}
		                                		
		                                		echo '</select>
		                                		<div class="row">
		                                			<div class="col-md-6">
		                                				<label>Start Time: </label>
		                                				<input type="time" value="'.$trs['tr_sched_start_time'].'" name="start_time" class="form-control" placeholder="Start Time" required="">
		                                			</div>
		                                			<div class="col-md-6">
		                                				<label>End Time: </label>
		                                				<input type="time" value="'.$trs['tr_sched_end_time'].'" name="end_time" class="form-control" placeholder="End Time" required="">
		                                			</div>
		                                		</div>
		                                		
		                                		
		                                		<button type="submit" name="update_trainor_sched" class="btn btn-primary" style="width: 100%;">Update</button>
		                                	</form>
		                                	
		                                	</div>
		                                </div>
                </div>

                <div class="modal-footer" style="padding:20px">
                
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                 
                </div>
              </div>
              
            </div>
          </div>';
	}
}
	
?>

<!-- CLOSE -->
            <div id="close_session" class="modal fade" role="dialog">
             <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                 <form method="POST">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Open Class Session</h4>
                  </div>
                  <div class="modal-body">

                    <label>Select Course to close session</label>
                    <select name="course" class="form-control">
                        <option value="" >Select Course</option>
                        <?php
                            if(count($v_courses) > 0){
                                foreach ($v_courses as $vc) {
                                    echo '
                                        <option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>
                                    ';
                                }
                            }
                        ?>
                    </select>

                  </div>
                  <div class="modal-footer">
                    <button type="submit" name="close_session" class="btn btn-primary" >Close</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  </div>
                  </form>
                </div>

              </div>
            </div>