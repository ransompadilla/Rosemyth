<div class="content">
    <div class="container-fluid">
        <div class="row">

        	<div id="#">
                <table class="table" id="enrolled-table">
                    <thead>
                        <tr>
                        <th>REFNO</th><th>NAME</th><th>COURSE</th><th>STATUS</th>
                        </tr>
                        </thead>
                          <tbody>
                            <?php
                            $ref="";$stat="";
                                if(count($reg_payment) > 0){
                                  foreach ($reg_payment as $ens) {
                                     if($ens['ref_id'] == ""){
                                        $ref="WALK-IN";
                                    }
                                    else{$ref=$ens['ref_id'];}
                                    if($ens['en_status'] == 3){
                                        $stat = '<button data-toggle="modal" data-target="#modal_partial'.$ens['en_id'].'" class="btn btn-xs btn-default">Partial</button>';
                                                            }
                                    else if($ens['en_status'] == 0){
                                        $stat = '<button data-toggle="modal" data-target="#modal_payment'.$ens['en_id'].'" class="btn btn-xs btn-danger">Payment</button>';
                                    }
                                    if($ens['en_status'] == 0 || $ens['en_status'] == 3){
                                     echo '<tr>
                                            <td>'.$ref.'</td>
                                            <td>'.$ens['en_lname'].', '.$ens['en_fname'].'</td>
                                            <td>'.$ens['co_name'].'</td>
                                            <td>'.$stat.'</td>
                                            </tr>';
                                    }
                                    } 
                                }
                                                    
                            ?>
                      </tbody>
                      </table> 
                    </div>
        </div>
    </div>
</div>
 <?php
    for ($i=0; $i <= $max_en ; $i++) { 
        echo '<div class="modal fade" id="modal_payment'.$i.'" role="dialog">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Payment</h4>
                </div>
                <div class="modal-body" >
                    <h2>Partial or Fullypaid ?</h2>
                </div>

                <div class="modal-footer">
                    <form method="POST">
                      <input type="hidden" name="en_id" value="'.$i.'">
                      <button type="submit" name="partial" class="btn btn-default" >Partial</button>
                      <button type="submit" name="fullypaid" class="btn btn-info" >FullyPaid</button>
                    </form>
                </div>
              </div>
              
            </div>
          </div>';

          echo '<div class="modal fade" id="modal_partial'.$i.'" role="dialog">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">Payment</h4>
                </div>
                <div class="modal-body" >
                    <h2>Fullypaid ?</h2>
                </div>

                <div class="modal-footer">
                    <form method="POST">
                      <input type="hidden" name="en_id" value="'.$i.'">
                      <button type="submit" name="fullypaid" class="btn btn-info" >FullyPaid</button>
                    </form>
                </div>
              </div>
              
            </div>
          </div>';
    }
 ?>
 