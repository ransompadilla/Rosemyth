<?php 
	$flag=Null;
	$code="";
	$co_id="";

    if(isset($_COOKIE['flag'])){
        $flag = $_COOKIE['flag'];
    }
    else $flag=Null;

    $en_reg = $this->model->GetRegistrantByID(array($_GET['id']));
	?>
<!DOCTYPE html>
<html>
<head>
	<?php include "model/BootstrapHeader.php";?>
	<style type="text/css">
		
	</style>
</head>
<body style="background-color: #c0c0c0;">
	<div class="container">
	
    
    <div class="row">
	<div class="col-lg-11">
		<div style="margin-top: 100px;">
			<p>
              <?php if($flag == "ok"){

                echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Updated </div>';
              }
              
              ?>
              
            </p>
		<h1 class="well well-sm" style="text-align: center;">
    	<p class="small text-muted">Technical Education and Skills Development Authority<br>
    	Pangasiwaan sa Edukasyong Teknikal at Pagpapaunlad ng Kasanayan</p>
    	</h1>
    	</div>
				<form method="POST">
					<input type="hidden" name="en_id" value="<?php echo $_GET['id'];?>">
					<div class="col-sm-12">
					<div class="panel panel-info">
						<h1 class="well">LEARNERS PROFILE FORM</h1>
				      <div class="panel-heading">2. Manpower Profile:</div>
				      <div class="panel-body">
				      	<div class="row">
				      		<div class="col-sm-2 form-group">
								<label>2.1 &nbsp;&nbsp;&nbsp;NAME: </label>
								
							</div>
							<div class="col-sm-3 form-group">
								<label>First Name</label>
								<input type="text" name="fname" value="<?php echo $en_reg['en_fname']?>" placeholder="Enter First Name Here.." class="form-control" required="">
							</div>
							<div class="col-sm-3 form-group">
								<label>Last Name</label>
								<input type="text" name="lname" value="<?php echo $en_reg['en_lname']?>" placeholder="Enter Last Name Here.." class="form-control" required="">
							</div>
							<div class="col-sm-3 form-group">
								<label>Middle Name</label>
								<input type="text" name="mi" value="<?php echo $en_reg['en_mi']?>" placeholder="Enter Last Name Here.." class="form-control" required="">
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2 form-group">
								<label>2.2 &nbsp;&nbsp;&nbsp;Complete &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Permanent &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mailing &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Address: </label>
								
							</div>
							<div class="col-sm-3 form-group">
								<label>Number, Street</label>
								<input type="text" name="num-street" value="<?php echo $en_reg['en_num_street']?>" placeholder="Enter Number, Street Name Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>Barangay</label>
								<input type="text" name="barangay" value="<?php echo $en_reg['en_barangay']?>" placeholder="Enter Barangay Name Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>District</label>
								<input type="text" name="district" value="<?php echo $en_reg['en_district']?>" placeholder="Enter District Here.." class="form-control" required="">
							</div>	

						</div>
						<div class="row">
							<div class="col-sm-2 form-group">
								
							</div>
							<div class="col-sm-3 form-group">
								<label>City/Municipality</label>
								<input type="text" name="city" value="<?php echo $en_reg['en_city']?>" placeholder="Enter City/Municipality Name Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>Province</label>
								<input type="text" name="province" value="<?php echo $en_reg['en_province']?>" placeholder="Enter Province Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>Region</label>
								<input type="text" name="region" value="<?php echo $en_reg['en_region']?>" placeholder="Enter Region Here.." class="form-control" required="">
							</div>	
							
						</div>
						<div class="row">
							<div class="col-sm-2 form-group">
								
							</div>
							<div class="col-sm-3 form-group">
								<label>Email ADD/FB Account</label>
								<input type="email" name="emailAdd" value="<?php echo $en_reg['en_email_add']?>" placeholder="Enter Email Address/Facebook Account Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>Contact No</label>
								<input type="text" name="contact" value="<?php echo $en_reg['en_contact']?>" placeholder="Enter Contact# Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>Nationality</label>
								<input type="text" name="nationality" value="<?php echo $en_reg['en_nationality']?>" placeholder="Enter Nationality Here.." class="form-control" required="">
							</div>	
							
						</div>

				      </div>
				    </div>
				    <div class="panel panel-info">
				      <div class="panel-heading">3. Personal Information:</div>
				      <div class="panel-body">
				      	<div class="row">
							<div class="col-sm-4 form-group">
								<label>3.1 Sex</label>
								<div class="radio">
							      <label><input type="radio" <?php if($en_reg['en_gender'] == "M") echo "checked='checked'";?> name="gender" value="M">Male</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" <?php if($en_reg['en_gender'] == "F") echo "checked='checked'";?> name="gender" value="F">Female</label>
							    </div>
							</div>	
							<div class="col-sm-4 form-group">
								<label>3.2 Civil Status</label>
								<div class="radio">
							      <label><input type="radio" <?php if($en_reg['en_civilstatus'] == "Single") echo "checked='checked'";?> name="civilstatus" value="Single">Single</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="civilstatus" value="Married" <?php if($en_reg['en_civilstatus'] == "Married") echo "checked='checked'";?>>Married</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="civilstatus" value="Widow/er" <?php if($en_reg['en_civilstatus'] == "Widow/er") echo "checked='checked'";?>>Widow/er</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="civilstatus" value="Separated" <?php if($en_reg['en_civilstatus'] == "Separated") echo "checked='checked'";?>>Separated</label>
							    </div>
							</div>	
							<div class="col-sm-4 form-group">
								<label>3.3 Employment Status <i class="small text-muted">(before the training)</i></label>
								<div class="radio">
							      <label><input type="radio" name="empstatus" value="Employed" <?php if($en_reg['en_empstatus'] == "Employed") echo "checked='checked'";?>>Employed</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="empstatus" value="Unemployed" <?php if($en_reg['en_empstatus'] == "Unemployed") echo "checked='checked'";?>>Unemplyed</label>
							    </div>
							</div>	
							
						</div>
						<div class="row">
							
							<div class="col-sm-5 form-group">
								<label>3.4 Birth Date</label>
								<input type="date" name="bdate" value="<?php echo $en_reg['en_bdate']?>" placeholder="Enter Phone Number Here.." class="form-control" required="">
							</div>
							<div class="col-sm-5 form-group">
								<label>Age</label>
								<input type="text" name="age" value="<?php echo $en_reg['en_age']?>" placeholder="Enter Age Here.." class="form-control" required="">
							</div>
						</div>
						<div class="form-group">
							<label>3.4 Birth Place</label>
							<input type="text" name="place_birth" value="<?php echo $en_reg['en_birthplace']?>" placeholder="Enter Birth of Place Here.." class="form-control" required="">
						</div>
						<div class="row">
				      		<div class="col-sm-2 form-group">
								<label>3.4 &nbsp;&nbsp;&nbsp;PARENT'S &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;NAME: </label>
								
							</div>
							<div class="col-sm-5 form-group">
								<label>Father's First Name</label>
								<input type="text" name="fa_fname" value="<?php echo $en_reg['en_father_fname']?>" placeholder="Enter First Name Here.." class="form-control" required="">
							</div>
							<div class="col-sm-5 form-group">
								<label>Father's Last Name</label>
								<input type="text" name="fa_lname" value="<?php echo $en_reg['en_father_lname']?>" placeholder="Enter Last Name Here.." class="form-control" required="">
							</div>
							
						</div>
						<div class="row">
				      		<div class="col-sm-2 form-group">
								
							</div>
							<div class="col-sm-5 form-group">
								<label>Mother's First Name</label>
								<input type="text" name="mo_fname" value="<?php echo $en_reg['en_mother_fname']?>" placeholder="Enter First Name Here.." class="form-control" required="">
							</div>
							<div class="col-sm-5 form-group">
								<label>Mother's Last Name</label>
								<input type="text" name="mo_lname" value="<?php echo $en_reg['en_mother_lname']?>" placeholder="Enter Last Name Here.." class="form-control" required="">
							</div>
							
						</div>
				    </div>
				    </div>	
				    <div class="panel panel-info">
				      <div class="panel-heading">3.5 Educational Attainment Before the Training <i class="small text-muted">(Trainee)</i></div>
				      <div class="panel-body">
				      	<div class="row">
							<div class="col-sm-4 form-group">
								<div class="radio">
							      <label><input type="radio" name="edattain" value="NG Completed" <?php if($en_reg['en_edattainment'] == "NG Completed") echo "checked='checked'";?>>No Grade Completed</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="edattain" value="HS Graduate" <?php if($en_reg['en_edattainment'] == "HS Graduate") echo "checked='checked'";?>>High School Graduate</label>
							    </div>
								<div class="radio">
							      <label><input type="radio" name="edattain" value="Pre-School" <?php if($en_reg['en_edattainment'] == "Pre-School") echo "checked='checked'";?>>Pre-School <i class="small text-muted">(Nursery/Kinder/Prep)</i></label>
							    </div>
							</div>	
							<div class="col-sm-4 form-group">
							    <div class="radio">
							      <label><input type="radio" name="edattain" value="Post Secondary" <?php if($en_reg['en_edattainment'] == "Post Secondary") echo "checked='checked'";?>>Post Secondary</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="edattain" value="Elementary Undergraduate" <?php if($en_reg['en_edattainment'] == "Elementary Undergraduate") echo "checked='checked'";?>>Elementary Undergraduate</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="edattain" value="College Undergraduate" <?php if($en_reg['en_edattainment'] == "College Undergraduate") echo "checked='checked'";?>>College Undergrauate</label>
							    </div>
							</div>
							<div class="col-sm-4 form-group">
								<div class="radio">
							      <label><input type="radio" name="edattain" value="HS Undergraduate" <?php if($en_reg['en_edattainment'] == "HS Undergraduate") echo "checked='checked'";?>>High School Undergraduate</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="edattain" value="College Graduate or Higher" <?php if($en_reg['en_edattainment'] == "College or Higher") echo "checked='checked'";?>>College Graduate or Higher</label>
							    </div>
							</div>	
							
						</div>
				      </div>
				    </div>
				    <div class="panel panel-info">
				      <div class="panel-heading">4. Leaner/Trainee/Student <i class="small text-muted">(Clients) Classification</i></div>
				      <div class="panel-body">
				      	<div class="row">
							<div class="col-sm-4 form-group">
								<div class="radio">
							      <label><input type="radio" name="lts" value="PWDs" <?php if($en_reg['en_lts'] == "PWDs") echo "checked='checked'";?>>Persons with disabilities(PWDs)</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="lts" value="Displaced Worker" <?php if($en_reg['en_lts'] == "Displaced Worker") echo "checked='checked'";?>>Displaced Worker(Local)</label>
							    </div>
								<div class="radio">
							      <label><input type="radio" name="lts" value="OFW" <?php if($en_reg['en_lts'] == "OFW") echo "checked='checked'";?>>OFW</label>
							    </div>
							</div>	
							<div class="col-sm-4 form-group">
							    <div class="radio">
							      <label><input type="radio" name="lts" value="OFW Dependent" <?php if($en_reg['en_lts'] == "OFW Dependent") echo "checked='checked'";?>>OFW Dependent</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="lts" value="OFW Repatriate" <?php if($en_reg['en_lts'] == "OFW Repatriate") echo "checked='checked'";?>>OFW Repatriate</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="lts" value="Victims/Survivors of Human Trafficking" <?php if($en_reg['en_lts'] == "Victims/Survivors of Human Trafficking") echo "checked='checked'";?>>Victims/Survivors of Human Trafficking</label>
							    </div>
							</div>
							<div class="col-sm-4 form-group">
								<div class="radio">
							      <label><input type="radio" name="lts" value="Rebel Returnees" <?php if($en_reg['en_lts'] == "Rebel Returnees") echo "checked='checked'";?>>Rebel Returnees</label>
							    </div>
								<div class="radio">
							      <label><input type="radio" name="lts" value="Solo Parent" <?php if($en_reg['en_lts'] == "Solo Parent") echo "checked='checked'";?>>Solo Parent</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="lts" value="Others" <?php if($en_reg['en_lts'] == "Others") echo "checked='checked'";?>>Others</label>
							    </div>
							</div>	
							
						</div>
				      </div>
				    </div>
				    <div class="panel panel-info">
				      <div class="panel-heading">5. Taken NCAEIYP4SC before? </div>
				      <div class="panel-body">
				      	<div class="row">
				      		<div class="col-sm-2 form-group">
							    <div class="radio">
							      <label><input type="radio" name="taken_before" value="Yes" <?php if($en_reg['en_taken_where'] != "" && $en_reg['en_taken_when'] != "") echo "checked='checked'";?>>Yes</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="taken_before" value="No" <?php if($en_reg['en_taken_where'] == "" && $en_reg['en_taken_when'] == "") echo "checked='checked'";?>>No</label>
							    </div>
							    
							</div>
					      	<div class="col-sm-5 form-group">
								<label>Where:</label>
								<input type="text" name="taken_where" value="<?php echo $en_reg['en_taken_where']?>" placeholder="Enter Here.." class="form-control">
							</div>
							<div class="col-sm-5 form-group">
								<label>When:</label>
								<input type="text" name="taken_when" value="<?php echo $en_reg['en_taken_when']?>" placeholder="Enter Here.." class="form-control">
							</div>
						</div>
				      </div>
				    </div>
				    <div class="panel panel-info">
				      <div class="panel-heading">6. Name of Course/Qualification</div>
				      <div class="panel-body">
				      	<div class="row">
					      	<div class="col-sm-12 form-group">
								<label>Course/Qualification</label>
								<select name="course" class="form-control">
									<option value="">Select Course</option>
								
								<?php

									if(count($v_courses) > 0){
										foreach ($v_courses as $vc) {
											if($en_reg['co_id'] == $vc['co_id']){
												echo '<option value="'.$vc['co_id'].'" selected>'.$vc['co_name'].'</option>';
											}
											else{
												echo '<option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>';
											}
											
										}
									}
								?>
								</select>
							</div>
						</div>
				      </div>
				    </div>
				    <div class="panel panel-info">
				      <div class="panel-heading">Student/Scholar Voucher Number <i class="small text-muted">(For Scholar Only)</i></div>
				      <div class="panel-body">
				      	<div class="row">
					      	<div class="col-sm-6 form-group">
								<label>Voucher Number</label>
								<input type="text" name="voucher_number" value="<?php echo $en_reg['en_stud_voucher_no']?>" placeholder="Enter Voucher Number Here.." class="form-control">
							</div>
							<div class="col-sm-6 form-group">
								<label>Scholarship Package(TWSP, PESFA, etc.)</label>
								<input type="text" name="scholar_package" value="<?php echo $en_reg['en_scholar_package']?>" placeholder="Enter Scholar Package Here.." class="form-control">
							</div>
						</div>
				      </div>
				    </div>
					<button type="submit" name="update_registrant" class="btn btn-lg btn-info">Update</button>	

					<a class="btn btn-lg btn-danger" href="index.php?q=vocational/enrollies"> Cancel</a>	

					</div>
					
				</form> 
				
	</div>
	
	</div>

    </div>

	<?php include "model/BootstrapFooter.php";?>
</body>
</html>
