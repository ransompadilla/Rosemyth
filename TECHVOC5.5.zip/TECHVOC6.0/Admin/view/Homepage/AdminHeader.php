<!DOCTYPE html>
<html lang="en-us">
    <head>
      <?php include "model/BootstrapHeader.php";
      $a_home="";$a_enrollies="";$a_payment="";$manage_sched="";$drop_up="";$add_reg="";
      $activity="";
        if(isset($_GET['q'])){
            $flag = rtrim($_GET['q'], '/');
            $page = array("Home","vocational/enrollies", "vocational/payment", "vocational/manage-schedule", "vocational/drop", "vocational/add_registrant", "vocational/upload/activities");

                if($flag == $page[0]){
                    $a_home = "active";
                }
                else{$a_home=$a_home;}
                if($flag == $page[1]){
                    $a_enrollies = "active";
                }
                else{$a_enrollies=$a_enrollies;}
                if($flag == $page[2]){
                    $a_payment = "active";
                }
                else{$a_payment=$a_payment;}
                if($flag == $page[3]){
                    $manage_sched = "active";
                }
                else{$manage_sched=$manage_sched;}

                if($flag == $page[4]){
                    $drop_up = "active";
                }
                else{$drop_up=$drop_up;}

                if($flag == $page[5]){
                    $add_reg = "active";
                }
                else{$add_reg=$add_reg;}

                if($flag == $page[6]){
                    $activity = "active";
                }
                else{$activity=$activity;}

        }
        $session = $this->model->GetSessionID();
        $start1 = strtotime($session['start_date']);
        $end1 = strtotime($session['end_date']);
        $start = date("F/d/Y", $start1);
        $end = date("F/d/Y", $end1);
       
      ?>
      <script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
      <style type="text/css">
        #enrolled-table tr:hover{
          background-color: #e0e0e0; 
        }
        #course .card img:hover{
            border: 1px solid #a0a0a0;
        }

      </style>
     <script type="text/javascript">

        $(document).ready(function(){
            $("#myTable").hide();
            
            $('.btnPayment').click(function(){
                var en_id = $(this).attr('id');
                var xhttp = new XMLHttpRequest();
                  xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                      $('#'+en_id+'').removeClass('btn btn-danger').addClass('btn btn-success').text("PAID  ");
                    }
                  };
                  var page = "index.php?payment="+en_id;
                  xhttp.open("GET", page, true);
                  xhttp.send();
            });
            $('.btnDrop').click(function(){
                var en_id = $(this).attr('id');
                if(confirm("Are you sure do you want to DROP this STUDENT ? ")){
                  var xhttp = new XMLHttpRequest();
                  xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                      $('#'+en_id+'').removeClass('btn btn-danger').addClass('btn btn-success').text("Done");
                    }
                  };
                  var page = "index.php?drop="+en_id;
                  xhttp.open("GET", page, true);
                  xhttp.send();
                }
                else{return false;}
                
            });
			$("#course").change(function(){
				var co_id = $("#course").val();
                if(co_id != ""){
                    window.location = "index.php?q=vocational/manage-schedule&id="+co_id;
                }
                else {return false;}
				
			});
            $('#delete').click(function(){
             var en_id = $("#en_id").val();
			 
             if(confirm("Are you sure do you want to delete this registrant ? ")){
                window.location = "index.php?delete_registrant="+en_id;
             }
             else{return false;}
            });
            $('#un_active').click(function(){
             var en_id = $("#en_id").val();
             if(confirm("Are you sure do you want to ACTIVATE this registrant ? ")){
                window.location = "index.php?activate_registrant="+en_id;
             }
             else{return false;}
            });
            $(".btnDownload").click(function(){
				var id = $(this).attr("id");
               var page = "view/Homepage/vocational/excel.php?id="+id;
               window.location = page;
            });
            $(".delete-sched").click(function(){
                var sched_id = $(this).attr("id");
                if(confirm("Are you sure do you want to DELETE this SCHEDULE ? ")){
                window.location = "index.php?delete_sched="+sched_id;
             }
             else{return false;}
            });
            $("#search").keyup(function(){
                var count=0;
                search_table($(this).val());
                 
            });

            function search_table(value){
                $("#enrolled-table tr").each(function(){
                    var found = "false";
                    var count=0;
                    $(this).each(function(){
                        if($(this).text().toLowerCase().indexOf(value.toLowerCase()) >= 0){
                            found = "true";
                            
                        }
                    });
                    if(found == "true"){
                        $(this).show();
                        count = $("#enrolled-table tbody tr").length;
                    }
                    else{
                        $(this).hide();
                    }
                    $("#result").text(count);
                
                });

               
            }
            
        });

        
         function printLayer(layer){
            var generator = window.open(", name , ");
            var layetext = document.getElementById(layer);
            generator.document.write(layetext.innerHTML.replace("Print Me"));

            generator.document.close();
            generator.print();
            generator.close();
           }

        function setSession(user_id, session_id,co_id){
            if(session_id == ""){
                alert("No Session Open");
            }
            else{
                var xhttp = new XMLHttpRequest();
                xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                      $('#'+user_id+'').removeClass('btn btn-info').addClass('btn btn-success').text("Done");
                    }
                  };
                  var page = "index.php?session_id="+session_id+"&user_id="+user_id+"&co_id="+co_id;
                  xhttp.open("GET", page, true);
                  xhttp.send();
            }
            
        }
		

     </script>
    </head>
    <body>
    <div class="wrapper">
        <div class="sidebar" data-color="purple" data-image="../assets/img/sidebar-1.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

        Tip 2: you can also add an image using data-image tag
    -->
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                    TECHVOC
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="<?php echo $a_home;?>">
                        <a href="index.php?q=Home">
                            <i class="material-icons">home</i>
                            <p>Home</p>
                        </a>
                    </li>
                    <li class="<?php echo $a_enrollies;?>">
                        <a href="index.php?q=vocational/enrollies">
                            <i class="material-icons">person</i>
                            <p>Enrollies</p>
                        </a>
                    </li>
                    <li class="<?php echo $a_payment;?>">
                        <a href="index.php?q=vocational/payment">
                            <i class="material-icons">content_paste</i>
                            <p>Payment</p>
                        </a>
                    </li>
                    <li class="">
                        <a data-toggle="collapse" href="#session">
                            <i class="material-icons">code</i>
                            <p>Enrollment Session</p>
                        </a>
                        <ul id="session" class="collapse list-group">
                          <li data-toggle="modal" data-target="#open_session" class="list-group-item"><span style="margin-left: 50px;">Open Session</span></li>
                          <li data-toggle="modal" data-target="#close_session" class="list-group-item"><span style="margin-left: 50px;">Close Session</span></li>
                        </ul>
                    </li>
					<li class="<?php echo $manage_sched;?>">
                        <a href="index.php?q=vocational/manage-schedule">
                            <i class="material-icons">content_paste</i>
                            <p>Manage Schedule</p>
                        </a>
                    </li>
                    <li class="<?php echo $drop_up;?>">
                        <a href="index.php?q=vocational/drop">
                            <i class="material-icons">content_paste</i>
                            <p>Drop/Update</p>
                        </a>
                    </li>
                     <!--<li class="">
                        <a href="index.php?q=vocational/assessment">
                            <i class="material-icons">content_paste</i>
                            <p>Assessment</p>
                        </a>
                    </li>-->
                    <li class="<?php echo $add_reg;?>">
                        <a href="index.php?q=vocational/add_registrant">
                            <i class="material-icons">content_paste</i>
                            <p>Add Registrant</p>
                        </a>
                    </li>
                    <li class="<?php echo $activity;?>">
                        <a href="index.php?q=vocational/upload/activities">
                            <i class="material-icons">content_paste</i>
                            <p>Activities</p>
                        </a>
                    </li>
					<!--<li class="">
                        <a data-toggle="collapse" href="#album">
                            <i class="material-icons">code</i>
                            <p>Album</p>
                        </a>
                        <ul id="album" class="collapse list-group">
                          <li data-toggle="modal" data-target="#open_session" class="list-group-item"><span style="margin-left: 50px;">Add Album</span></li>
                          <li data-toggle="modal" data-target="#close_session" class="list-group-item"><span style="margin-left: 50px;">View Album</span></li>
                        </ul>
                    </li>-->
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <nav class="navbar navbar-transparent navbar-absolute">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#"></a>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="#pablo" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="material-icons">dashboard</i>
                                    <p class="hidden-lg hidden-md">Dashboard</p>
                                </a>
                            </li>
                            <li class="dropdown">
                                
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="material-icons">notifications</i>
                                    
                                        <?php $ctr=0;
                                            if($ctr > 0){
                                             echo '<span class="notification">'.$ctr.'</span>';
                                            }
                                        ?>
                                    
                                    <p class="hidden-lg hidden-md">Notifications</p>
                                </a>
                                <ul class="dropdown-menu">
                                    <?php
                                    
                                        if(count($registrants) % 10 == 0){
                                            echo '<li>
                                                    <a href="#">You have now reached '.count($registrants).' Registrants. </a>
                                                </li>';
                                                $ctr++;
                                        }
                                        if(count($enrolled_student) % 10 == 0){
                                            echo '<li>
                                                    <a href="#">You have now reached '.count($enrolled_student).' Enrolled Students. </a>
                                                </li>';
                                                $ctr++;
                                        }
                                         if(count($v_courses) > 0){
                                             foreach ($v_courses as $vc) {
                                                $en_count = $this->model->CountEnrolledByCourse($vc['co_id']);
                                                $reg_count = $this->model->CountRegistrantByCourse($vc['co_id']);
                                                if(count($en_count) % 10 == 0){
                                                    foreach ($en_count as $ec) {
                                                        echo '<li>
                                                        <a href="#">You have now reached '.count($en_count).' Enrolled Students on '.$ec['co_name'].' </a>
                                                    </li>';
                                                    }
                                                    $ctr++;
                                                     
                                                }
                                                if(count($reg_count) % 10 == 0){
                                                    foreach ($reg_count as $rc) {
                                                        echo '<li>
                                                        <a href="#">You have now reached '.count($reg_count).' Enrolled Students on '.$rc['co_name'].' </a>
                                                    </li>';
                                                    }
                                                    $ctr++;
                                                }
                                             }
                                         }
                                    ?>
                                    
                                   
                                    <li>
                                        <a href="#">See all</a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a href="#pablo" class="dropdown-toggle" data-toggle="dropdown">
                                    <?php echo $name; 
                                        if($adminInfo['admin_img'] != ""){
                                            echo ' &nbsp;<img class="img-circle" src="'.$adminInfo['admin_img'].'" style="width: 25px; height:25px;"/>';
                                        }
                                        else{
                                            echo ' &nbsp;<i class="material-icons">person</i>';
                                        }
                                    ?>
                                    
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="index.php?q=profile/profile">Profile</a>
                                    </li>
                                    <li>
                                        <a href="index.php?logout=1">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <form class="navbar-form navbar-right">
                            <div class="form-group  is-empty">
                                <input type="search" id="search" class="form-control"  placeholder="Search">
                                <span class="material-input"></span>
                            </div>
                            <button type="button" class="btn btn-white btn-round btn-just-icon">
                                <i class="material-icons">search</i>
                                <div class="ripple-container"></div>
                            </button>
                        </form>
                    </div>
                </div>
            </nav>
            <!-- OPEN -->
            <div id="open_session" class="modal fade" role="dialog">
              <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                 <form method="POST">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Open Class Session</h4>
                  </div>
                  <div class="modal-body">

                    <label>Course</label>
                    <select name="course" class="form-control">
                        <option value="" >Select Course</option>
                        <?php
                            if(count($v_courses) > 0){
                                foreach ($v_courses as $vc) {
                                    echo '
                                        <option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>
                                    ';
                                }
                            }
                        ?>
                    </select>

                    <label>Start Training Date</label>
                   <input type="date" name="start_date" class="form-control" required="">

                    <label>End Training Date</label>
                   <input type="date" name="end_date" class="form-control" required="">
                  
                  </div>
                  <div class="modal-footer">
                    <button type="submit" name="open_session" class="btn btn-primary" >Open</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  </div>
                  </form>
                </div>

              </div>
            </div>
            <!-- CLOSE -->
            <div id="close_session" class="modal fade" role="dialog">
             <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                 <form method="POST">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Open Class Session</h4>
                  </div>
                  <div class="modal-body">

                    <label>Select Course to close session</label>
                    <select name="course" class="form-control">
                        <option value="" >Select Course</option>
                        <?php
                            if(count($v_courses) > 0){
                                foreach ($v_courses as $vc) {
                                    echo '
                                        <option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>
                                    ';
                                }
                            }
                        ?>
                    </select>

                  </div>
                  <div class="modal-footer">
                    <button type="submit" name="close_session" class="btn btn-primary" >Close</button>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                  </div>
                  </form>
                </div>

              </div>
            </div>

