<?php
  $flag=Null;
    if(isset($_COOKIE['flag'])){
        $flag = $_COOKIE['flag'];
    }
    else $flag=Null;
?>
<!DOCTYPE html>
<html>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://fonts.googleapis.com/css?family=Raleway" rel="stylesheet">

<head>
<?php include 'model/BootstrapHeader.php';?>
    
</head>
<style>
* {
  box-sizing: border-box;
}

body {
  background: url("../Bootstrap/img/bg/contact-bg.jpg") no-repeat center top fixed;
  background-size: cover;
  color: #fff;
}

#regForm {
  
  margin: 100px auto;
  font-family: Raleway;;
  width: 70%;
  min-width: 300px;
}

h1 {
  text-align: center;  
}
input[type="text"],
input[type="email"],
input[type="date"],
input[type="password"],
select,
textarea {
  display: block;
  margin: 0 auto;
  width: 100%;
  background:transparent;
  border: 1px solid #fefefe;
  padding: 12px 15px;
  margin-bottom: 30px;
}
input {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
  color: #fff;

}
select {
  padding: 10px;
  width: 100%;
  font-size: 17px;
  font-family: Raleway;
  border: 1px solid #aaaaaa;
  color: #fff;
}


/* Mark input boxes that gets an error on validation: */
input.invalid {
  background-color: #ffdddd;
}

/* Hide all steps by default: */
.tab {
  display: none;
}

button {
  background-color: #4CAF50;
  color: #ffffff;
  border: none;
  padding: 10px 20px;
  font-size: 17px;
  font-family: Raleway;
  cursor: pointer;
}

button:hover {
  opacity: 0.8;
}
#btnLogin{
  background: transparent;
  border: 1px solid #fff;
  width: 100%;
  padding: 10px;
  transition: 0.5s background linear;
  font-weight: bold;

}
#prevBtn {
  background-color: #bbbbbb;
}

/* Make circles that indicate the steps of the form: */
.step {
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbbbbb;
  border: none;  
  border-radius: 50%;
  display: inline-block;
  opacity: 0.5;
}

.step.active {
  opacity: 1;
}

/* Mark the steps that are finished and valid: */
.step.finish {
  background-color: #4CAF50;
}
#formBox{
	width: 100%;
	padding:10px;
}
#formBox input{
	background-color: #fff;
	color: #444;
}
#btnLogin{
	background-color: #294c84;
}
</style>
<body style="background-image: url(../Bootstrap/img/call-to-action-bg.jpg);">
            
<div class=" container overlay-3" > 
  <p>
              <?php if($flag == "ok"){
                echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Added..</div>';
              }
              else if($flag == "used") {
                echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Email Already in used..</div>';
              }
              ?>
              
            </p>

<div id="formBox">
<form id="regForm"  method="POST" name="stepLogin" onsubmit="return validatePassword();" >
  <h1>Create Account</h1>
  <!-- One "tab" for each step in the form: -->
  <div class="tab">
    <p><input type="text" placeholder="First name..." oninput="this.className = ''" name="fname" ></p>
    <p><input type="text" placeholder="Last name..." oninput="this.className = ''" name="lname"></p>
    <p>
      <select  oninput="this.className = ''" name="gender">
        <option value="">Choose Gender</option>
        <option value="M">Male</option>
        <option value="F">Female</option>
      </select>
    </p>
    <p><input type="text" placeholder="Address..." oninput="this.className = ''" name="address"></p>
    <p><input type="text" placeholder="Age..." oninput="this.className = ''" name="age"></p>
    <p><input type="date"  oninput="this.className = ''" name="bdate"></p>
    <p><input type="text" placeholder="Phone..." oninput="this.className = ''" name="contact"></p>
  </div>
  
  <div class="tab">Login Info:
    <p><input type="email" placeholder="E-mail..." oninput="this.className = ''" name="email"></p>
    <p><input placeholder="Password..." oninput="this.className = ''" name="pword" type="password"></p>
    <p><input placeholder="Re-Type Password..." oninput="this.className = ''" name="r-pword" type="password"></p>
    <p id="validatePassword"></p>
  </div>
  <div style="overflow:auto;">
    <div style="float:right;">
      <button type="button" id="prevBtn" onclick="nextPrev(-1)">Previous</button>
     
      <button type="button" name="register_user" id="nextBtn" onclick="nextPrev(1)">Next</button>
    </div>
  </div>
  <!-- Circles which indicates the steps of the form: -->
  <div style="text-align:center;margin-top:40px;">
    <span class="step"></span>
    <span class="step"></span><br><br>

<a id="btnLogin" class="btn btn-primary" href="index.php?auth=Login">Login</a>
  </div>
</form>
</div>
</div>
<script>
var currentTab = 0; // Current tab is set to be the first tab (0)
showTab(currentTab); // Display the crurrent tab

function showTab(n) {
  // This function will display the specified tab of the form...
  var x = document.getElementsByClassName("tab");
  x[n].style.display = "block";
  //... and fix the Previous/Next buttons:
  if (n == 0) {
    document.getElementById("prevBtn").style.display = "none";
  } else {
    document.getElementById("prevBtn").style.display = "inline";
  }
  if (n == (x.length - 1)) {
    document.getElementById("nextBtn").innerHTML = "Submit";
  } else {
    document.getElementById("nextBtn").innerHTML = "Next";
  }
 
  //... and run a function that will display the correct step indicator:
  fixStepIndicator(n)
}

function nextPrev(n) {
  // This function will figure out which tab to display
  var x = document.getElementsByClassName("tab");
  // Exit the function if any field in the current tab is invalid:
  if (n == 1 && !validateForm()) return false;
  // Hide the current tab:
  x[currentTab].style.display = "none";
  // Increase or decrease the current tab by 1:
  currentTab = currentTab + n;
  // if you have reached the end of the form...
  if (currentTab >= x.length) {
    // ... the form gets submitted:
    
    document.getElementById("nextBtn").type = "submit";
    currentTab = currentTab-1;
  }
  // Otherwise, display the correct tab:
  showTab(currentTab);
}
function validatePassword(){
   var x = document.forms["stepLogin"]["pword"].value;
  var y = document.forms["stepLogin"]["r-pword"].value;
    if (x != y) {
        document.getElementById('validatePassword').innerHTML = "<div class='alert alert-priomary alert-dismissable'><button type='button' class='close' data-dismiss='alert'aria-hidden='true'>&times;</button>Warning ! Password did not much!</div>";
        return false;
    }
    else { 
      x=y;
    }
}
function validateForm() {
  // This function deals with validation of the form fields
  var x, y, i, valid = true;
  x = document.getElementsByClassName("tab");
  y = x[currentTab].getElementsByTagName("input");
  // A loop that checks every input field in the current tab:
  for (i = 0; i < y.length; i++) {
    // If a field is empty...
    if (y[i].value == "") {
      // add an "invalid" class to the field:
      y[i].className += " invalid";
      // and set the current valid status to false
      valid = false;
    }

   
  }
  // If the valid status is true, mark the step as finished and valid:
  if (valid) {
    document.getElementsByClassName("step")[currentTab].className += " finish";
  }
  return valid; // return the valid status
}

function fixStepIndicator(n) {
  // This function removes the "active" class of all steps...
  var i, x = document.getElementsByClassName("step");
  for (i = 0; i < x.length; i++) {
    x[i].className = x[i].className.replace(" active", "");
  }
  //... and adds the "active" class on the current step:
  x[n].className += " active";
}
</script>

</body>
</html>
