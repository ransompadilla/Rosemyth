<div class="content" style="margin-top: 150px;margin-bottom: 200px;">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-header" style="background-color: #3063ad;">
                                    <h4 class="title">Edit Profile</h4>
                                    <p class="category">Complete your profile</p>
                                </div>
                                <div class="card-content">
                                    <form method="POST" enctype="multipart/form-data">
                                        <div class="row">
                                           <input type="hidden" name="user_id" value="<?php echo $user_id?>" class="form-control">
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Fist Name</label>
                                                    <input type="text" name="fname" value="<?php echo $userInfo['user_fname']?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Last Name</label>
                                                    <input type="text" name="lname" value="<?php echo $userInfo['user_lname']?>" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Adress</label>
                                                    <input type="text" name="address" value="<?php echo $userInfo['user_address']?>" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                          <div class="col-md-3">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Gender</label>
                                                    <input type="text" name="gender" value="<?php echo $userInfo['user_gender']?>" class="form-control">
                                                </div>
                                            </div>
                                            <div class="col-md-9">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Contact</label>
                                                    <input type="text" name="contact" value="<?php echo $userInfo['user_contact']?>" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group label-floating">
                                                    <label class="control-label">Birth Date</label>
                                                    <input type="date" name="bdate" value="<?php echo $userInfo['user_bdate']?>" class="form-control">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label>Upload Image</label>
                                                    <div class="input-group">
                                                        <span class="input-group-btn">
                                                            <span class="btn btn-default btn-file">
                                                                Browse… <input type="file" name="fileToUpload" id="fileToUpload" required="">
                                                            </span>
                                                        </span>
                                                        <input type="text" class="form-control" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <button type="submit" name="update_user" class="btn btn-primary pull-right">Update Profile</button>
                                        <div class="clearfix"></div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card card-profile">
                                <div class="card-avatar">
                                    <a href="#pablo">

                                        <img class="img" src="<?php echo $userInfo['user_img']?>" />

                                    </a>
                                </div>
                                <div class="content">
                                    <h6 class="category text-gray"></h6>
                                    <h4 class="card-title"><?php echo $userInfo['user_fname']." ".$userInfo['user_lname'] ?></h4>
                                    <p class="card-content">
                                        Don't be scared of the truth because we need to restart the human foundation in truth And I love you like Kanye loves Kanye I love Rick Owens’ bed design but the back is...
                                    </p>
                                    <a href="index.php?q=Profile/change/email" class="btn btn-dander">Change Email</a><a href="index.php?q=Profile/change/password" class="btn btn-info ">Change Password</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>