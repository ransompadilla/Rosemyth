<?php
$course_name="";
  if(isset($_GET['id'])){
     $course = $this->model->GetCourseByID(array($_GET['id']));
     $course_name = $course['co_name'];
    
    }
    else{
      $course_name=$course_name;
    }
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
        	
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                   <h4 class="title">ACTIVITIES</h4>
                                    <!-- <p id="result"></p> -->
                                    <!-- <p class="category">Users (<?php echo count($all_users);?>)</p> -->
                                </div>
                                <div class="card-content">
                                    <div class="tab-content">
                                       <div class="row">
                                           <div class="well col-md-3"  style="padding: 20px;">
                                            <div>
                                                <b>ADD ACTIVITIES</b>
                                            </div>
                                            <form method="POST" enctype="multipart/form-data">
                                            <div class="row">
                                              <div class="col-md-12">
                                                    <div class="form-group label-floating">
                                                        <select name="co_id" class="form-control">
                                                        <option value="">Choose Course</option>
                                                        <?php
                                                          if(count($v_courses) > 0){
                                                            foreach($v_courses as $vc){
                                                              if($_GET['id'] == $vc['co_id']){
                                                                echo '<option value="'.$vc['co_id'].'"selected>'.$vc['co_name'].'</option>';
                                                              }
                                                              else{
                                                                echo '<option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>';
                                                              }
                                                              
                                                            }
                                                          }
                                                        ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group label-floating">
                                                        <label class="control-label">Title</label>
                                                        <input type="text" name="act_title" class="form-control" placeholder="Title" required="" >
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group label-floating">
                                                        <label class="control-label">Description</label>
                                                        <input type="text" name="act_desc" class="form-control" placeholder="Description" required="">
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                    <label>Upload Image</label>
                                                    <div class="input-group">
                                                        <span class="input-group-btn">
                                                            <span class="btn btn-default btn-file">
                                                                Browse… <input type="file" name="fileToUpload" id="fileToUpload" required="">
                                                            </span>
                                                        </span>
                                                        <input type="text" class="form-control" readonly>
                                                    </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                 <button class="btn btn-primary" type="submit" name="upload_activities" style="width: 100%;">Upload</button>
                                                </div> 
                                            </div>
                                                
                                            </form>
                                               
                                           </div>
                                           <div class="well col-md-9" style="background-color: #e8ebef;">
                                            <div class="content">
                                            <div class="container-fluid">
                                                <select name="co_id" class="form-control" id="activity_course">
                                                        <option value="">Choose Course</option>
                                                        <option value="0">ALL Courses</option>
                                                        <?php
                                                          if(count($v_courses) > 0){
                                                            foreach($v_courses as $vc){
                                                              if($_GET['id'] == $vc['co_id']){
                                                                echo '<option value="'.$vc['co_id'].'"selected>'.$vc['co_name'].'</option>';
                                                              }
                                                              else{
                                                                echo '<option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>';
                                                              }
                                                              
                                                            }
                                                          }
                                                        ?>
                                                        </select>
                                                <div class="row">
                                                  <h2 class="well" data-background-color="green"><?php echo $course_name;?></h2>
                                                  <?php
                                                  if(isset($_GET['id'])){
                                                    $act_course = $this->model->GetAllActivitiesByCOID($_GET['id']);
                                                    if(count($act_course) > 0){

                                                      foreach ($act_course as $a) {
                                                        echo '
                                                        <a href="#">

                                                          <div id="course" class="col-md-4">
                                                              <div class="card">
                                                                  <img src="'.$a['act_img'].'" class="img-fluid" alt="" style="width: 100%; height: 150px;">
                                                                  <div class="card-content">
                                                                      <h4 class="title">'.$a['act_title'].'</h4>
                                                                      <p class="category">
                                                                       '.$a['act_desc'].'
                                                                      </p>
                                                                  </div>
                                                                  
                                                              </div>
                                                          </div>
                                                        ';       
                                                      }
                                                    }
                                                  }
                                                  else{
                                                    if(count($act) > 0){

                                                      foreach ($act as $a) {
                                                        echo '
                                                        <a href="#">

                                                          <div id="course" class="col-md-4">
                                                              <div class="card">
                                                                  <img src="'.$a['act_img'].'" class="img-fluid" alt="" style="width: 100%; height: 150px;">
                                                                  <div class="card-content">
                                                                      <h4 class="title">'.$a['act_title'].'</h4>
                                                                      <p class="category">
                                                                       '.$a['act_desc'].'
                                                                      </p>
                                                                  </div>
                                                                  
                                                              </div>
                                                          </div>
                                                        ';       
                                                      }
                                                    }
                                                  }
                                                    
                                                  ?>
                                                </div>
                                              
                                            </div>
                                            
                                        </div>
                                           </div>
                                       </div>
                                            
                                            
                                    </div>
                                        
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>
    </div>
