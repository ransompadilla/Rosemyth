<!DOCTYPE html>
<html lang="en-us">
    <head>
      <?php include "model/BootstrapHeader.php";
      $a_home="";$a_enrollies="";$a_payment="";
        if(isset($_GET['q'])){
            $flag = rtrim($_GET['q'], '/');
            $page = array("Home","vocational/enrollies", "vocational/payment");

                if($flag == $page[0]){
                    $a_home = "active";
                }
                else{$a_home=$a_home;}
                if($flag == $page[1]){
                    $a_enrollies = "active";
                }
                else{$a_enrollies=$a_enrollies;}
                if($flag == $page[2]){
                    $a_payment = "active";
                }
                else{$a_payment=$a_payment;}
        }
        
      ?>
      <script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
      <style type="text/css">
        #enrolled-table tr:hover{
          background-color: #e0e0e0; 


        }


      </style>
     <script type="text/javascript">
        $(document).ready(function(){
            $("#myTable").hide();
            $('.btnPayment').click(function(){
                var en_id = $(this).attr('id');
                var xhttp = new XMLHttpRequest();
                  xhttp.onreadystatechange = function() {
                    if (this.readyState == 4 && this.status == 200) {
                      $('#'+en_id+'').removeClass('btn btn-danger').addClass('btn btn-success').text("PAID  ");
                    }
                  };
                  var page = "index.php?payment="+en_id;
                  xhttp.open("GET", page, true);
                  xhttp.send();
            });
        });

         function printLayer(layer){
            var generator = window.open(", name , ");
            var layetext = document.getElementById(layer);
            generator.document.write(layetext.innerHTML.replace("Print Me"));

            generator.document.close();
            generator.print();
            generator.close();
           }

        (function(document) {
            'use strict';

            var LightTableFilter = (function(Arr) {

                var _input;
                function _onInputEvent(e) {
                    _input = e.target;
                    var tables = document.getElementsByClassName(_input.getAttribute('data-table'));
                    Arr.forEach.call(tables, function(table) {
                        Arr.forEach.call(table.tBodies, function(tbody) {
                             Arr.forEach.call(tbody.rows, _filter);
                             
                        });
                    });
                }

                function _filter(row) {
                    var text = row.textContent.toLowerCase(), val = _input.value.toLowerCase();
                    row.style.display = text.indexOf(val) === -1 ? 'none' : 'table-row';

                }

                return {
                    init: function() {
                        var inputs = document.getElementsByClassName('light-table-filter');
                        Arr.forEach.call(inputs, function(input) {
                            input.oninput = _onInputEvent;
                        });
                    }
                };
            })(Array.prototype);

            document.addEventListener('readystatechange', function() {
                if (document.readyState === 'complete') {
                    LightTableFilter.init();
                }
            });

        })(document);

     </script>
    </head>
    <body>
    <div class="wrapper">
        <div class="sidebar" data-color="purple" data-image="../assets/img/sidebar-1.jpg">
            <!--
        Tip 1: You can change the color of the sidebar using: data-color="purple | blue | green | orange | red"

        Tip 2: you can also add an image using data-image tag
    -->
            <div class="logo">
                <a href="http://www.creative-tim.com" class="simple-text">
                    TECHVOC
                </a>
            </div>
            <div class="sidebar-wrapper">
                <ul class="nav">
                    <li class="<?php echo $a_home;?>">
                        <a href="index.php?q=Home">
                            <i class="material-icons">home</i>
                            <p>Home</p>
                        </a>
                    </li>
                    <li class="<?php echo $a_enrollies;?>">
                        <a href="index.php?q=vocational/enrollies">
                            <i class="material-icons">person</i>
                            <p>Enrollies</p>
                        </a>
                    </li>
                    <li class="<?php echo $a_payment;?>">
                        <a href="index.php?q=vocational/payment">
                            <i class="material-icons">content_paste</i>
                            <p>Payment</p>
                        </a>
                    </li>
                    
                </ul>
            </div>
        </div>
        <div class="main-panel">
            <nav class="navbar navbar-transparent navbar-absolute">
                <div class="container-fluid">
                    <div class="navbar-header">
                        <button type="button" class="navbar-toggle" data-toggle="collapse">
                            <span class="sr-only">Toggle navigation</span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                            <span class="icon-bar"></span>
                        </button>
                        <a class="navbar-brand" href="#">  </a>
                    </div>
                    <div class="collapse navbar-collapse">
                        <ul class="nav navbar-nav navbar-right">
                            <li>
                                <a href="#pablo" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="material-icons">dashboard</i>
                                    <p class="hidden-lg hidden-md">Dashboard</p>
                                </a>
                            </li>
                            <li class="dropdown">
                                
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                                    <i class="material-icons">notifications</i>
                                    
                                        <?php $ctr=0;
                                            if($ctr > 0){
                                             echo '<span class="notification">'.$ctr.'</span>';
                                            }
                                        ?>
                                    
                                    <p class="hidden-lg hidden-md">Notifications</p>
                                </a>
                                <ul class="dropdown-menu">
                                    <?php
                                    
                                        if(count($registrants) % 10 == 0){
                                            echo '<li>
                                                    <a href="#">You have now reached '.count($registrants).' Registrants. </a>
                                                </li>';
                                                $ctr++;
                                        }
                                        if(count($enrolled_student) % 10 == 0){
                                            echo '<li>
                                                    <a href="#">You have now reached '.count($enrolled_student).' Enrolled Students. </a>
                                                </li>';
                                                $ctr++;
                                        }
                                         if(count($v_courses) > 0){
                                             foreach ($v_courses as $vc) {
                                                $en_count = $this->model->CountEnrolledByCourse($vc['co_id']);
                                                $reg_count = $this->model->CountRegistrantByCourse($vc['co_id']);
                                                if(count($en_count) % 10 == 0){
                                                    foreach ($en_count as $ec) {
                                                        echo '<li>
                                                        <a href="#">You have now reached '.count($en_count).' Enrolled Students on '.$ec['co_name'].' </a>
                                                    </li>';
                                                    }
                                                    $ctr++;
                                                     
                                                }
                                                if(count($reg_count) % 10 == 0){
                                                    foreach ($reg_count as $rc) {
                                                        echo '<li>
                                                        <a href="#">You have now reached '.count($reg_count).' Enrolled Students on '.$rc['co_name'].' </a>
                                                    </li>';
                                                    }
                                                    $ctr++;
                                                }
                                             }
                                         }
                                    ?>
                                    
                                   
                                    <li>
                                        <a href="#">See all</a>
                                    </li>
                                </ul>
                            </li>
                            <li>
                                <a href="#pablo" class="dropdown-toggle" data-toggle="dropdown">
                                    <?php echo $name; 
                                        if($adminInfo['admin_img'] != ""){
                                            echo ' &nbsp;<img class="img-circle" src="'.$adminInfo['admin_img'].'" style="width: 25px; height:25px;"/>';
                                        }
                                        else{
                                            echo ' &nbsp;<i class="material-icons">person</i>';
                                        }
                                    ?>
                                    
                                </a>
                                <ul class="dropdown-menu">
                                    <li>
                                        <a href="index.php?q=profile/profile">Profile</a>
                                    </li>
                                    <li>
                                        <a href="index.php?logout=1">Logout</a>
                                    </li>
                                </ul>
                            </li>
                        </ul>
                        <form class="navbar-form navbar-right">
                            <div class="form-group  is-empty">
                                <input type="search" class="form-control light-table-filter" data-table="order-table"  placeholder="Search">
                                <span class="material-input"></span>
                            </div>
                            <button type="button" class="btn btn-white btn-round btn-just-icon">
                                <i class="material-icons">search</i>
                                <div class="ripple-container"></div>
                            </button>
                        </form>
                    </div>
                </div>
            </nav>
