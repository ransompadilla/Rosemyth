<div class="content">
    <div class="container-fluid">
        <div class="row">

        	<div id="#">
                <table class="order-table table" id="print-table">
                    <thead>
                        <tr>
                        <th>IDNO</th><th>NAME</th><th>COURSE</th><th>STATUS</th>
                        </tr>
                        </thead>
                          <tbody>
                            <?php
                                if(count($registrants) > 0){
                                  foreach ($registrants as $ens) {
                                     echo '<tr>
                                            <td>'.$ens['ref_id'].'</td>
                                            <td>'.$ens['en_lname'].', '.$ens['en_fname'].'</td>
                                            <td>'.$ens['co_name'].'</td>
                                            <td><button id="'.$ens['en_id'].'" class="btnPayment btn btn-danger">UNPAID</button></td>
                                            </tr>';
                                    } 
                                }
                                                    
                            ?>
                      </tbody>
                      </table> 
                    </div>
        </div>
    </div>
</div>
 