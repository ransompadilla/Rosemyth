  
  <!--==========================
    Footer
  ============================-->
  <footer id="footer" style="background-color: #0a2f63;">
    
    <div class="container" >
      <div class="copyright" style="height:5px;">
        &copy; Copyright <strong>2018 Benedicto College</strong>. All Rights Reserved
     <div class="pull-right">
       <a href = "view/ReadyLink/facilities.php">Facilities</a> | 
       <a href = "view/ReadyLink/history.php">History</a> | 
       <a href = "view/ReadyLink/article.php">Article</a>
     </div>
	  </div>
    </div>
  </footer><!-- #footer -->

        <?php include "model/BootstrapFooter.php";?>
        

  </body>
</html>