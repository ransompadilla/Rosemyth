 
 <!--==========================
      Portfolio Section
    ============================-->
    <section id="portfolio"  class="section-bg" style="margin-top:7%; ">
      <div class="container">

        <header class="section-header">
          <h3 class="section-title">Vocational Courses Offered</h3>
        </header>
<!-- 
        <div class="row">
          <div class="col-lg-12">
            <ul id="portfolio-flters">
              <li data-filter="*" class="filter-active">All</li>
              <li data-filter=".filter-app">App</li>
              <li data-filter=".filter-card">Card</li>
              <li data-filter=".filter-web">Web</li>
            </ul>
          </div>
        </div>
         -->
        <div class="row portfolio-container">
        <?php
            if(count($v_courses) > 0){
                foreach ($v_courses as $vc) {
                    echo '
                        <div class="col-lg-4 col-md-6 portfolio-item filter-app wow fadeInUp">
                            <div class="portfolio-wrap">
                              <figure>
                                <img src="'.$vc['co_img'].'" class="img-fluid" alt="" style="width: 100%;">
                               
                                <a href="index.php?q=Vocational/Course&code='.$vc['co_code'].'" class="link-details" title="More Details"><i class="ion ion-android-open"></i></a>
                              </figure>

                              <div class="portfolio-info">
                                <h4><a href="#">'.$vc['co_name'].'</a></h4>
                                <p>'.$vc['co_desc'].'</p>
                              </div>
                            </div>
                          </div>
                        ';
                }
            }
        ?>
        </div>
      </div>
    </section><!-- #portfolio -->
