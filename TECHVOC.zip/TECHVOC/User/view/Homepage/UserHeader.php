<!DOCTYPE html>
<html lang="en-us">
    <head>
      <?php include "model/BootstrapHeader.php";?>

  
  
  <script src="../Bootstrap/lib/jquery/jquery.min.js"></script>
  <script src="../Bootstrap/lib/bootstrap/js/bootstrap.min.js"></script>
    </head>
    <body style="background-color: #f0f0f0;">
      <header id="header" style="background-color: #a0a0a0;">
    <div class="container-fluid">

      <div id="logo" class="pull-left">
        <h1><a href="#intro" class="scrollto">TECHVOC</a></h1>
        <!-- Uncomment below if you prefer to use an image logo -->
        <!-- <a href="#intro"><img src="img/logo.png" alt="" title="" /></a>-->
      </div>

      <nav id="nav-menu-container">
        <ul class="nav-menu">
          <li class="menu-active"><a href="index.php?q=Home">Home</a></li>
          <li><a href="index.php?q=Vocational/Courses">Vocational Courses</a></li>
          <li><a href="#about"><?php echo $name;?></a></li>
          <li><a href="index.php?logout=1">Logout</a></li>
        </ul>
      </nav><!-- #nav-menu-container -->
    </div>
  </header><!-- #header -->

        
