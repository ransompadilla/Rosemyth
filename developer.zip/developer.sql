-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 01, 2018 at 05:15 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `developer`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_fname` varchar(25) DEFAULT NULL,
  `admin_lname` varchar(25) DEFAULT NULL,
  `admin_gender` char(1) DEFAULT NULL,
  `admin_address` varchar(50) DEFAULT NULL,
  `admin_contact` varchar(15) DEFAULT NULL,
  `admin_email` varchar(25) DEFAULT NULL,
  `admin_password` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_fname`, `admin_lname`, `admin_gender`, `admin_address`, `admin_contact`, `admin_email`, `admin_password`) VALUES
(1, 'Ransom', 'Carino', 'M', 'Talisay', NULL, NULL, NULL),
(2, 'Ransom', 'Carino', 'M', 'Talisay', '09234815395', 'ransom@yahoo.com', 'ransom');

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE IF NOT EXISTS `announcement` (
  `an_id` int(11) NOT NULL AUTO_INCREMENT,
  `an_details` varchar(999) DEFAULT NULL,
  `an_time` datetime DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`an_id`),
  KEY `code` (`co_id`),
  KEY `admin` (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `announcement`
--

INSERT INTO `announcement` (`an_id`, `an_details`, `an_time`, `co_id`, `admin_id`) VALUES
(1, 'Hi Students, There be no class tommorow', '2018-02-25 00:39:30', 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `course_offer`
--

CREATE TABLE IF NOT EXISTS `course_offer` (
  `co_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_code` int(11) NOT NULL,
  `co_name` varchar(25) DEFAULT NULL,
  `co_desc` varchar(100) DEFAULT NULL,
  `co_limit` int(11) DEFAULT NULL,
  `co_img` blob,
  PRIMARY KEY (`co_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `course_offer`
--

INSERT INTO `course_offer` (`co_id`, `co_code`, `co_name`, `co_desc`, `co_limit`, `co_img`) VALUES
(1, 1001, 'HouseKeeping NCII', 'HouseKeeping NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f686f7573652e6a7067),
(2, 1002, 'Cookery NCII', 'Cookery NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f636f6f6b2e6a7067),
(3, 1003, 'Food & Beverage Services ', 'Food & Beverage Services NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f6261722e6a7067),
(4, 1004, 'Bartending NCII', 'Bartending NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f6261722e6a7067),
(5, 1005, 'Welding (SMAW) NC I & II', 'Welding (SMAW) NC I & II', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f494d475f32303138303130385f3133323535355f427572737430312e6a7067),
(6, 1006, 'Computer System Servicing', 'Computer System Servicing NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f636f6d2e6a7067);

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

CREATE TABLE IF NOT EXISTS `enrollment` (
  `en_id` int(11) NOT NULL AUTO_INCREMENT,
  `en_fname` varchar(25) DEFAULT NULL,
  `en_lname` varchar(25) DEFAULT NULL,
  `en_city` varchar(25) DEFAULT NULL,
  `en_state` varchar(25) DEFAULT NULL,
  `en_zip` varchar(15) DEFAULT NULL,
  `en_gender` char(1) DEFAULT NULL,
  `en_civilstatus` varchar(15) DEFAULT NULL,
  `en_empstatus` varchar(15) DEFAULT NULL,
  `en_bdate` date DEFAULT NULL,
  `en_age` int(3) DEFAULT NULL,
  `en_birthplace` varchar(100) DEFAULT NULL,
  `en_edattainment` varchar(70) DEFAULT NULL,
  `en_lts` varchar(70) DEFAULT NULL,
  `en_stud_voucher_no` int(11) DEFAULT NULL,
  `en_scholar_package` varchar(70) DEFAULT NULL,
  `en_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ref_id` int(11) DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `en_status` int(1) DEFAULT NULL,
  PRIMARY KEY (`en_id`),
  KEY `ref_id` (`ref_id`),
  KEY `co_id` (`co_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `enrollment`
--

INSERT INTO `enrollment` (`en_id`, `en_fname`, `en_lname`, `en_city`, `en_state`, `en_zip`, `en_gender`, `en_civilstatus`, `en_empstatus`, `en_bdate`, `en_age`, `en_birthplace`, `en_edattainment`, `en_lts`, `en_stud_voucher_no`, `en_scholar_package`, `en_date`, `ref_id`, `co_id`, `en_status`) VALUES
(11, 'Recca Jane', 'Carino', 'Sibonga', 'Sibonga', '6060', 'F', 'Single', 'Unemplyed', '1997-03-03', 20, 'Sibonga', 'College Undergraduate', 'Others', 0, 'none', '2018-02-28 22:23:10', 10100004, 3, 1),
(12, 'Ransom', 'Carino', 'Talisay', 'Zone 4, Biasong', '6045', 'M', 'Single', 'Unemplyed', '1995-06-28', 22, 'ZN Del Norte', 'College Undergraduate', 'Others', 0, 'none', '2018-02-28 23:51:05', 10100001, 2, 1),
(13, 'Jhudey', 'Carino', 'Talisay', 'Zone 4, Biasong', '6045', 'M', 'Single', 'Unemplyed', '2001-03-30', 17, 'Mohon Talisay City Cebu', 'HS Undergraduate', 'Others', 0, 'none', '2018-02-28 23:52:22', 10100003, 2, 0),
(14, 'Rosemyth', 'Rosacena', 'Sibonga', 'Sibonga', '6060', 'F', 'Single', 'Unemplyed', '1995-03-03', 22, 'Sibonga', 'College Undergraduate', 'Others', 0, 'none', '2018-02-28 23:53:36', 10100002, 3, 0);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fname` varchar(25) DEFAULT NULL,
  `user_lname` varchar(25) DEFAULT NULL,
  `user_gender` char(1) DEFAULT NULL,
  `user_address` varchar(50) DEFAULT NULL,
  `user_bdate` date DEFAULT NULL,
  `user_contact` varchar(15) DEFAULT NULL,
  `user_email` varchar(25) DEFAULT NULL,
  `user_password` varchar(25) DEFAULT NULL,
  `user_img` blob,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_fname`, `user_lname`, `user_gender`, `user_address`, `user_bdate`, `user_contact`, `user_email`, `user_password`, `user_img`) VALUES
(10100001, 'Ransom', 'Carino', 'M', 'Biasong, Talisay City, Cebu', '1995-07-28', '09234185395', 'padillaransom@gmail.com', 'ransom', NULL),
(10100002, 'Rosemyth', 'Rosacena', 'F', 'Sanciangko', '1993-08-24', '09123242222', 'rose@yahoo.com', 'rose', NULL),
(10100003, 'Jhudey', 'Carino', 'M', 'Talisay', '2001-02-03', '09234815395', 'jhudey@yahoo.com', 'jhudey', NULL),
(10100004, 'Recca Jane', 'Valencia', 'F', 'Sibonga', '1997-03-31', '09123242222', 'recca@yahoo.com', 'recca', NULL);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `announcement`
--
ALTER TABLE `announcement`
  ADD CONSTRAINT `admin` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `code` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE;

--
-- Constraints for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD CONSTRAINT `co_id` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `ref_id` FOREIGN KEY (`ref_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
