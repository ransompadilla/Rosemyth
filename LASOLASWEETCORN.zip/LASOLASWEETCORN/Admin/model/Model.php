<?php
	include_once("Crud.php");
	class Model{
		private $crud;
		public function __construct(){
			$this->crud = new Crud();
		}
		public function RegisterAdmin($data){
            $query = "INSERT INTO admin(admin_name,admin_contact,admin_img,admin_username,admin_password) VALUES(?,?,?,?,?);";
            $this->crud->Insert($query,$data);
        }
        public function RegisterEmployee($data){
            $query = "INSERT INTO employee(emp_lname,emp_fname,emp_age,emp_gender,emp_address, emp_contact, dept_id,emp_position, active) VALUES(?,?,?,?,?,?,?,?,?);";
            $this->crud->Insert($query,$data);
        }
        public function RegisterDepartment($data){
            $query = "INSERT INTO department(dept_code,dept_name,active) VALUES(?,?,?);";
            $this->crud->Insert($query,$data);
        }
        public function RegisterProduct($data){
            $query = "INSERT INTO product(prod_code,prod_description,prod_qty,prod_price, active) VALUES(?,?,?,?,?);";
            $this->crud->Insert($query,$data);
        }
        ///
        public function ViewEmployeeInfo(){
            $query = "SELECT e.*, d.* FROM employee e INNER JOIN department d ON e.dept_id = d.dept_id WHERE e.active=1 ORDER BY e.emp_lname";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function ViewDepartmentInfo(){
            $query = "SELECT * FROM department WHERE active=1";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function ViewProductInfo(){
            $query = "SELECT * FROM product WHERE active=1";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function getCustomerDetails(){
            $query = "SELECT * FROM customer WHERE active=1";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        ///

        public function GetDeptName(){
            $query = "SELECT dept_id, dept_name FROM department WHERE active=1";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        ///
        ///UNACTIVE //
        public function ViewUnActiveEmployeeInfo(){
            $query = "SELECT e.*, d.* FROM employee e INNER JOIN department d ON e.dept_id = d.dept_id WHERE e.active=0 ORDER BY e.emp_lname";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function ViewUnActiveDepartmentInfo(){
            $query = "SELECT * FROM department WHERE active=0 ORDER BY dept_name";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        public function ViewUnActiveProductInfo(){
            $query = "SELECT * FROM product WHERE active=0 ORDER BY prod_id";
            $rows = $this->crud->SelectAll($query);
            return $rows;
        }
        //END OF UNACTIVE///
        ///UPDATE
        public function UpdateEmployee($data){
            $query = "UPDATE employee set emp_lname=?, emp_fname=?, emp_age=?, emp_gender=?, emp_address=?, emp_contact=?, dept_id=?, emp_position=? where emp_id=?";
           $this->crud->Update($query,$data);

        }
        public function UpdateProduct($data){
            $query = "UPDATE product set prod_code=?, prod_description=?, prod_qty=?, prod_price=? WHERE prod_id=?";
            $this->crud->Update($query,$data);

        }
        public function UpdateDepartment($data){
            $query = "UPDATE department set dept_code=?, dept_name=? WHERE dept_id=?";
            $this->crud->Update($query,$data);

        }
        ///
        //UNACTIVE//
        public function UnActiveEmployee($data){
            $query = "UPDATE employee set active=0 where emp_id=?";
            $this->crud->Update($query,$data);

        }
        public function UnActiveProduct($data){
            $query = "UPDATE product set active=0 where prod_id=?";
            $this->crud->Update($query,$data);

        }
        public function UnActiveDepartment($data){
            $query = "UPDATE department set active=0 where dept_id=?";
            $this->crud->Update($query,$data);

        }
        //UNACTIVE//
        //ACTIVE
        public function ActiveEmployee($data){
            $query = "UPDATE employee set active=1 where emp_id=?";
            $this->crud->Update($query,$data);

        }
        public function ActiveProduct($data){
            $query = "UPDATE product set active=1 where prod_id=?";
            $this->crud->Update($query,$data);

        }
        public function ActiveDepartment($data){
            $query = "UPDATE department set active=1 where dept_id=?";
            $this->crud->Update($query,$data);

        }
        //END OF ACTIVATION
        ///VALIDATION LOGIN
        public function ValidateAdminLogin($data){
            $query = "SELECT * FROM admin where admin_username=? and admin_password=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }

        public function ValidateEmail($data){
            session_start();
            $query = "SELECT * FROM admin where admin_username=? and admin_password=?";
            $row = $this->crud->Select($query,$data);
            if($row > 0){

                $_SESSION['admin_username'] = $row['admin_username'];

                header("Location: ../Libs/cooperative.php?page=Admin/admin");
            }
            else{
                echo "Invalid Username and password <a href='../Libs/cooperative.php?page=Admin/Login'> back </a>";
            }
        }
        //
        //LOGGING OUT/

        public function Admin_Logout(){
            if(isset($_COOKIE['admin_username'])){
                setcookie("admin_username",$_COOKIE['admin_username'], time() - 86400 ,"/");
                header("Location: index.php?auth=Login");
            }
        }
         public function FbLogout(){
            //include 'view/Auth/FbConfig.php';
            //session_start();
            if(isset($_SESSION['fb_token'])){
                $accessToken = null;
                var_dump($_SESSION['fb_token']);
                session_destroy();
            }
            
        }
        //

        ///ADMIN
        public function getAdminNameByEmail($data){
            $name="";
            $query = "SELECT * FROM admin where admin_username=?";
            $row = $this->crud->Select($query,$data);
            if($row > 0){
                $name = $row['admin_name'];
            }
            return $name;
        }
        public function getAdminImgByEmail($data){
            $img="";
            $query = "SELECT * FROM admin where admin_username=?";
            $row = $this->crud->Select($query,$data);
            if($row > 0){
                $img = $row['admin_img'];
            }
            return $img;
        }
        //sales inventory
        public function SalesInventory($date){
            $query = "SELECT o.prod_id , sum(o.order_qty) as qty , p.prod_code,p.prod_price FROM  orderline o JOIN product p ON o.prod_id=p.prod_id  WHERE p.active=1 and o.process=2 and o.date_order LIKE '%$date%' GROUP BY o.prod_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function Sales(){
            $query = "SELECT prod_code,prod_qty,prod_price FROM product WHERE active = 1;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //payment
        public function CustomerAccount(){
            $query = "SELECT c.cust_id,c.cust_lname,c.cust_fname,c.cust_img,p.card_no,p.card_type, sum(p.ack_payment) as total_payment FROM customer c LEFT JOIN payment p ON c.cust_id=p.cust_id WHERE c.active=1  GROUP BY c.cust_id;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetPayment($id){
            $payment=0;
            $query = "SELECT payment_amount FROM payment WHERE cust_id=$id and emp_id != ''";
            $row = $this->crud->SelectAll($query);
            if(count($row) > 0){
                foreach ($row as $key) {
                    $payment += $key['payment_amount'];
                }
            }
            return $payment;
        }
        public function GetGrossTotal($id){
            $total=0;$atotal=0;
            $query = "SELECT o.orderline_id,o.order_qty, p.prod_price,p.prod_code FROM orderline o INNER JOIN product p ON o.prod_id=p.prod_id WHERE o.cust_id=$id and o.status=1 ORDER BY p.prod_id;";
            $row = $this->crud->SelectAll($query);
            if(count($row) > 0){
                    foreach ($row as $k => $v) {
                        $total = $v['prod_price'] * $v['order_qty'];
                        $atotal+=$total;
                    }
            }
            return $atotal;
        }
        public function GetOrderList($id){
            $query = "SELECT DISTINCT(date_order) FROM orderline WHERE status=1 and cust_id=$id ORDER BY date_order;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        
        public function GetTotalAmountPerDate($date,$id){
                $total=0;$atotal=0;
            $query = "SELECT o.orderline_id,o.order_qty, p.prod_price,p.prod_code FROM orderline o INNER JOIN product p ON o.prod_id=p.prod_id WHERE o.date_order LIKE '%$date%' and o.cust_id=$id and o.status=1 ORDER BY p.prod_id;";
            $row = $this->crud->SelectAll($query);
            if(count($row) > 0){
                    foreach ($row as $k => $v) {
                        $total = $v['prod_price'] * $v['order_qty'];
                        $atotal+=$total;
                    }
            }
            return $atotal;
        }
        public function GetTotalSalesPerDay($date){
        $total=0;$atotal=0;
            $query = "SELECT o.orderline_id,o.order_qty, p.prod_price,p.prod_code FROM orderline o INNER JOIN product p ON o.prod_id=p.prod_id WHERE o.date_order LIKE '%$date%' and o.process=2 ORDER BY p.prod_id;";
            $row = $this->crud->SelectAll($query);
            if(count($row) > 0){
                    foreach ($row as $k => $v) {
                        $total = $v['prod_price'] * $v['order_qty'];
                        $atotal+=$total;
                    }
            }
            return $atotal;
        }
        public function getTotalSales(){
            $total=0;$atotal=0;
            $query = "SELECT o.orderline_id,o.order_qty, p.prod_price,p.prod_code FROM orderline o INNER JOIN product p ON o.prod_id=p.prod_id WHERE o.process=2 ORDER BY p.prod_id;";
            $row = $this->crud->SelectAll($query);
            if(count($row) > 0){
                    foreach ($row as $k => $v) {
                        $total = $v['prod_price'] * $v['order_qty'];
                        $atotal+=$total;
                    }
            }
            return $atotal;
        }
        public function GetPaymentSales(){
            $payment=0;
            $query = "SELECT payment_amount FROM payment WHERE emp_id != ''";
            $row = $this->crud->SelectAll($query);
            if(count($row) > 0){
                foreach ($row as $key) {
                    $payment += $key['payment_amount'];
                }
            }
            return $payment;
        }
        public function GetOrderInfo($date,$id){
            $query = "SELECT * FROM orderline o INNER JOIN product p ON o.prod_id=p.prod_id  WHERE o.date_order LIKE '%$date%' and o.cust_id=$id and o.status=1 ORDER BY p.prod_id ;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getAllOrderlist($date){
            $query = "SELECT * FROM orderline o INNER JOIN product p ON o.prod_id=p.prod_id  WHERE o.date_order LIKE '%$date%' and o.status=1 ORDER BY p.prod_id ;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getDateOrderList($data){
            $query = "SELECT DISTINCT(date_order) FROM orderline WHERE status=1 and date_order LIKE '%?%'";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        public function GetDistinctDateOrderlist(){
            $query = "SELECT DISTINCT(date_order) as dateorder FROM orderline WHERE status=1";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getMaxNoCustomerID(){
            $query = "SELECT max(cust_id) as max FROM customer;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getMinNoCustomerID(){
            $query = "SELECT min(cust_id) as min FROM customer;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetCustomerInfo($data){
            $query = "SELECT * FROM customer WHERE cust_id=? and active=1";
            $rows = $this->crud->Select($query,$data);
            return $rows;
        }
        public function getCustomerPayment($id){
            $query = "SELECT c.*, p.* FROM customer c JOIN payment p ON p.cust_id=c.cust_id WHERE p.cust_id=$id and p.emp_id != '' ORDER BY payment_date DESC;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function getStaffImgINPayment($p_id){
            $query = "SELECT e.emp_img,e.emp_nickname FROM employee e JOIN payment p ON p.emp_id=e.emp_id WHERE p.payment_id=$p_id;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
	}
?>