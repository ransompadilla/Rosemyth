<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 <!-- Bootstrap -->
 <link href="../Bootstrap/css/bootstrap-responsive.min.css" rel="stylesheet">
 <link href="../Bootstrap/css/bootstrap-responsive.css" rel="stylesheet">
 <link href="../Bootstrap/css/bootstrap.min.css" rel="stylesheet">
 <link href="../Bootstrap/css/bootstrap.css" rel="stylesheet">

 <!-- <link href="../Bootstrap/css/MyStyle.css" rel="stylesheet"> -->

 <link href="../Bootstrap/css/elegant-icons-style.css" rel="stylesheet" />
	<link href="../Bootstrap/css/widgets.css" rel="stylesheet">
	<link href="../Bootstrap/css/line-icons.css" rel="stylesheet">
	<link href="../Bootstrap/css/style-responsive.css" rel="stylesheet">
 <link href="../Bootstrap/media/css/jquery.dataTables.min.css" rel="stylesheet">
 <link href="../Bootstrap/media/css/jquery.dataTables.css" rel="stylesheet">
	<link href="../Bootstrap/css/jquery-jvectormap-1.2.2.css" rel="stylesheet">
	<link href="../Bootstrap/css/jquery-ui-1.10.4.min.css" rel="stylesheet">
  <link href="../Bootstrap/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">

  <link href="../Bootstrap/css/style.css" rel="stylesheet">
  
   <!-- <link href="../Bootstrap/css/css/sb-admin.css" rel="stylesheet"> -->

 


 <!--  <script src="../Bootstrap/js/scripts.js"></script>
  <script src="../Bootstrap/js/jquery.scrollTo.min.js"></script>
    <script src="../Bootstrap/js/jquery.nicescroll.js" type="text/javascript"></script>
    
    <script src="../Bootstrap/js/gritter.js" type="text/javascript"></script> -->