              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Department Record
                          </header>
                          <div class="table-responsive">
                            <table class="table">
                           <tbody>
                              <tr>
                                 <th><i class="icon_key_alt"></i>_CODE</th>
                                 <th><i class="fa fa-list"></i>_Description</th>
                                 <th><i class="icon_cogs"></i>_Action</th>
                              </tr>          
                                <?php
                                        if(count($department) > 0){
                                            
                                            foreach ($department as $key) { 
                                              if(isset($_COOKIE['update'])){
                                                  if($_COOKIE['update']==$key['dept_id']){
                                                    echo "<tr style='background-color:#e0e0e0;'>";
                                                    echo "<td>".$key['dept_id']."</td>";
                                                    echo "<td>".$key['dept_name']."</td>";
                                                    echo "<td><a href='index.php?homepage=Department/Update&dept_id=".$key['dept_id']."&dept_code=".$key['dept_id']."&dept_name=".$key['dept_name']."' class='glyphicon glyphicon-edit'> </a>   <a href='#' id='".$key['dept_id']."' class='deleteDepartment glyphicon glyphicon-trash'> </a></td>";
                                                    echo "</tr>";
                                                  }
                                                  else{
                                                    echo "<tr>";
                                                    echo "<td>".$key['dept_id']."</td>";
                                                    echo "<td>".$key['dept_name']."</td>";
                                                    echo "<td><a href='index.php?homepage=Department/Update&dept_id=".$key['dept_id']."&dept_code=".$key['dept_id']."&dept_name=".$key['dept_name']."' class='glyphicon glyphicon-edit'> </a>   <a href='#' id='".$key['dept_id']."' class='deleteDepartment glyphicon glyphicon-trash'> </a></td>";
                                                    echo "</tr>";
                                                  }
                                              }
                                              else{
                                                echo "<tr>";
                                                echo "<td>".$key['dept_id']."</td>";
                                                echo "<td>".$key['dept_name']."</td>";
                                                echo "<td><a href='index.php?homepage=Department/Update&dept_id=".$key['dept_id']."&dept_code=".$key['dept_id']."&dept_name=".$key['dept_name']."' class='glyphicon glyphicon-edit'> </a>   <a href='#' id='".$key['dept_id']."' class='deleteDepartment glyphicon glyphicon-trash'> </a></td>";
                                                echo "</tr>";
                                                
                                              }
                                            }
                                            
                                        }
                                ?>                    
                           </tbody>
                        </table>
                        </div>
                      </section>
                  </div>
              </div>