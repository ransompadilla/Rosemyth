
              <div class="row">
                  <div class="col-lg-12">
                  <section class="panel" >
                                                  <div class="panel-body progress-panel">
                                                    <div class="row">
                                                      <div class="col-lg-8 task-progress pull-left">
                                                          <h1>RECORD</h1>                                  
                                                      </div>
                                                      <div class="col-lg-4">
                                                        <span class="profile-ava pull-right">
                                                        <?php
                                                          $balance = $gross_rec - $amount;
                                                          echo "<b>Balance: $balance <br> 
                                                              Paid: $amount <br>
                                                              Gross: $gross_rec</b>";
                                                        ?>
                                                              
                                                        </span>                                
                                                      </div>
                                                    </div>
                                                  </div>
                                                  <?php
                                                  
                                                    foreach ($dis_date as $value) {
                                                        $d = strtotime($value['dateorder']);
                                                        $date = Date("F j, Y",$d);

                                                        $date1 = Date("y-m-d",$d);
                                                        if(!$stack->isFind($date1)){
                                                          $stack->push($date1);
                                                        }

                                                    }
                                                    for($i=0;$i<$stack->count();$i++){
                                                      $_date = $stack->itemsArray()[$i];
                                                      $_dd = strtotime($_date);
                                                      $_dateme = Date("F j, Y", $_dd);
                                                      $totalAmount = $this->model->GetTotalSalesPerDay($_date);
                                                      echo '<div class="panel panel-default" style="margin-bottom:0px;">
                                                          <div class="panel-heading">
                                                            <h4 class="panel-title" style="margin-right:20px;">
                                                            <a data-toggle="collapse" href="#'.$_date.'">'.$_dateme.'</a>
                                                              <i class="pull-right"><strong> P'.$totalAmount.'</strong></i>
                                                                
                                                            </h4>
                                                          </div>
                                                          <div id="'.$_date.'" class="panel-collapse collapse">';

                                              $sales_inv = $this->model->SalesInventory($_date);
                                                          echo '<table class="table table-stripped" >
                                                              <th>CODE</th><th>QTY</th><th>PRICE</th><th>SALES</th>';

                                                      if(count($sales_inv) > 0){
                                                        $total = 0;
                                                        foreach ($sales_inv as $key) { 
                                                          $sales = $key['qty'] * $key['prod_price'];
                                                          $total += $sales;
                                                          echo "<tr style='background-color:#fefefe;'>";
                                                              echo "<td>".$key['prod_code']."</td>";
                                                              echo "<td>".$key['qty']."</td>";
                                                              echo "<td>".$key['prod_price']."</td>";
                                                              echo "<td>".$sales."</td>";
                                                      }
                                                    
                                                          echo '<tr><td></td><td></td><td><strong>Total</strong></td><td><strong>'.$total.'</strong></td></tr>';
                                                          
                                                      }
                                                      echo '</table></div></div>';
                                                      }
                                                    
                                                  ?>
                                              </section>

                  </div>
              </div>