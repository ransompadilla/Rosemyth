
              <div class="row">
                  <div class="col-lg-12">
                      <section class="panel">
                          <header class="panel-heading">
                              Sales
                          </header>
                          <div class="table-responsive">
                            <table class="table">
                           <tbody>
                              <tr>
                                 <th><i class="icon_profile"></i>_PRODCODE</th>
                                 <th><i class="icon_profile"></i>_QTY</th>
                                 <th><i class="icon_calendar"></i>_PRICE</th>
                                 <th><i class="icon_profile"></i>_TOTAL</th>                 
                             </tr>          
                              <?php
                                    if(count($sales) > 0){
                                        
                                        foreach ($sales as $key) { 
                                          $tsales = $key['prod_qty'] * $key['prod_price'];
                                          echo "<tr style='background-color:#fefefe;'>";
                                              echo "<td>".$key['prod_code']."</td>";
                                              echo "<td>".$key['prod_qty']."</td>";
                                              echo "<td>".$key['prod_price']."</td>";
                                              echo "<td>".$tsales."</td>";
                                      }
                                    }
                            ?>                    
                           </tbody>
                        </table>
                        </div>
                      </section>
                  </div>
              </div>