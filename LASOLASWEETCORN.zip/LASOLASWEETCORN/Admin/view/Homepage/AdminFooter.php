<p>
	<?php if($flag == "ok"){
		echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Added..</div>';
	}
	?>
	
</p>
</div>
    <div class="col-sm-2">
      
    </div>
  </div>
</div>
<footer class="">
<hr>
<div class="">
  
  <p id="p_color" class="pull-left">&copy; 2017 College of Computer Studies, All Rights Reserved. No portion of this site may be 
  reproduced <br> or duplicate without the express permission of CCS.</p>
  <p class="pull-right"><a id="a_color" href="#">Privacy Policy </a>| <a id="a_color" href="#">Interest-Based Advertising </a> | <a id="a_color" href="#">Terms of Use </a> | <a id="a_color" href="#">Site of Map</a></p>
</div>
</footer>
<script src="../Bootstrap/js/bootstrap.min.js"></script>
    <script src="../Bootstrap/js/jquery.min.js"></script>
 <script src="../Bootstrap/js/bootstrap.js"></script>
<script src="../Bootstrap/js/jquery.js"></script>

</body>
</html>