<?php include"model/stack.php"; $stack=new Stack();
include 'view/Auth/FbConfig.php'; 
  if(!session_id()){
    session_start();
  }
      $username="";$name="";$img="";$flag="";$fbImg="";$fbName="";
    $department = $this->model->GetDeptName();
    $page = $_GET['homepage'];
    $explode = explode("/", $page);
    if(isset($_COOKIE['flag'])){
          $flag=$_COOKIE['flag'];
    }
    if(isset($_COOKIE['admin_username'])){
        $username = $_COOKIE['admin_username'];
         $name = $this->model->getAdminNameByEmail(array($username));
         $img = $this->model->getAdminImgByEmail(array($username));
    }
    else if($_SESSION['userData']){
      $name = $_SESSION['userData']['first_name']." ".$_SESSION['userData']['last_name'];
      $fbImg = $_SESSION['userData']['picture']['url'];
    }
    else{
      header('Location: index.php?auth=Login');
    }
    //$logoutUrl = $helper->getLogoutUrl(array('next'=>'index.php'));
?>

<!DOCTYPE html>
<html lang="en">
  <head>

  <?php include 'model/Bootstrap.php';?>
<script src="../Bootstrap/js/bootstrap.min.js"></script>
    <script src="../Bootstrap/js/jquery.min.js"></script>
 <script src="../Bootstrap/js/bootstrap.js"></script>
<script src="../Bootstrap/js/jquery.js"></script>
<script type="text/javascript">
  $(document).ready(function(){
    $('.deleteEmployee').click(function(){
      var id = $(this).attr('id');
      if(confirm("Do you want to Delete?")){
          window.location = "index.php?id="+id+"&page=employee";
      }
    });
    $('.deleteProduct').click(function(){
      var id = $(this).attr('id');
      if(confirm("Do you want to Delete?")){
          window.location = "index.php?id="+id+"&page=product";
      }
    });
    $('.deleteDepartment').click(function(){
      var id = $(this).attr('id');
      if(confirm("Do you want to Delete?")){
          window.location = "index.php?id="+id+"&page=department";
      }
    });
    //ACTIVATE
    $('.activeEmp').click(function(){
      var id = $(this).attr('id');
      if(confirm("Do you want to Activate?")){
          window.location = "index.php?id="+id+"&active=employee";
      }
    });
    $('.activeProd').click(function(){
      var id = $(this).attr('id');
      if(confirm("Do you want to Activate?")){
          window.location = "index.php?id="+id+"&active=product";
      }
    });
    $('.activeDept').click(function(){
      var id = $(this).attr('id');
      if(confirm("Do you want to Activate?")){
          window.location = "index.php?id="+id+"&active=department";
      }
    });
    //END OF ACTIVATION
  });

</script>

  </head>
<style>
  body{padding:50px;background-image: url('../images/bg1.jpg');
  background-repeat: no-repeat;
  background-position: center;
    background-size: cover;
  height: 100%;

    }
    #prof_img{height: 35px; width: 35px;}
    #wide-nav{padding:20px;}
    #listNames{background-color: #353a42;padding:20px;margin: 10px 50px 0px 0px;width: 100%;}
    #E1{padding: 5px 0px 5px 0px;}
    #F1-5{padding: 30px;}
    #listColor{background-color:#353a42;}
    li{list-style-type: none;font-family:verdana;}
    
    p{color:#cfcfd1;}
    #a_color{color:#1a7cdd;}
    #F1-5BG{background-color: #353a42;padding:20px;}
    #c_blue{color:#1287cc;}
    #p_color{color:#fefefe;}
    #iconSize{padding-left:2px;width: 30px;}
    #NascarIconSize{width: 102px;}
    .KL_42-50px{width: 28px;height: 28px;}
    #h-s{margin-top:5px;}
    #profile_img{height: 30px;width: 30px;}
    table th{background-color: #e0e0e0;}/*
    table tr{color:#000000;}*/
</style>

  <body class="" style="background-image: url('../Bootstrap/img/Product/img10.jpg');">
  <!-- container section start -->
     
<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
    <a class="navbar-brand" href="#">LASOLA's SWEETCORN</a>
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php?homepage=Home"><span class="fa fa-home"></span> Home</a></li>
        <li><a href="#"><?php if($img!=null) echo "<img id='prof_img' src='../Bootstrap/img/$img' class='img-circle'>";elseif ($fbImg!=null) {
          echo "<img id='prof_img' src='$fbImg' class='img-circle'>";
        } else echo"<span class='fa fa-user'> </span>";?> <?php echo $name;?></a></li>
        
        <li><a href="index.php?logout=1"><span class="glyphicon glyphicon-log-out"></span> Logout</a></li>
      </ul>
    </div>
  </div>
</nav>
<hr>
<hr>
<hr>
<div class="container-fluid">
  <div class="row">
    <div class="col-sm-3">
      <div class="panel-group">
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#employee">EMPLOYEE <span class="caret"></span></a>
      </h4>
    </div>
    <div id="employee" class="panel-collapse collapse <?php if($explode[0] == "Employee"){echo "in";}?>">
      
        <ul class="list-group">
          <li class="list-group-item " <?php if($explode[0] == "Employee" && $explode[1] == "Register") echo "style='background-color: #c0c0c0;' ";?> ><a class="<?php if($explode[0] == "Employee" && $explode[1] == "Register") echo "text-muted"; ?>" href="index.php?homepage=Employee/Register">Register Employee</a></li>
          <li class="list-group-item " <?php if($explode[0] == "Employee" && $explode[1] == "View") echo "style='background-color: #c0c0c0;' ";?>><a class="<?php if($explode[0] == "Employee" && $explode[1] == "View") echo "text-muted"; ?>" href="index.php?homepage=Employee/View">View Employee</a>
          </li>
          <li class="list-group-item " <?php if($explode[0] == "Employee" && $explode[1] == "UnActive") echo "style='background-color: #c0c0c0;' ";?>><a class="<?php if($explode[0] == "Employee" && $explode[1] == "UnActive") echo "text-muted"; ?>" href="index.php?homepage=Employee/UnActive">UnActive Employee</a>
          </li> 
        </ul>
        
<!--       <div class="panel-footer">Panel Footer</div> -->
    </div>
  </div>
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#product">PRODUCT <span class="caret"></span></a>
      </h4>
    </div>
    <div id="product" class="panel-collapse collapse <?php if($explode[0] == "Product"){echo "in";}?>">
        <ul class="list-group">
          <li class="list-group-item" <?php if($explode[0] == "Product" && $explode[1] == "Register") echo "style='background-color: #c0c0c0;'"; ?> ><a class="<?php if($explode[0] == "Product" && $explode[1] == "Register") echo "text-muted"; ?>" href="index.php?homepage=Product/Register">Register Product</a></li>
          <li class="list-group-item" <?php if($explode[0] == "Product" && $explode[1] == "View") echo "style='background-color: #c0c0c0;'"; ?> ><a class="<?php if($explode[0] == "Product" && $explode[1] == "View") echo "text-muted"; ?>" href="index.php?homepage=Product/View">View Product</a>
          </li> 
          <li class="list-group-item" <?php if($explode[0] == "Product" && $explode[1] == "UnActive") echo "style='background-color: #c0c0c0;'"; ?> ><a class="<?php if($explode[0] == "Product" && $explode[1] == "UnActive") echo "text-muted"; ?>" href="index.php?homepage=Product/UnActive">UnActive Product</a>
          </li> 
        </ul>
    </div>
  </div><!-- 
  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#department">DEPARTMENT <span class="caret"></span></a>
      </h4>
    </div>
    <div id="department" class="panel-collapse collapse <?php if($explode[0] == "Department"){echo "in";}?>">
        <ul class="list-group">
          <li class="list-group-item" <?php if($explode[0] == "Department" && $explode[1] == "Register") echo "style='background-color: #c0c0c0;'"; ?> ><a class="<?php if($explode[0] == "Department" && $explode[1] == "Register") echo "text-muted"; ?>" href="index.php?homepage=Department/Register">Register Department</a></li>
          <li class="list-group-item" <?php if($explode[0] == "Department" && $explode[1] == "View") echo "style='background-color: #c0c0c0;'"; ?> ><a class="<?php if($explode[0] == "Department" && $explode[1] == "View") echo "text-muted"; ?>" href="index.php?homepage=Department/View">View Department</a>
          </li> 
          <li class="list-group-item" <?php if($explode[0] == "Department" && $explode[1] == "UnActive") echo "style='background-color: #c0c0c0;'"; ?> ><a class="<?php if($explode[0] == "Department" && $explode[1] == "UnActive") echo "text-muted"; ?>" href="index.php?homepage=Department/UnActive">UnActive Department</a>
          </li> 
        </ul>
    </div>
  </div> -->

  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a data-toggle="collapse" href="#sales">SALES <span class="caret"></span></a>
      </h4>
    </div>
    <div id="sales" class="panel-collapse collapse <?php if($explode[0] == "Sales"){echo "in";}?>">
        <ul class="list-group">
          <li class="list-group-item" <?php if($explode[0] == "Sales" && $explode[1] == "Inventory") echo "style='background-color: #c0c0c0;'"; ?> ><a class="<?php if($explode[0] == "Sales" && $explode[1] == "Inventory") echo "text-muted"; ?>" href="index.php?homepage=Sales/Inventory">Inventory</a></li>
          <li class="list-group-item" <?php if($explode[0] == "Sales" && $explode[1] == "Sales") echo "style='background-color: #c0c0c0;'"; ?> ><a class="<?php if($explode[0] == "Sales" && $explode[1] == "Sales") echo "text-muted"; ?>" href="index.php?homepage=Sales/Sales">Sales</a>
          </li> 
          <!-- <li class="list-group-item" <?php if($explode[0] == "Department" && $explode[1] == "UnActive") echo "style='background-color: #c0c0c0;'"; ?> ><a class="<?php if($explode[0] == "Department" && $explode[1] == "UnActive") echo "text-muted"; ?>" href="index.php?homepage=Department/UnActive">Charge Sales</a>
          </li>  -->
        </ul>
    </div>
  </div>
<!-- PAYMENT -->

  <div class="panel panel-default">
    <div class="panel-heading">
      <h4 class="panel-title">
        <a href="index.php?homepage=CustomerAccount">CUSTOMER ACCOUNT </a>
      </h4>
    </div>
    
  </div>


</div>
    </div>
    <div class="col-md-8">
  <?php 	
    $crumbs = explode("/", $page);
            $count = count($crumbs);
            if($crumbs[0] != "Home"){
                echo '<ul class="breadcrumb">';
                  echo "<li><a href='../Libs/View.php?page=Home'>Home</a></li>";
                  for($i=0;$i<count($crumbs);$i++){
                    if($i == $count-1){
                         echo "<li><a class='text-muted' href='#'>".$crumbs[$i]."</a></li>";
                    }
                    else echo "<li><a href='#'>".$crumbs[$i]."</a></li>";
                  }
                echo '</ul>';
            }
            else {
                echo '<ul class="breadcrumb">';
                  echo "<li><a href='../Libs/View.php?page=Home'>Home</a></li>";
                  echo "<li></li>";
                echo '</ul>';
            }
  ?>
   