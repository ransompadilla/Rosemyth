<?php include '../Admin/model/Bootstrap.php';
	$flag=0;
    if(isset($_COOKIE['flag'])){
        $flag = $_COOKIE['flag'];
    }
    else $flag=0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    
	<link href="../Bootstrap/css/widgets.css" rel="stylesheet">
    <link href="../Bootstrap/css/style.css" rel="stylesheet">
    <link href="../Bootstrap/css/style-responsive.css" rel="stylesheet" />

    <script type="text/javascript">
 
   function validatePassword() {
        var form = document.forms["AuthForm"];
        var password = form["password"].value;
        var c_password = form["c_pass"].value;
        if (c_password != password) {
            document.getElementById('validatePassword').innerHTML = "<div class='alert alert-danger alert-dismissable'><button type='button' class='close' data-dismiss='alert'aria-hidden='true'>&times;</button>Warning ! Password did not much!</div>";
            return false;
        }
        else{
            password = c_password;
        }

    }
</script>
</head>

  <body class="login-img3-body">

    <div class="container">