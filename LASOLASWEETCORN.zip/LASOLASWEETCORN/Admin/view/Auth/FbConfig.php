<?php
session_start();
	require_once "../Facebook/autoload.php";
	$FB = new \Facebook\Facebook([
		'app_id' => '111930809553569',
		'app_secret' => '1601c58327fade49444d0c0cff60cce1',
		'default_graph_version' => 'v2.10',
		// 'persistent_data_handler'=>'session'
		]);
	$helper = $FB->getRedirectLoginHelper();
?>