<?php 
if(isset($_GET['data'])){                 

   header("Content-type: application/vnd.ms-excel; name='excel'");
header("Content-Disposition: attachment; filename=exportfile.xls");
header("Pragma: no-cache");
header("Expires: 0");
  echo $_GET['data'];
}
?>
