<!DOCTYPE html>
<html>
<head>
	<?php include "model/BootstrapHeader.php";?>
	<style type="text/css">
		
	</style>
</head>
<body style="background-color: #c0c0c0;">
	<div class="container">
	<?php 
	$flag=Null;
	$code="";
	$co_id="";

    if(isset($_COOKIE['flag'])){
        $flag = $_COOKIE['flag'];
    }
    else $flag=Null;

	?>
    
    <div class="row">
	<div class="col-lg-11">
		<div style="margin-top: 100px;">
			<p>
              <?php if($flag == "ok"){

                echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Register </div>';
              }
              
              ?>
              
            </p>
		<h1 class="well well-sm" style="text-align: center;">
    	<p class="small text-muted">Technical Education and Skills Development Authority<br>
    	Pangasiwaan sa Edukasyong Teknikal at Pagpapaunlad ng Kasanayan</p>
    	</h1>
    	</div>
				<form method="POST">
					
					<div class="col-sm-12">
					<div class="panel panel-info">
						<h1 class="well">LEARNERS PROFILE FORM</h1>
				      <div class="panel-heading">2. Manpower Profile:</div>
				      <div class="panel-body">
				      	<div class="row">
				      		<div class="col-sm-2 form-group">
								<label>2.1 &nbsp;&nbsp;&nbsp;NAME: </label>
								
							</div>
							<div class="col-sm-3 form-group">
								<label>First Name</label>
								<input type="text" name="fname" placeholder="Enter First Name Here.." class="form-control" required="">
							</div>
							<div class="col-sm-3 form-group">
								<label>Last Name</label>
								<input type="text" name="lname" placeholder="Enter Last Name Here.." class="form-control" required="">
							</div>
							<div class="col-sm-3 form-group">
								<label>Middle Name</label>
								<input type="text" name="mi" placeholder="Enter Last Name Here.." class="form-control" required="">
							</div>
						</div>
						<div class="row">
							<div class="col-sm-2 form-group">
								<label>2.2 &nbsp;&nbsp;&nbsp;Complete &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Permanent &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Mailing &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Address: </label>
								
							</div>
							<div class="col-sm-3 form-group">
								<label>Number, Street</label>
								<input type="text" name="num-street" placeholder="Enter Number, Street Name Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>Barangay</label>
								<input type="text" name="barangay" placeholder="Enter Barangay Name Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>District</label>
								<input type="text" name="district" placeholder="Enter District Here.." class="form-control" required="">
							</div>	

						</div>
						<div class="row">
							<div class="col-sm-2 form-group">
								
							</div>
							<div class="col-sm-3 form-group">
								<label>City/Municipality</label>
								<input type="text" name="city" placeholder="Enter City/Municipality Name Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>Province</label>
								<input type="text" name="province" placeholder="Enter Province Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>Region</label>
								<input type="text" name="region" placeholder="Enter Region Here.." class="form-control" required="">
							</div>	
							
						</div>
						<div class="row">
							<div class="col-sm-2 form-group">
								
							</div>
							<div class="col-sm-3 form-group">
								<label>Email ADD/FB Account</label>
								<input type="email" name="emailAdd" placeholder="Enter Email Address/Facebook Account Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>Contact No</label>
								<input type="text" name="contact" placeholder="Enter Contact# Here.." class="form-control" required="">
							</div>	
							<div class="col-sm-3 form-group">
								<label>Nationality</label>
								<input type="text" name="nationality" placeholder="Enter Nationality Here.." class="form-control" required="">
							</div>	
							
						</div>

				      </div>
				    </div>
				    <div class="panel panel-info">
				      <div class="panel-heading">3. Personal Information:</div>
				      <div class="panel-body">
				      	<div class="row">
							<div class="col-sm-4 form-group">
								<label>3.1 Sex</label>
								<div class="radio">
							      <label><input type="radio" name="gender" value="M">Male</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="gender" value="F">Female</label>
							    </div>
							</div>	
							<div class="col-sm-4 form-group">
								<label>3.2 Civil Status</label>
								<div class="radio">
							      <label><input type="radio" name="civilstatus" value="Single">Single</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="civilstatus" value="Married">Married</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="civilstatus" value="Widow/er">Widow/er</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="civilstatus" value="Separated">Separated</label>
							    </div>
							</div>	
							<div class="col-sm-4 form-group">
								<label>3.3 Employment Status <i class="small text-muted">(before the training)</i></label>
								<div class="radio">
							      <label><input type="radio" name="empstatus" value="Employed">Employed</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="empstatus" value="Unemplyed">Unemplyed</label>
							    </div>
							</div>	
							
						</div>
						<div class="row">
							
							<div class="col-sm-5 form-group">
								<label>3.4 Birth Date</label>
								<input type="date" name="bdate" placeholder="Enter Phone Number Here.." class="form-control" required="">
							</div>
							<div class="col-sm-5 form-group">
								<label>Age</label>
								<input type="text" name="age" placeholder="Enter Age Here.." class="form-control" required="">
							</div>
						</div>
						<div class="form-group">
							<label>3.4 Birth Place</label>
							<input type="text" name="place_birth" placeholder="Enter Birth of Place Here.." class="form-control" required="">
						</div>
						<div class="row">
				      		<div class="col-sm-2 form-group">
								<label>3.4 &nbsp;&nbsp;&nbsp;PARENT'S &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;NAME: </label>
								
							</div>
							<div class="col-sm-5 form-group">
								<label>Father's First Name</label>
								<input type="text" name="fa_fname" placeholder="Enter First Name Here.." class="form-control" required="">
							</div>
							<div class="col-sm-5 form-group">
								<label>Father's Last Name</label>
								<input type="text" name="fa_lname" placeholder="Enter Last Name Here.." class="form-control" required="">
							</div>
							
						</div>
						<div class="row">
				      		<div class="col-sm-2 form-group">
								
							</div>
							<div class="col-sm-5 form-group">
								<label>Mother's First Name</label>
								<input type="text" name="mo_fname" placeholder="Enter First Name Here.." class="form-control" required="">
							</div>
							<div class="col-sm-5 form-group">
								<label>Mother's Last Name</label>
								<input type="text" name="mo_lname" placeholder="Enter Last Name Here.." class="form-control" required="">
							</div>
							
						</div>
				    </div>
				    </div>	
				    <div class="panel panel-info">
				      <div class="panel-heading">3.5 Educational Attainment Before the Training <i class="small text-muted">(Trainee)</i></div>
				      <div class="panel-body">
				      	<div class="row">
							<div class="col-sm-4 form-group">
								<div class="radio">
							      <label><input type="radio" name="edattain" value="NG Completed">No Grade Completed</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="edattain" value="HS Graduate">High School Graduate</label>
							    </div>
								<div class="radio">
							      <label><input type="radio" name="edattain" value="Pre-School">Pre-School <i class="small text-muted">(Nursery/Kinder/Prep)</i></label>
							    </div>
							</div>	
							<div class="col-sm-4 form-group">
							    <div class="radio">
							      <label><input type="radio" name="edattain" value="Post Secondary">Post Secondary</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="edattain" value="Elementary Undergraduate">Elementary Undergraduate</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="edattain" value="College Undergraduate">College Undergrauate</label>
							    </div>
							</div>
							<div class="col-sm-4 form-group">
								<div class="radio">
							      <label><input type="radio" name="edattain" value="HS Undergraduate">High School Undergraduate</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="edattain" value="College Graduate or Higher">College Graduate or Higher</label>
							    </div>
							</div>	
							
						</div>
				      </div>
				    </div>
				    <div class="panel panel-info">
				      <div class="panel-heading">4. Leaner/Trainee/Student <i class="small text-muted">(Clients) Classification</i></div>
				      <div class="panel-body">
				      	<div class="row">
							<div class="col-sm-4 form-group">
								<div class="radio">
							      <label><input type="radio" name="lts" value="PWDs">Persons with disabilities(PWDs)</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="lts" value="Displaced Worker">Displaced Worker(Local)</label>
							    </div>
								<div class="radio">
							      <label><input type="radio" name="lts" value="OFW">OFW</label>
							    </div>
							</div>	
							<div class="col-sm-4 form-group">
							    <div class="radio">
							      <label><input type="radio" name="lts" value="OFW Dependent">OFW Dependent</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="lts" value="OFW Repatriate">OFW Repatriate</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="lts" value="Victims/Survivors of Human Trafficking">Victims/Survivors of Human Trafficking</label>
							    </div>
							</div>
							<div class="col-sm-4 form-group">
								<div class="radio">
							      <label><input type="radio" name="lts" value="Rebel Returnees">Rebel Returnees</label>
							    </div>
								<div class="radio">
							      <label><input type="radio" name="lts" value="Solo Parent">Solo Parent</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="lts" value="Others">Others</label>
							    </div>
							</div>	
							
						</div>
				      </div>
				    </div>
				    <div class="panel panel-info">
				      <div class="panel-heading">5. Taken NCAEIYP4SC before? </div>
				      <div class="panel-body">
				      	<div class="row">
				      		<div class="col-sm-2 form-group">
							    <div class="radio">
							      <label><input type="radio" name="taken_before" value="Yes">Yes</label>
							    </div>
							    <div class="radio">
							      <label><input type="radio" name="taken_before" value="No">No</label>
							    </div>
							    
							</div>
					      	<div class="col-sm-5 form-group">
								<label>Where:</label>
								<input type="text" name="taken_where" placeholder="Enter Here.." class="form-control" required="">
							</div>
							<div class="col-sm-5 form-group">
								<label>When:</label>
								<input type="text" name="taken_when" placeholder="Enter Here.." class="form-control" required="">
							</div>
						</div>
				      </div>
				    </div>
				    <div class="panel panel-info">
				      <div class="panel-heading">6. Name of Course/Qualification</div>
				      <div class="panel-body">
				      	<div class="row">
					      	<div class="col-sm-12 form-group">
								<label>Course/Qualification</label>
								<select name="course" class="form-control">
									<option value="">Select Course</option>
								
								<?php

									if(count($v_courses) > 0){
										foreach ($v_courses as $vc) {
											echo '<option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>';
										}
									}
								?>
								</select>
							</div>
						</div>
				      </div>
				    </div>
				    <div class="panel panel-info">
				      <div class="panel-heading">Student/Scholar Voucher Number <i class="small text-muted">(For Scholar Only)</i></div>
				      <div class="panel-body">
				      	<div class="row">
					      	<div class="col-sm-6 form-group">
								<label>Voucher Number</label>
								<input type="text" name="voucher_number" placeholder="Enter Voucher Number Here.." class="form-control" required="">
							</div>
							<div class="col-sm-6 form-group">
								<label>Scholarship Package(TWSP, PESFA, etc.)</label>
								<input type="text" name="scholar_package" placeholder="Enter Scholar Package Here.." class="form-control" required="">
							</div>
						</div>
				      </div>
				    </div>
					<button type="submit" name="enroll_student" class="btn btn-lg btn-info">Submit</button>	

					<a class="btn btn-lg btn-danger" href="index.php?q=Home"> Cancel</a>	

					</div>
					
				</form> 
				
	</div>
	
	</div>

    </div>

	<?php include "model/BootstrapFooter.php";?>
</body>
</html>
