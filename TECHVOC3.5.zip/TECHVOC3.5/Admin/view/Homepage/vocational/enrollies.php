<div class="content">
    <div class="container-fluid">
        <div class="row">
        
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <div class="nav-tabs-navigation">
                                        <div class="nav-tabs-wrapper">
                                            <span class="nav-tabs-title">Enrollies:</span>
                                            <ul class="nav nav-tabs" data-tabs="tabs">
                                                <li class="active">
                                                    <a href="#registrants" data-toggle="tab">
                                                        <i class="material-icons">bug_report</i> <?php echo count($registrants);?> Registrants
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                                <li class="">
                                                    <a href="#enrolled" data-toggle="tab">
                                                        <i class="material-icons">code</i><?php echo count($enrolled_student);?> Enrolled
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                               
                                            </ul>
                                            <!-- <i id="result" class="float-right">result</i> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="card-content">
                                    <div class="tab-content">
                                        <div class="tab-pane active" id="registrants">
                                            <table class="order-table table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>REFNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>COURSE</th>
                                                        <th>CONTACT</th>
                                                        <th>SETTINGS</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $gen = "";$ref="";$active="";
                                                    if(count($all_student) > 0){
                                                        
                                                        foreach ($all_student as $ens) {
                                                          if($ens['session_id'] != ""){
                                                          if($ens['en_status'] == 1){
                                                            $stat = '<a class="btn btn-success" href="#">Training</a>';
                                                          }
                                                          else if($ens['en_status'] == 2){
                                                            $stat = '<a class="btn btn-danger" href="#">Drop</a>';
                                                          }
                                                        }
                                                        else{
                                                          if($ens['en_status'] == 0){
                                                            $stat = '<a class="btn btn-warning" href="#">Registrants</a>';
                                                          }
                                                          else{
                                                            $stat = '<a class="btn btn-primary" href="#">Unschedule</a>';
                                                          }
                                                          
                                                        }
                                                            if($ens['en_status'] == 0){
                                                              echo '<input type="hidden" id="en_id" value="'.$ens['en_id'].'">';
                                                                if($ens['en_gender'] =="M"){
                                                                    $gen="Males";
                                                                }
                                                                else{$gen="Female";}
                                                            if($ens['ref_id'] == NULL){
                                                              $ref = $name;
                                                            }else{
                                                              $ref = $ens['ref_id'];
                                                            }
                                                            if($ens['en_active']==0){
                                                              $active = "<button id='un_active' class='btn btn-danger'>UNACTIVE</button>";
                                                            }
                                                            else{
                                                              $active = '<span id="active" class="pull-right"><a href="index.php?q=vocational/update-registrant&id='.$ens['en_id'].'" class="fa fa-edit" ></a> <a id="delete"  class="fa fa-trash" href="#"></a></span>';
                                                            }
                                                                echo '<tr data-toggle="#" data-target="#'.$ref.'">
                                                              <td>'.$ref.'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['co_name'].'</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              <td>'.$active.'</td>
                                                              </tr>';
                                                          }
                                                        } 
                                                    }
                                                    
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                            <div id="myTable">
                                                 <table class="table table-stripped" id="print-table">
                                                  <thead>
                                                    <tr>
                                                      <th>IDNO</th><th>NAME</th><th>COURSE</th><th>STATUS</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody>
                                                  
                                                    <?php
                                                     
                                                    if(count($registrants) > 0){
                                                        foreach ($registrants as $ens) {
                                                          if($ens['en_active'] == 1){
                                                            echo '<tr>
                                                                <td>'.$ens['ref_id'].'</td>
                                                                <td>'.$ens['en_lname'].', '.$ens['en_fname'].'</td>
                                                                <td>'.$ens['co_name'].'</td>
                                                                <td> ______ </td>
                                                                </tr>';
                                                          } 
                                                          }
                                                          
                                                    }
                                                    
                                                    ?>
                                                  </tbody>
                                                </table> 
                                              </div>
                                             <a class="btn btn-primary" href="#" id="print" onclick="javascript:printLayer('myTable')"><i class="fa fa-print"> Print</i></a>
                                        </div>
                                        <div class="tab-pane" id="enrolled">
                                           <table class="order-table table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>IDNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>COURSE</th>
                                                        <th>CONTACT</th>
                                                        <th>STATUS</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $gen="";
                                                    if(count($all_student) > 0){
                                                        
                                                        foreach ($all_student as $ens) {
                                                          if($ens['session_id'] != ""){
                                                            if($ens['en_status'] == 1){
                                                              $stat = '<a class="btn btn-success" href="#">Training</a>';
                                                            }
                                                            else if($ens['en_status'] == 2){
                                                              $stat = '<a class="btn btn-danger" href="#">Drop</a>';
                                                            }
                                                          }
                                                          else{
                                                            if($ens['en_status'] == 0){
                                                              $stat = '<a class="btn btn-warning" href="#">Registrants</a>';
                                                            }
                                                            else{
                                                              $stat = '<a class="btn btn-primary" href="#">Unschedule</a>';
                                                            }
                                                            
                                                          }
                                                            if($ens['en_status'] > 0){

                                                                if($ens['en_gender'] =="M"){
                                                                    $gen="Male";
                                                                }
                                                                else{$gen="Female";}
                                                                
                                                                 echo '<tr data-toggle="modal" data-target="#'.$ens['ref_id'].'">
                                                              <td>'.$ens['ref_id'].'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['co_name'].'</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              <td>'.$stat.'</td>
                                                              </tr>';
                                                          }
                                                        } 
                                                    }
                                                    
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                     
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>
        <!-- Modal -->
        <?php
          if(count($all_student) > 0){
            foreach ($all_student as $e_stud) {
                $student = $this->model->GetEnrolliesByRefID(array($e_stud['ref_id']));
                 echo '<div class="modal fade" id="'.$e_stud['ref_id'].'" role="dialog">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content" style="width:150%; margin-left: -80px; margin-top: -80px;">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title"><b>REF NO. </b>'.$student['ref_id'].'</h4>
                </div>
                <div class="modal-body" >
                  <div class="row">
                
                <div class="col-sm-12">
                <div class="panel panel-info">
                    <div class="panel-heading">Manpower Profile:</div>
                    <div class="panel-body">
                      <div class="row">
                    <div class="col-sm-3 form-group">
                      <b>First Name : </b><i> '.$student['en_fname'].'</i>
                      
                    </div>
                    <div class="col-sm-3 form-group">
                      <b>Last Name : </b><i> '.$student['en_lname'].'</i>
                    </div>
                    <div class="col-sm-3 form-group">
                      <b>Middle Name : </b><i> '.$student['en_mi'].'</i>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-4 form-group">
                      <b>Number, Street : </b><i> '.$student['en_num_street'].'</i>
                    </div>  
                    <div class="col-sm-4 form-group">
                      <b>Barangay :</b> <i> '.$student['en_barangay'].'</i>
                      
                    </div>  
                    <div class="col-sm-4 form-group">
                      <b>District : </b><i> '.$student['en_district'].'</i>
                      
                    </div>    
                  </div>
                  <div class="row">
                    <div class="col-sm-4 form-group">
                      <b>City/Municipality : </b><i> '.$student['en_city'].'</i>
                    </div>  
                    <div class="col-sm-4 form-group">
                      <b>Province :</b> <i> '.$student['en_province'].'</i>
                      
                    </div>  
                    <div class="col-sm-4 form-group">
                      <b>Nationality : </b><i> '.$student['en_nationality'].'</i>
                      
                    </div>    
                  </div>
                    </div>
                  </div>
                  <div class="panel panel-info">
                    <div class="panel-heading">Personal Information:</div>
                    <div class="panel-body">
                      <div class="row">
                      <div class="col-sm-2 form-group">
                        <b>Sex : </b>'.$student['en_gender'].'
                      </div>  
                      <div class="col-sm-4 form-group">
                        <b>Civil Status : </b>'.$student['en_civilstatus'].'
                      </div>  
                      <div class="col-sm-6 form-group">
                        <b>Employment Status : </b>'.$student['en_empstatus'].'
                        
                      </div>  
                      
                    </div>
                    <div class="row">
                      <div class="col-sm-6 form-group">
                        <b>Birth Date : </b>'.$student['en_bdate'].'
                      </div>
                      <div class="col-sm-6 form-group">
                        <b>Age : </b>'.$student['en_age'].'
                      </div>
                    </div>
                    <div class="form-group">
                     <b>Birth Place : </b> '.$student['en_birthplace'].'
                    </div>
                    <div class="row">
                       <div class="col-sm-6 form-group">
                        <b> Father First Name : </b><i> '.$student['en_father_fname'].'</i>
                        
                      </div>
                      <div class="col-sm-6 form-group">
                        <b> Father Last Name : </b><i> '.$student['en_father_lname'].'</i>
                      </div>
                      
                  </div>
                  <div class="row">
                    <div class="col-sm-6 form-group">
                      <b>Mother First Name : </b><i> '.$student['en_mother_fname'].'</i>
                      
                    </div>
                    <div class="col-sm-6 form-group">
                      <b>Mother Last Name : </b><i> '.$student['en_mother_lname'].'</i>
                    </div>
                  </div>
                  </div>
                  
                  </div>  
                  <div class="panel panel-info">
                    <div class="panel-heading">Educational Attainment Before the Training <i class="small text-muted">(Trainee)</i></div>
                    <div class="panel-body">
                      <div class="row">
                    <div class="col-sm-10 form-group">
                      <b>Educational Attainment: </b>'.$student['en_edattainment'].'
                    </div>  
                    
                  </div>
                    </div>
                  </div>
                  <div class="panel panel-info">
                    <div class="panel-heading">Leaner/Trainee/Student <i class="small text-muted">(Clients) Classification</i></div>
                    <div class="panel-body">
                      <div class="row">
                    <div class="col-sm-6 form-group">
                      <b>Classification : </b>'.$student['en_lts'].'
                    </div>  
                  </div>
                    </div>
                  </div>
                  <div class="panel panel-info">
                    <div class="panel-heading">Taken NCAEIYP4SC Before?</div>
                    <div class="panel-body">
                      <div class="row">
                        <div class="col-sm-6 form-group">
                      <b>Where : </b>'.$student['en_taken_where'].'
                    </div>
                    <div class="col-sm-6 form-group">
                      <b>When : </b>'.$student['en_taken_when'].'
                      
                    </div>
                  </div>
                    </div>
                  </div>
                  <div class="panel panel-info">
                    <div class="panel-heading">Student/Scholar Voucher Number <i class="small text-muted">(For Scholar Only)</i></div>
                    <div class="panel-body">
                      <div class="row">
                        <div class="col-sm-6 form-group">
                      <b>Voucher Number : </b>'.$student['en_stud_voucher_no'].'
                    </div>
                    <div class="col-sm-6 form-group">
                      <b>Scholarship Package : </b>'.$student['en_scholar_package'].'
                      
                    </div>
                  </div>
                    </div>
                  </div>
                <button type="submit" name="enroll_student" class="btn btn-lg btn-info">Print</button>  
        
                </div>
              </div>
                </div>
                <div class="modal-footer">
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
              
            </div>
          </div>';
              }
            }
      
    ?>
    </div>
</div>
 

 