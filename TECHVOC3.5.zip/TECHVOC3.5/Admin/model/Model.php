<?php
	include_once("Crud.php");
	class Model{
		private $crud;
		public function __construct(){
			$this->crud = new Crud();
		}
        //REGISTER
		public function RegisterAdmin($data){
            $query = "INSERT INTO admin(admin_fname,admin_lname,admin_gender, admin_address, admin_contact, admin_email, admin_password) VALUES(?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);

        }
        public function RegisterAssessment($data){
            $query = "INSERT INTO assessment(
            info_region,
            info_province,
            info_district,
            info_city,
            info_provider,
            info_address,
            info_typeofprovider,
            info_classification_provider,
            info_industry_sector,
            info_prog_reg_stat,
            info_prog_title,
            info_ctpr,
            info_training_calendar_mode,
            info_delivery_mode,
            info_voucher_no,
            info_date_started,
            info_date_finished,
            info_date_assessed,
            info_assessment_result,
            user_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        //ENROLLMENT STUDENT
        public function EnrollStudent($data){
            $query = "INSERT INTO enrollment(
            en_fname,
            en_lname,
            en_mi,
            en_num_street,
            en_barangay,
            en_district,
             en_city, 
             en_province,
              en_region,
              en_email_add,
              en_contact,
              en_nationality,
              en_gender,
              en_civilstatus,
              en_empstatus,
               en_bdate,
               en_age,
               en_birthplace,
               en_father_fname,
               en_father_lname,
               en_mother_fname,
               en_mother_lname,
               en_edattainment,
               en_lts,
               en_taken_where,
               en_taken_when,
               en_stud_voucher_no,
               en_scholar_package,
                 co_id,
                 en_status,en_active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function OpenSession($data){
            $query = "INSERT INTO session(co_id,start_date, end_date, session_status) VALUES(?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function ChangeEmail($table,$data){
            $query = "UPDATE $table set cust_email=? where cust_id=?";
            $this->crud->Update($query,$data);

        }
        public function CheckadminPassword($data){
            $query = "SELECT admin_password FROM admin WHERE admin_password=? and admin_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        public function ChangeadminPassword($data){
            $query = "UPDATE admin set admin_password=? where admin_id=?";
            $this->crud->Update($query,$data);

        }
        //
        public function GetAlladmin($data){
            $query = "SELECT * FROM admin WHERE admin_id != $data; ";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //CHECK EMAIL
        public function CheckEmail($data){
            $check=NULL;
            $query = "SELECT * FROM admin where admin_email=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        //CHECK PASSWORD
        public function CheckPassword($data){
            $check=NULL;
            $query = "SELECT * FROM admin where admin_id=? and admin_password=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        //VALIDATE LOGIN
        public function ValidateadminLogin($data){
            $query = "SELECT * FROM admin where admin_email=? and admin_password=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //LOGOUT
        public function admin_Logout(){
            if(isset($_COOKIE['admin_id'])){
                setcookie("admin_id",$_COOKIE['admin_id'], time() - 86400 ,"/");
                header("Location: index.php");
            }
        }
        
        public function getadminInformation($data){
             
            $query = "SELECT * FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            
            return $row;
        }
       
        //AMDIN SIDE
        public function getAdminNameByID($data){
            $name=null;
            $query = "SELECT admin_fname, admin_lname FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['admin_fname']." ".$row['admin_lname'];
            }
            return $name;
        }
        // public function getAdminImgByID($data){
        //     $img=null;
        //     $query = "SELECT admin_img FROM admin where admin_id=?";
        //     $row = $this->crud->Select($query,$data);
        //     if(count($row) > 0){
        //         $img = $row['admin_img'];
        //     }
        //     else $img=null;
        //     return $img;
        // }
        //
        //
        //GET STUDENT WANTS TO ENROLL
        public function GetStudentWantTOEnroll(){
            $query = "SELECT  e.*, c.* FROM enrollment e, course_offer c WHERE e.en_status=0 and e.co_id=c.co_id;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetStudentEnrolled(){
            $query = "SELECT e.*, c.* FROM enrollment e, course_offer c WHERE e.en_status > 0 and e.co_id=c.co_id;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetAllStudentEnrollies(){
            $query = "SELECT e.*, c.* FROM enrollment e, course_offer c WHERE e.co_id=c.co_id;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
    
        public function CountUser(){
            $query = "SELECT * FROM user;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET VOCATIONAL COURSES OFFERED
        public function GetVocationalCourses(){
            $query = "SELECT * FROM course_offer";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetCourseByCode($data){
            $query = "SELECT * FROM course_offer WHERE co_code=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
         public function GetCourseByID($data){
            $query = "SELECT * FROM course_offer WHERE co_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
         //VIEW ENROLLIES
        public function GetEnrolliesByRefID($data){
            $query = "SELECT * FROM enrollment WHERE ref_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //GET STUDENT BY COURSE
        public function GetUnSchedStudenyByCourse($data){
            $query = "SELECT * FROM enrollment WHERE co_id=$data and en_status=1 and session_id IS NULL;";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET ASSESSMENT
        public function GetAssessment(){
            $query = "SELECT a.*, u.*, e.* FROM assessment a , user u, enrollment e WHERE a.user_id=u.user_id and e.ref_id=u.user_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetDoneSchedStudenyByCourse($data){
            $query = "SELECT e.*, s.*, c.* FROM enrollment e, session s, course_offer c WHERE e.co_id=$data and e.en_status=1 and e.session_id > 0 and e.session_id=s.session_id and e.co_id=c.co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //CHECK SESSION BY COURSE
        public function CheckSession($data){
            $found="false";
            $query = "SELECT * FROM session WHERE co_id=? and session_status=?";
            $row = $this->crud->Select($query, $data);
            if($row > 0){
                $found = "true";
            }
            return $found;
        }
        //GET ALL USERS
        public function GetAllUsers(){
            $query = "SELECT u.*, e.*, c.* FROM user u LEFT JOIN enrollment e ON u.user_id=e.ref_id lEFT JOIN course_offer c ON e.co_id=c.co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //TO DROP USER
        public function ToDropUser(){
            $query = "SELECT e.*, c.* FROM user u LEFT JOIN enrollment e,course_offer c WHERE e.co_id=c.co_id and e.en_status=1";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET OPEN SESSION BY COURSE
        public function GetOpenSessionByCourse($data){
            $query = "SELECT * FROM session WHERE co_id=? and session_status=1";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //GET ANNOUNCEMENT
        public function GetAnnouncement(){
            $query = "SELECT * FROM announcement";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET REGISTRANT BYID
        public function GetRegistrantByID($data){
            $query = "SELECT * FROM enrollment WHERE en_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //COUNT ENROLLED BY COURSE
        public function CountEnrolledByCourse($data){
            $query = "SELECT e.*, c.* FROM enrollment e, course_offer c  WHERE e.co_id=c.co_id and e.co_id=$data and e.en_status=1";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
         public function CountRegistrantByCourse($data){
            $query = "SELECT e.*, c.* FROM enrollment e, course_offer c  WHERE e.co_id=c.co_id and e.co_id=$data and e.en_status=0";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET SESSION ID
        public function GetSessionID(){
            $data = array(1);
            $query = "SELECT * FROM session WHERE session_status=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //SEARCH
        public function Search($from, $to, $course, $status){
            $row="";
                $query = "SELECT e.*, c.* FROM enrollment e, course_offer c WHERE e.co_id=c.co_id  and e.co_id=$course and  e.en_date BETWEEN( LIKE '$%from' AND LIKE '$%to')  and en_status=$status  ORDER BY en_date;";
                $row = $this->crud->SelectAll($query);
            
           
            
            return $row;
            
        }
        //UPDATE
        public function UpdateadminInfo($data){
            $query = "UPDATE admin SET admin_fname=?,admin_lname=?, admin_address=?, admin_gender=?, admin_contact=?, admin_img=? WHERE admin_id=?";
            $this->crud->Update($query, $data);
        }
        //PAYMENT
        public function UpdatePaymentStatus($data){
            $query = "UPDATE enrollment SET en_status=1 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        //DROP
        public function DropStudent($data){
            $query = "UPDATE enrollment SET en_status=2 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        //CLOSE SESSION ENROLLMENT
        public function CloseSession($data){
            $query = "UPDATE session SET session_status=0 WHERE session_status=1 and co_id=?";
            $this->crud->Update($query, $data);
        }
        //SET SESSION
        public function SetSession($data){
            $query = "UPDATE enrollment SET session_id=? WHERE en_id=?";
            $this->crud->Update($query, $data);
        }

        //DELETE REGISTRANTS
        public function DeleteRegistrant($data){
            $query = "UPDATE enrollment SET en_active=0 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        //ACTIVATE REGISTRANTS
        public function ActivateRegistrant($data){
            $query = "UPDATE enrollment SET en_active=1 WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
        //UDPATE REGISTRANTS
        public function UpdateRegistrant($data){
            $query = "UPDATE enrollment SET en_fname=?,
            en_lname=?,
            en_mi=?,
            en_num_street=?,
            en_barangay=?,
            en_district=?,
             en_city=?, 
             en_province=?,
              en_region=?,
              en_email_add=?,
              en_contact=?,
              en_nationality=?,
              en_gender=?,
              en_civilstatus=?,
              en_empstatus=?,
               en_bdate=?,
               en_age=?,
               en_birthplace=?,
               en_father_fname=?,
               en_father_lname=?,
               en_mother_fname=?,
               en_mother_lname=?,
               en_edattainment=?,
               en_lts=?,
               en_taken_where=?,
               en_taken_when=?,
               en_stud_voucher_no=?,
               en_scholar_package=?,
                 co_id=? WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
	}
?>