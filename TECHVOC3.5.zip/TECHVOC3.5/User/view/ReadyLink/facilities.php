<!DOCTYPE html>
<html>
<head>
	<title>Techvoc</title>
</head>
<body>
	<h1><b>FACILITIES</b></h1>
</body>
</html>