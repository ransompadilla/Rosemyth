
<div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <a href="index.php?q=vocational/enrollies">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="orange">
                                    <i class="material-icons">content_copy</i>
                                </div>
                                <div class="card-content">
                                    <p class="category">RESERVED</p>
                                    <h3 class="title"><?php echo count($registrants);?>
                                    </h3>
                                </div>
                                <!-- <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons text-danger">warning</i>
                                        <a href="#pablo">Get More Space...</a>
                                    </div>
                                </div> -->
                            </div>
                            </a>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <a href="index.php?q=vocational/enrollies">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="green">
                                    <i class="material-icons">store</i>
                                </div>
                                <div class="card-content">
                                    <p class="category">ENROLLED</p>
                                    <h3 class="title"><?php echo count($enrolled_student);?></h3>
                                </div>
                                <!-- <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">date_range</i> Last 24 Hours
                                    </div>
                                </div> -->
                            </div>
                            </a>
                        </div>
                        <!-- <div class="col-lg-3 col-md-6 col-sm-6">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="red">
                                    <i class="material-icons">info_outline</i>
                                </div>
                                <div class="card-content">
                                    <p class="category">Fixed Issues</p>
                                    <h3 class="title">75</h3>
                                </div>
                                <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">local_offer</i> Tracked from Github
                                    </div>
                                </div>
                            </div>
                        </div> -->
                        <div class="col-lg-3 col-md-6 col-sm-6">
                            <a href="#">
                            <div class="card card-stats">
                                <div class="card-header" data-background-color="red">
                                    <i class="fa fa-user"></i>
                                </div>
                                <div class="card-content">
                                    <p class="category">DROP</p>
                                    <h3 class="title"><?php echo count($count_drop);?></h3>
                                </div>
                                <!-- <div class="card-footer">
                                    <div class="stats">
                                        <i class="material-icons">update</i> Just Updated
                                    </div>
                                </div> -->
                            </div>
                            </a>
                        </div>
                    </div>
                    <hr>
                    <div class="row">
                      <?php
                      $ctr_drop=0;$ctr_trained=0;
                        if(count($v_courses) > 0){

                          foreach ($v_courses as $vc) {
                           
                            $course_count = $this->model->CountEnrolledByCourse($vc['co_id']);
                            $course_count_drop = $this->model->CountEnrolledDropByCourse($vc['co_id']);
                            $count_registrant = $this->model->CountRegistrantByCourse($vc['co_id']);
                            $unsched_student_course = $this->model->GetUnSchedStudenyByCourse($vc['co_id']);
                            
                            echo '
                            <a href="index.php?q=vocational/course&id='.$vc['co_id'].'">
                              <div id="course" class="col-md-4">
                                  <div class="card">
                                      <img src="'.$vc['co_img'].'" class="img-fluid" alt="" style="width: 100%; height: 250px;">
                                      <div class="card-content">
                                          <h4 class="title">'.$vc['co_name'].'</h4>
                                          <p class="category">
                                              <span class="pull-left">ENROLLED: '.count($course_count).'<br>
                                              UNSCHED: '.count($unsched_student_course).'
                                              </span>
                                              <span class="pull-right"><span>DROP: '.count($course_count_drop).'<br>
                                              RESERVED: '.count($count_registrant).'
                                              </span>
                                                
                                          </p>
                                      </div>
                                      <div class="card-footer">
                                          <div class="stats">
                                            
                                          </div>
                                      </div>
                                  </div>
                              </div>
                            ';       
                          }
                        }
                      ?>
                    </div>
                  
                </div>
                
            </div>