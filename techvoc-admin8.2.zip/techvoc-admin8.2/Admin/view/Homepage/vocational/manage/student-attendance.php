<?php 
include_once "../../../../model/Model.php";
$model = new Model();

if(isset($_GET['id'])){                 
	header("Content-type: application/vnd.ms-excel; name='excel'");
	header("Content-Disposition: attachment; filename=exportfile.xls");
	header("Pragma: no-cache");
	header("Expires: 0");

	$tr = $model->GetTrainorByID(array($_GET['id']));
    $tr_student = $model->GetTrainerStudent($_GET['id']);
    $course = $model->GetCourseByID(array($_GET['co_id']));
	  echo 'Teacher Name: '.$tr['tr_lname'].', '.$tr['tr_fname'].'<br>';
	  echo 'Teacher Course: '.$course['co_name'].'<br><br>';
	  echo '<table class="order-table table" id="enrolled-table">
	        <thead>
	            <tr id="printme">
					<th>NO.</th>
	                <th>STUDENT NAME</th>
	                <th>DATE1</th>
	                <th>DATE2</th>
	                <th>DATE3</th>
	                <th>DATE4</th>
	                <th>DATE5</th>
	            </tr>
	        </thead>
	        <tbody>';
	            if(count($tr_student) > 0){
	            	$ctr=1;
	            	echo '<tr></tr>';
	                foreach ($tr_student as $trs) {
	                   echo '<tr>
	                   			<td>'.$ctr++.'</td>
	                   			<td>'.$trs['en_lname'].', '.$trs['en_fname'].'</td>
	                   		</tr>';
	                                            
	              	}
	            }
			echo '</tbody>
	    </table>';
	}
?>
