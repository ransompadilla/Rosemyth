<?php 
include_once "../../../model/Model.php";
$model = new Model();

if(isset($_GET['id'])){                 
header("Content-type: application/vnd.ms-excel; name='excel'");
header("Content-Disposition: attachment; filename=exportfile.xls");
header("Pragma: no-cache");
header("Expires: 0");

$donesched_student_course = $model->GetDoneSchedStudenyByCourse($_GET['id']);
 
  $stat="";
  echo '<table class="order-table table" id="enrolled-table">
                                                <thead>
                                                    <tr id="printme">
<th>REGION</th>
                                                        <th>PROVINCE</th>
                                                        <th>DISTRICT</th>
                                                        <th>CITY</th>
                                                        <th>PROVIDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>TYPE OF PROVIDER</th>
                                                        <th>CLASSIFICATION PROVIDER</th>
                                                        <th>INDUSTRY SECTOR</th>
                                                        <th>PROGRAM REGISTRATION STATUS</th>
                                                        <th>QUALIFICATION/PROGRAM TITLE</th>
                                                        <th>CTPR</th>
                                                        <th>DELIVERY MODE</th>
                                                        <th>LASTNAME</th>
                                                        <th>FIRSTNAME</th>
                                                        <th>MIDDLE NAME</th>
                                                        <th>EXTENSION NAME</th>
                                                        <th>CONTACT</th>
                                                        <th>EMAIL</th>
                                                        <th>STREET</th>
                                                        <th>BARANGAY</th>
                                                        <th>CITY/MUNICIPALITY</th>
                                                        <th>REGION</th>
                                                        <th>PROVINCE</th>
                                                        <th>GENDER</th>
                                                        <th>DATE OF BIRTH  </th>

                                                        <th>AGE</th>
                                                        <th>CIVIL STATUS</th>
                                                        <th>HIGHEST GRADE COMPLETED</th>
                                                        <th>NATIONALITY</th>
                                                        <th>CLASSIFICATION OF CLIENTS</th>
                                                        <th>TRAINING STATUS</th>
                                                        <th>TPYE OF SCHOLARSHIPS</th>
                                                        <th>VOUCHER NO</th>
                                                        <th>DATE STARTED</th>
                                                        <th>DATE FINISHED</th>
                                                        <th>DATE ASSESSED</th>
                                                        <th>ASSESSMENT REUSULT</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>';
                                                    if(count($donesched_student_course) > 0){
                                                        
                                                        foreach ($donesched_student_course as $ens) {
                                                          
                                                          if($ens['en_status'] == 1){
                                                            $stat = '<a class="btn btn-success" href="#">Training</a>';
                                                          }
                                                          else if($ens['en_status'] == 2){
                                                            $stat = '<a class="btn btn-success" href="#">Drop</a>';
                                                          }
                                                                if($ens['en_gender'] =="M"){
                                                                    $gen="Male";
                                                                }
                                                                else{$gen="Female";}
                                                            
                                                                echo '<tr>
                                                              <td></td>
                                                              <td></td>
                                                              <td></td>
                                                              <td></td>

                                                              <td></td>
                                                              <td></td>
                                                              <td></td>
                                                              <td></td>
                                                              <td></td>
                                                              <td></td>
                                                              <td></td>
                                                              <td></td>
                                                              <td></td>


                                                              <td>'.$ens['en_lname'].'</td>
                                                              <td>'.$ens['en_fname'].'</td>
                                                              <td>'.$ens['en_mi'].'</td>
                                                              <td>N/A</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              <td>'.$ens['en_email_add'].'</td>
                                                              <td>'.$ens['en_num_street'].'</td>
                                                              <td>'.$ens['en_barangay'].'</td>
                                                              <td>'.$ens['en_city'].'</td>
                                                              <td>'.$ens['en_district'].'</td>
                                                              <td>'.$ens['en_province'].'</td>
                                                              <td>'.$ens['en_gender'].'</td>
                                                              <td>'.$ens['en_bdate'].'</td>
                                                              <td>'.$ens['en_age'].'</td>

                                                              <td>'.$ens['en_civilstatus'].'</td>
                                                              <td>'.$ens['en_edattainment'].'</td>
                                                              <td>'.$ens['en_nationality'].'</td>
                                                              <td>'.$ens['en_lts'].'</td>
                                                              <td>'.$ens['en_scholar_package'].'</td>

                                                              <td></td>
                                                              <td></td>
                                                              <td></td>
                                                              <td></td>
                                                              <td></td>
                                                              </tr>';
                                                          }
                                                      
                                                    }
								echo '</tbody>
                                            </table>';
}
?>
