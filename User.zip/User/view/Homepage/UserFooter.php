  
  <!--==========================
    Footer
  ============================-->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6 footer-info">
            <h3>Benedicto College</h3>
            <p>Technical Vocational Institution & Assesment Center</p>
          </div>
<!-- 
          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Home</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">About us</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Services</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="ion-ios-arrow-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>
 -->
          <div class="col-lg-4 col-md-6 footer-contact">
            <h4>Contact Us</h4>
            <p>
              <i class="fa fa-home" aria-hidden="true"></i> A.S. Fortuna Street, <br>
              Mandaue City 6014,<br>
              Metro Cebu Philippines <br>
              <br><br>Tel. Nos.: <br>
              <i class="fa fa-phone" aria-hidden="true"></i>&nbsp; +63 (32) 345 5790 (COLLEGE)<br>
              <i class="fa fa-phone" aria-hidden="true"></i>&nbsp; +63 (32) 422 2777 (BASIC EDUCATION)<br>
              <i class="fa fa-phone" aria-hidden="true"></i>&nbsp; +63 (32) 344 9320 (TECHNICAL-VOCATIONAL)<br>
            </p>

            <div class="social-links">
              <a href="#" class="twitter"><i class="fa fa-twitter"></i></a>
              <a href="#" class="facebook"><i class="fa fa-facebook"></i></a>
              <a href="#" class="instagram"><i class="fa fa-instagram"></i></a>
              <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a>
              <a href="#" class="linkedin"><i class="fa fa-linkedin"></i></a>
            </div>

          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <b><p class = "indent">&emsp;READY LINKS</p></b>
              <ul class = "quicklinks"><br>
                
                
                <li><a href = "#">Facilities</a></li>
                <li><a href = "#">Activities in & out </a></li>
                <li><a href = "#">History</a></li>
                <li><a href = "#">Article</a></li>
              </ul>
          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong>TECHVOC</strong>. All Rights Reserved
      </div>
      <div class="credits">
        <!--
          All the links in the footer should remain intact.
          You can delete the links only if you purchased the pro version.
          Licensing information: https://bootstrapmade.com/license/
          Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/buy/?theme=BizPage
        -->
      <!--   Best <a href="https://bootstrapmade.com/">Bootstrap Templates</a> by BootstrapMade -->
      </div>
    </div>
  </footer><!-- #footer -->
        <?php include "model/BootstrapFooter.php";?>
        

  </body>
</html>