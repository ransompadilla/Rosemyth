<div class="content">
    <div class="container-fluid">
        <div class="row">
        	
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                   <h4 class="title">Assessment</h4>
                                    <!-- <p id="result"></p> -->
                                    <!-- <p class="category">Users (<?php echo count($assessment);?>)</p> -->
                                </div>
                                <div class="card-content" id="training">
                                    <div id="assessment_table" class="tab-content" style="overflow-x:auto;">
                                       
                                            <table class="table">
                                                <thead>
                                                    <tr>
                                                        <th>REGION</th>
                                                        <th>PROVINCE</th>
                                                        <th>DISTRICT</th>
                                                        <th>CITY</th>
                                                        <th>PROVIDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>TYPE OF PROVIDER</th>
                                                        <th>CLASSIFICATION PROVIDER</th>
                                                        <th>INDUSTRY SECTOR</th>
                                                        <th>PROGRAM REGISTRATION STATUS</th>
                                                        <th>QUALIFICATION/PROGRAM TITLE</th>
                                                        <th>CTPR</th>
                                                        <th>DELIVERY MODE</th>
                                                        <th>LASTNAME</th>
                                                        <th>FIRSTNAME</th>
                                                        <th>MIDDLE NAME</th>
                                                        <th>EXTENSION NAME</th>
                                                        <th>CONTACT</th>
                                                        <th>EMAIL</th>
                                                        <th>STREET</th>
                                                        <th>BARANGAY</th>
                                                        <th>CITY/MUNICIPALITY</th>
                                                        <th>PROVOVINCE</th>
                                                        <th>GENDER</th>
                                                        <th>DATE OF BIRTH  </th>

                                                        <th>AGE</th>
                                                        <th>CIVIL STATUS</th>
                                                        <th>HIGHEST GRADE COMPLETED</th>
                                                        <th>NATIONALITY</th>
                                                        <th>CLASSIFICATION OF CLIENTS</th>
                                                        <th>TRAINING STATUS</th>
                                                        <th>TPYE OF SCHOLARSHIPS</th>
                                                        <th>VOUCHER NO</th>
                                                        <th>DATE STARTED</th>
                                                        <th>DATE FINISHED</th>
                                                        <th>DATE ASSESSED</th>
                                                        <th>ASSESSMENT REUSULT</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $stat="";
                                                    if(count($assessment) > 0){
                                                        
                                                        foreach ($assessment as $ens) {
                                                        	if($ens['en_status'] == 1 and $ens['session_id'] != NULL){
                                                       
                                                                if($ens['en_gender'] =="M" || $ens['user_gender'] =="M"){
                                                                    $gen="Male";
                                                                }
                                                                else{$gen="Female";}
                                                            if($ens['ref_id'] == $ens['user_id']){
                                                            	echo '<tr data-toggle="#" data-target="#'.$ens['ref_id'].'">
                                                              <td>'.$ens['info_region'].'</td>
                                                              <td>'.$ens['info_province'].'</td>
                                                              <td>'.$ens['info_district'].'</td>
                                                              <td>'.$ens['info_city'].'</td>

                                                              <td>'.$ens['info_provider'].'</td>
                                                              <td>'.$ens['info_typeofprovider'].'</td>
                                                              <td>'.$ens['info_classification_provider'].'</td>
                                                              <td>'.$ens['info_industry_sector'].'</td>
                                                              <td>'.$ens['info_prog_reg_stat'].'</td>
                                                              <td>'.$ens['info_prog_title'].'</td>
                                                              <td>'.$ens['info_ctpr'].'</td>
                                                              <td>'.$ens['info_training_calendar_mode'].'</td>
                                                              <td>'.$ens['info_delivery_mode'].'</td>


                                                              <td>'.$ens['en_lname'].'</td>
                                                              <td>'.$ens['en_fname'].'</td>
                                                              <td>'.$ens['en_mi'].'</td>
                                                              <td>N/A</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              <td>'.$ens['en_email_add'].'</td>
                                                              <td>'.$ens['en_num_street'].'</td>
                                                              <td>'.$ens['en_barangay'].'</td>
                                                              <td>'.$ens['en_city'].'</td>
                                                              <td>'.$ens['en_district'].'</td>
                                                              <td>'.$ens['en_province'].'</td>
                                                              <td>'.$ens['en_gender'].'</td>
                                                              <td>'.$ens['en_bdate'].'</td>
                                                              <td>'.$ens['en_age'].'</td>

                                                              <td>'.$ens['en_civilstatus'].'</td>
                                                              <td>'.$ens['en_edattainment'].'</td>
                                                              <td>'.$ens['en_nationality'].'</td>
                                                              <td>'.$ens['en_lts'].'</td>
                                                              <td>'.$ens['en_scholar_package'].'</td>

                                                              <td>'.$ens['info_voucher_no'].'</td>
                                                              <td>'.$ens['info_date_started'].'</td>
                                                              <td>'.$ens['info_date_finished'].'</td>
                                                              <td>'.$ens['info_date_assessed'].'</td>
                                                              <td>'.$ens['info_assessment_result'].'</td>

                                                              </tr>';
                                                            }
                                                            
                                                          }
                                                        }
                                                    	
                                                    }
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                              <button id="btnDownload" class="btnDownload btn btn-info">Download to Excel</button>  
                                        </div>
                                        
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>
    </div>
