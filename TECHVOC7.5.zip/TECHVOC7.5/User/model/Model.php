<?php
	include_once("Crud.php");
	class Model{
		private $crud;
		public function __construct(){
			$this->crud = new Crud();
		}
        //REGISTER
		public function RegisterUser($data){
            $query = "INSERT INTO user(user_fname,user_lname,user_gender, user_address, user_bdate,user_age, user_contact, user_email, user_password) VALUES(?,?,?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);

        }
        //ENROLLMENT STUDENT
        public function EnrollStudent($data){
            $query = "INSERT INTO enrollment(
            en_fname,
            en_lname,
            en_mi,
            en_num_street,
            en_barangay,
            en_district,
             en_city, 
             en_province,
              en_region,
              en_email_add,
              en_contact,
              en_nationality,
              en_gender,
              en_civilstatus,
              en_empstatus,
               en_bdate,
               en_age,
               en_birthplace,
               en_father_fname,
               en_father_lname,
               en_mother_fname,
               en_mother_lname,
               en_edattainment,
               en_lts,
               en_taken_where,
               en_taken_when,
               en_stud_voucher_no,
               en_scholar_package,
                ref_id,
                 co_id,
                 en_status,en_active) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $this->crud->Insert($query,$data);
        }
        public function ChangeEmail($data){
            $query = "UPDATE user set user_email=? where user_id=?";
            $this->crud->Update($query,$data);

        }
        public function CheckUserPassword($data){
            $query = "SELECT user_password FROM user WHERE user_password=? and user_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        public function ChangeUserPassword($data){
            $query = "UPDATE user set user_password=? where user_id=?";
            $this->crud->Update($query,$data);

        }
        //
        public function GetAllUser($data){
            $query = "SELECT * FROM user WHERE user_id != $data; ";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //CHECK REFID
        public function CheckRefID($data){
            $check=NULL;
            $query = "SELECT * FROM enrollment where ref_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        //CHECK EMAIL
        public function CheckEmail($data){
            $check=NULL;
            $query = "SELECT * FROM user where user_email=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        //CHECK PASSWORD
        public function CheckPassword($data){
            $check=NULL;
            $query = "SELECT * FROM user where user_id=? and user_password=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 1){
                $check = "Checked";
            }
            return $check;
        }
        //VALIDATE LOGIN
        public function ValidateUserLogin($data){
            $query = "SELECT * FROM user where user_email=? and user_password=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //LOGOUT
        public function User_Logout(){
            if(isset($_COOKIE['user_id'])){
                setcookie("user_id",$_COOKIE['user_id'], time() - 86400 ,"/");
                header("Location: index.php");
            }
        }
        
        public function getUserInformation($data){
             
            $query = "SELECT * FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            
            return $row;
        }
        public function getUserNameByID($data){
            $name=null;
            $query = "SELECT user_fname, user_lname FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['user_fname']." ".$row['user_lname'];
            }
            return $name;
        }
        public function getUserImgByID($data){
            $img=null;
            $query = "SELECT user_img FROM user where user_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $img = $row['user_img'];
            }
            else $img=null;
            return $img;
        }
        //AMDIN SIDE
        public function getAdminNameByID($data){
            $name=null;
            $query = "SELECT admin_name FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $name = $row['admin_name'];
            }
            return $name;
        }
        public function getAdminImgByID($data){
            $img=null;
            $query = "SELECT admin_img FROM admin where admin_id=?";
            $row = $this->crud->Select($query,$data);
            if(count($row) > 0){
                $img = $row['admin_img'];
            }
            else $img=null;
            return $img;
        }
        //
        public function GetIncreamentRefID(){
          $query = "SELECT max(ref_id) as transaction_no FROM enrollment";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //
        //GET VOCATIONAL COURSES OFFERED
        public function GetVocationalCourses(){
            $query = "SELECT * FROM course_offer";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        
         public function GetCourseByID($data){
            $query = "SELECT * FROM course_offer WHERE co_id=?";
            $row = $this->crud->Select($query,$data);
            return $row;
        }
        //GET ALL ACTIVITEIES
        public function GetAllActivitiesByCOID($data){
             $query = "SELECT * FROM activities WHERE co_id=$data";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //GET ANNOUNCEMENT
        public function GetAnnouncement(){
            $query = "SELECT * FROM announcement";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
       //GET ALL ACTIVITEIES
        public function GetAllActivities(){
             $query = "SELECT a.*, c.* FROM activities a, course_offer c WHERE a.co_id=c.co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        //NO of Enrolly
        public function GetAllEnrollies($co_id){
            $query = "SELECT e.*, s.*, sched.* FROM enrollment e, session s, schedule sched WHERE e.session_id=s.session_id and e.sched_id=sched.sched_id and e.co_id=$co_id";
            $row = $this->crud->SelectAll($query);
            return $row;
        }
        public function GetMyForm($data){
            $query = "SELECT FROM enrollment WHERE ref_id=?";
            $row = $this->crud->Select($query, $data);
            return $row;
        }
       
        //UPDATE
        public function UpdateUserInfo($data){
            $query = "UPDATE user SET user_fname=?,user_lname=?, user_address=?, user_gender=?, user_bdate=?, user_contact=?, user_img=? WHERE user_id=?";
            $this->crud->Update($query, $data);
        }
         //UDPATE REGISTRANTS
        public function UpdateRegistrant($data){
            $query = "UPDATE enrollment SET en_fname=?,
            en_lname=?,
            en_mi=?,
            en_num_street=?,
            en_barangay=?,
            en_district=?,
             en_city=?, 
             en_province=?,
              en_region=?,
              en_email_add=?,
              en_contact=?,
              en_nationality=?,
              en_gender=?,
              en_civilstatus=?,
              en_empstatus=?,
               en_bdate=?,
               en_age=?,
               en_birthplace=?,
               en_father_fname=?,
               en_father_lname=?,
               en_mother_fname=?,
               en_mother_lname=?,
               en_edattainment=?,
               en_lts=?,
               en_taken_where=?,
               en_taken_when=?,
               en_stud_voucher_no=?,
               en_scholar_package=?,
                 co_id=? WHERE en_id=?";
            $this->crud->Update($query, $data);
        }
      

	}
?>