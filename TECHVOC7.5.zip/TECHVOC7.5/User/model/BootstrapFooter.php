 <script src="../Bootstrap/lib/jquery/jquery.min.js"></script>
<script src="assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="assets/js/jquery-3.2.1.min.js" type="text/javascript"></script>
  <script src="../Bootstrap/lib/jquery/jquery-migrate.min.js"></script>
  <script src="../Bootstrap/lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../Bootstrap/lib/easing/easing.min.js"></script>
  <script src="../Bootstrap/lib/superfish/hoverIntent.js"></script>
  <script src="../Bootstrap/lib/superfish/superfish.min.js"></script>
  <script src="../Bootstrap/lib/wow/wow.min.js"></script>
  <script src="../Bootstrap/lib/waypoints/waypoints.min.js"></script>
  <script src="../Bootstrap/lib/counterup/counterup.min.js"></script>
  <script src="../Bootstrap/lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="../Bootstrap/lib/isotope/isotope.pkgd.min.js"></script>
  <script src="../Bootstrap/lib/lightbox/js/lightbox.min.js"></script>
  <script src="../Bootstrap/lib/touchSwipe/jquery.touchSwipe.min.js"></script>
  <!-- Contact Form JavaScript File -->
  <script src="../Bootstrap/contactform/contactform.js"></script>

  <!-- Template Main Javascript File -->
  <script src="../Bootstrap/js/main.js"></script>