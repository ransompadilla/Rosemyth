<?php
$str="";$flag="";
if(isset($_COOKIE['flag'])){
	$flag=$_COOKIE['flag'];
}
else{$flag=$flag;}
  if(isset($_GET['id'])){
    $course = $this->model->GetCourseByID(array($_GET['id']));
      $unsched_student_course = $this->model->GetUnSchedStudenyByCourse($_GET['id']);
      $donesched_student_course = $this->model->GetDoneSchedStudenyByCourse($_GET['id']);
      $gen = ""; 
      $session = $this->model->GetOpenSessionByCourse(array($_GET['id']));
      if($session){
        $start = strtotime($session['start_date']);
        $end = strtotime($session['end_date']);
        $start_d = Date('F/d/Y', $start);
        $end_d = Date('F/d/Y', $end);

        $str = $start_d." - ".$end_d;
      }
      else{$str="<b>NOTE: Please set a new Session to set SCHEDULE.</b>";}
    }
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
        
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <div class="nav-tabs-navigation">
                                        <div class="nav-tabs-wrapper">
                                           <h3>MANAGE SCHEDULE</h3>
                                        </div>
                                    </div>
                                </div>
                                <div class="card-content">

                                    <div class="row">
                                    	
                                        <div class="well col-lg-4" id=""  style="background-color: #e0e0e0; padding: 20px; border: 1px;">
                                        <div class="card-header" data-background-color="purple">
		                                    <div class="nav-tabs-navigation">
		                                        <div class="nav-tabs-wrapper">
		                                           <h3>ADD SCHEDULE</h3>
		                                        </div>
		                                    </div>
		                                </div>
										<form method="POST">
										<input type="hidden" name="session_id" value="<?php echo $session['session_id']?>"/>
										  <div class="col-md-offset-3">
											  <select name="co_id" class="form-control" id="course">
												<option value="">Choose Course</option>
												<?php
													if(count($v_courses) > 0){
														foreach($v_courses as $vc){
															if($_GET['id'] == $vc['co_id']){
																echo '<option value="'.$vc['co_id'].'"selected>'.$vc['co_name'].'</option>';
															}
															else{
																echo '<option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>';
															}
															
														}
													}
												?>
											  </select>
											  
										  </div>
										  <h3 class="well" data-background-color="green" style="text-align: center;"><?php echo $str;?></h3>
										  <div class="row">
											<div class="col-md-6">
												<label>Start Day of the Week: </label>
												 <select class="form-control" name="week_day_start" required="">
												<option value="">Choose day</option>
												<?php
													$week = array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
													for($i=0;$i<count($week);$i++){
														echo '<option value="'.$week[$i].'">'.$week[$i].'</option>';
													}
												?>
											  </select>
											  
											</div>
											<div class="col-md-6">
												
											  <label>End Day of the Week: </label>
												<select class="form-control" name="week_day_end" required="">
												<option value="">Choose day</option>
													<?php
														$week = array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
														for($i=0;$i<count($week);$i++){
															echo '<option value="'.$week[$i].'">'.$week[$i].'</option>';
														}
													?>
												</select>
											</div>
										  </div>
										  <div class="row">
											<div class="col-md-6">
												<label>Start Hour: </label>
												<input type="time" class="form-control" name="start_hour" required="">
												
											  
											</div>
											<div class="col-md-6">
												
											  <label>End Hour: </label>
											  <input type="time" class="form-control" name="end_hour" required="">
												
											</div>
										  </div>

										<div class="row">
											<div class="col-md-12">
										  <input type="text" name="stud_limit" class="form-control" placeholder="Student Limit" required="">
										    </div>
										</div>

										<div class="row">
											<div class="col-md-12">
										  <button type="submit" name="add_schedule" class="btn btn-info" style="width:100%;">Submit</button>
										    </div>
										</div>
										<div class="row">
											<div class="col-md-12">
										  
											<p>
											  <?php if($flag == "ok"){

												echo '<div class="alert alert-success alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Successfully Register </div>';
											  }
											  else if($flag == "notok"){

												echo '<div class="alert alert-danger alert-dismissable"><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button> Please set session first </div>';
											  }
											  
											  ?>
											  
											</p>
											</div>
										</div>
										</form>
                                    </div>
                           
                            <div class="col-lg-8" style="background-color: #f0f0f0; padding: 20px; border: 1px;">
                            	<div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                   <h4 class="title">Schedule</h4>
                                    <!-- <p id="result"></p> -->
                                    <!-- <p class="category">Users (<?php echo count($all_users);?>)</p> -->
                                </div>
                                <div class="card-content" >
                                    <div class="tab-content">
                                       
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>WEEK</th>
                                                        <th>HOUR</th>
                                                        <th>COURSE</th>
                                                        <th>SESSION</th>
                                                        <th>No Of Student</th>
                                                        <th>LIMIT</th>
                                                        <th>SETTING</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $stat="";$s_time="";$e_time="";$time="";
                                                    if(count($schedule) > 0){
                                                        
                                                        foreach ($schedule as $sched) {
                                                        	  $count_sched = $this->model->CountStudentBySchedule($sched['sched_id']);
                                                        	$sched_start = strtotime($sched['start_date']);
													        $sched_end = strtotime($sched['end_date']);
													        $sched_start_d = Date('F/d/Y', $sched_start);
													        $sched_end_d = Date('F/d/Y', $sched_end);

													        if($sched['sched_time_start'] < 12){
													        	$s_time = $sched['sched_time_start']." AM";
													        }
													        else{
													        	$s_time = $sched['sched_time_start']." PM";
													        }
													        if($sched['sched_time_end'] < 12){
													        	$e_time = $sched['sched_time_end']." AM";
													        }
													        else{
													        	$e_time = $sched['sched_time_end']." PM";
													        }
													        
                                                        	echo '<tr>
                                                        		<td>'.$sched['sched_week_start'].' - '.$sched['sched_week_end'].'</td>
                                                        		<td>'.$s_time.' - '.$e_time.'</td>
                                                        		<td>'.$sched['co_name'].'</td>
                                                        		<td>'.$sched_start_d.' - '.$sched_end_d.'</td>
                                                        		<td>'.count($count_sched).'</td>
                                                        		<td>'.$sched['stud_limit'].'</td>
                                                        		<td><a data-toggle="modal" href="#update_sched'.$sched['sched_id'].'" class="fa fa-edit"></a> <a href="#" class="fa fa-trash"></a></td>
                                                        	</tr>';
                                                            }
                                                            
                                                          }
                                                        
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                            
                                        </div>
                                        
                                </div>
                            </div>
                            </div>
                             </div>
                                     	</div>
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>

 <?php 
 	for($i=1; $i<=$maxSched; $i++){
 		$u_sched = $this->model->GetScheduleByID(array($i));
 		echo '
 			<div class="modal fade" id="update_sched'.$i.'" role="dialog">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content" style="width:150%; margin-left: -80px; margin-top: -80px;">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">UPDATE SCHEDULE</h4>
                </div>
                <div class="modal-body" >
                 	<div class="well col-lg-12" id=""  style="background-color: #e0e0e0; padding: 20px; border: 1px;">
                                        
										<form method="POST">
										<input type="hidden" name="sched_id" value="'.$u_sched['sched_id'].'"/>
										  <div class="col-md-offset-3">
											  <select name="co_id" class="form-control" id="course">
												<option value="">Choose Course</option>';
													if(count($v_courses) > 0){
														foreach($v_courses as $vc){
															if($u_sched['co_id'] == $vc['co_id']){
																echo '<option value="'.$vc['co_id'].'"selected>'.$vc['co_name'].'</option>';
															}
															else{
																echo '<option value="'.$vc['co_id'].'">'.$vc['co_name'].'</option>';
															}
															
														}
													}
											  echo '</select>
											  
										  </div>

										    <div class="row">
											<div class="col-md-6">
												<label>Start Day of the Week: </label>
												 <select class="form-control" name="week_day_start" required="">
												<option value="">Choose day</option>';
													$week = array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
													for($j=0;$j<count($week);$j++){
														if($u_sched['sched_week_start'] == $week[$j]){
															echo '<option value="'.$week[$j].'" selected>'.$week[$j].'</option>';
														}
														else{
															echo '<option value="'.$week[$j].'">'.$week[$j].'</option>';
														}
													}
												
											  echo '</select>
											  
											</div>
											<div class="col-md-6">
												
											  <label>End Day of the Week: </label>
												<select class="form-control" name="week_day_end" required="">
												<option value="">Choose day</option>';
														$week = array("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday");
														for($k=0;$k<count($week);$k++){
															if($u_sched['sched_week_end'] == $week[$k]){
																echo '<option value="'.$week[$k].'" selected>'.$week[$k].'</option>';
															}
															else{
																echo '<option value="'.$week[$k].'">'.$week[$k].'</option>';
															}
														}
													
												echo '</select>
											</div>
										  </div>
										 <div class="row">
											<div class="col-md-6">
												<label>Start Hour: </label>
												<input type="time" value="'.$u_sched['sched_time_start'].'" class="form-control" name="start_hour" required="">
												
											  
											</div>
											<div class="col-md-6">
												
											  <label>End Hour: </label>
											  <input type="time" value="'.$u_sched['sched_time_end'].'" class="form-control" name="end_hour" required="">
												
											</div>
										  </div>

										<div class="row">
											<div class="col-md-12">
										  <input type="text" value="'.$u_sched['limit'].'" name="stud_limit" class="form-control" placeholder="Student Limit" required="">
										    </div>
										</div>

										<div class="row">
											<div class="col-md-12">
										  <button type="submit" name="update_schedule" class="btn btn-info" style="width:100%;">Update</button>
										    </div>
										</div>
										
										</form>
                                    </div>

                </div>

                <div class="modal-footer">
                
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
              
            </div>
          </div>
 		';
 	}
 ?>

 
