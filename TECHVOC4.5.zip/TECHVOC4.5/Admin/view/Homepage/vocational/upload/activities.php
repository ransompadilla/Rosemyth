<div class="content">
    <div class="container-fluid">
        <div class="row">
        	
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                   <h4 class="title">ACTIVITIES</h4>
                                    <!-- <p id="result"></p> -->
                                    <!-- <p class="category">Users (<?php echo count($all_users);?>)</p> -->
                                </div>
                                <div class="card-content">
                                    <div class="tab-content">
                                       <div class="row">
                                           <div class="well col-md-3" style="padding: 20px;">
                                            <form method="POST" enctype="multipart/form-data">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="form-group label-floating">
                                                        <label class="control-label">Title</label>
                                                        <input type="text" name="act_title" class="form-control" placeholder="Title" required="" >
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group label-floating">
                                                        <label class="control-label">Description</label>
                                                        <input type="text" name="act_desc" class="form-control" placeholder="Description" required="">
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                    <label>Upload Image</label>
                                                    <div class="input-group">
                                                        <span class="input-group-btn">
                                                            <span class="btn btn-default btn-file">
                                                                Browse… <input type="file" name="fileToUpload" id="fileToUpload" required="">
                                                            </span>
                                                        </span>
                                                        <input type="text" class="form-control" readonly>
                                                    </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-12">
                                                 <button class="btn btn-primary" type="submit" name="upload_activities" style="width: 100%;">Upload</button>
                                                </div> 
                                            </div>
                                                
                                            </form>
                                               
                                           </div>
                                           <div class="well col-md-9">
                                            <div class="content">
                                            <div class="container-fluid">
                                                
                                                <div class="row">
                                                  <?php
                                                    if(count($act) > 0){

                                                      foreach ($act as $a) {
                                                        echo '
                                                        <a href="#">

                                                          <div id="course" class="col-md-4">
                                                              <div class="card">
                                                                  <img src="'.$a['act_img'].'" class="img-fluid" alt="" style="width: 100%; height: 150px;">
                                                                  <div class="card-content">
                                                                      <h4 class="title">'.$a['act_title'].'</h4>
                                                                      <p class="category">
                                                                       '.$a['act_desc'].'
                                                                      </p>
                                                                  </div>
                                                                  <div class="card-footer">
                                                                      <div class="stats">
                                                                        
                                                                      </div>
                                                                  </div>
                                                              </div>
                                                          </div>
                                                        ';       
                                                      }
                                                    }
                                                  ?>
                                                </div>
                                              
                                            </div>
                                            
                                        </div>
                                           </div>
                                       </div>
                                            
                                            
                                    </div>
                                        
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>
    </div>
