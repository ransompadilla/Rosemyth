<div class="content">
    <div class="container-fluid">
        <div class="row">
        	
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                   <h4 class="title">USERS</h4>
                                    <!-- <p id="result"></p> -->
                                    <!-- <p class="category">Users (<?php echo count($all_users);?>)</p> -->
                                </div>
                                <div class="card-content">
                                    <div class="tab-content">
                                       
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>IDNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>COURSE</th>
                                                        <th>STATUS</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $stat="";
                                                    if(count($all_users) > 0){
                                                        
                                                        foreach ($all_users as $ens) {
                                                        	if($ens['en_status'] == 1 and $ens['session_id'] != NULL){
                                                       
                                                                if($ens['en_gender'] =="M" || $ens['user_gender'] =="M"){
                                                                    $gen="Male";
                                                                }
                                                                else{$gen="Female";}
                                                            if($ens['ref_id'] == $ens['user_id']){
                                                            	echo '<tr data-toggle="#" data-target="#'.$ens['ref_id'].'">
                                                              <td>'.$ens['ref_id'].'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['co_name'].'</td>
                                                              <td><a class="btn btn-info" href="index.php?q=vocational/update-registrant&id='.$ens['en_id'].'">Update</a> | <button id="'.$ens['en_id'].'" class="btnDrop btn btn-danger">Drop</button></td>
                                                              </tr>';
                                                            }
                                                            
                                                          }
                                                        }
                                                    	
                                                    }
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                            
                                        </div>
                                        
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>
    </div>
