<?php
	require '../../../PHPMailer/PHPMailerAutoload.php';
			$mail = new PHPMailer;
			// $mail->isSMTP();

			// $mail->SMTPAuth="true";
			// $mail->SMTPSecure="ssl";
			// $mail->Host = "smtp.gmail.com";
			// $mail->Port=465;
			//  $mail->isHTML();
			// $mail->Username="jhudey28@gmail.com";
			// $mail->Password="jhudeymarc";
			// $mail->setForm('no-reply@howcode.org','developer');
			// $mail->From = 'no-reply@howcode.org';
			// $mail->subject="Information";
			// $mail->Body="You are now enrolled this is your schedule monday-friday";
			// $mail->addAddress('padillaransom@gmail.com');
			// if($mail->send()){
			// 	echo "mail sent";
			// }
			// else {
			// 	echo "mail sending failed";
			// }
	$mail->SMTPDebug = 2;
$mail->isSMTP();     
$mail->Host="relay-hosting.secureserver.net";
$mail->Port= 25;
$mail->SMTPAuth= false;                               // Enable SMTP authentication
$mail->Username = 'jhudey28@gmail.com';                 // SMTP username
$mail->Password = 'jhudeymarc';                           // SMTP password
$mail->SMTPSecure = 'ssl';                                 // TCP port to connect to

$mail->setFrom('jhudey28@gmail.com', 'Mailer');
$mail->addAddress('padillaransom@gmail.com');     // Add a recipient
//$mail->addAddress('ellen@example.com');               // Name is optional
// $mail->addReplyTo('info@example.com', 'Information');
// $mail->addCC('cc@example.com');
// $mail->addBCC('bcc@example.com');

// $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = 'Here is the subject';
$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}
?>