-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 02, 2018 at 01:25 PM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `techvoc_sql`
--

-- --------------------------------------------------------

--
-- Table structure for table `activities`
--

CREATE TABLE IF NOT EXISTS `activities` (
  `act_id` int(11) NOT NULL AUTO_INCREMENT,
  `act_title` varchar(100) DEFAULT NULL,
  `act_desc` varchar(1000) DEFAULT NULL,
  `act_img` blob,
  `co_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`act_id`),
  KEY `act_course` (`co_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `activities`
--

INSERT INTO `activities` (`act_id`, `act_title`, `act_desc`, `act_img`, `co_id`) VALUES
(42, 'General Cleaning', 'General Cleaning', 0x2e2e2f426f6f7473747261702f696d672f616374697669746965732f46425f494d475f313531333035303834333439312e6a7067, 1),
(43, 'title', 'Description', 0x2e2e2f426f6f7473747261702f696d672f616374697669746965732f6275736869742e706e67, 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_fname` varchar(25) DEFAULT NULL,
  `admin_lname` varchar(25) DEFAULT NULL,
  `admin_gender` char(1) DEFAULT NULL,
  `admin_address` varchar(50) DEFAULT NULL,
  `admin_contact` varchar(15) DEFAULT NULL,
  `admin_email` varchar(25) DEFAULT NULL,
  `admin_password` varchar(25) DEFAULT NULL,
  `admin_img` blob,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_fname`, `admin_lname`, `admin_gender`, `admin_address`, `admin_contact`, `admin_email`, `admin_password`, `admin_img`) VALUES
(1, 'Ransom', 'Carino', 'M', 'Talisay', NULL, NULL, NULL, NULL),
(2, 'Ransom', 'Carino', 'M', 'Talisay', '09234815395', 'ransom@yahoo.com', 'ransom', 0x2e2e2f426f6f7473747261702f696d672f31353431393738385f3335353337383136313532313432335f3931383833303738393436303331353138355f6f2e6a7067),
(3, 'Recca Jane', 'Valencia', 'F', 'Lahug Cebu City', '09123242222', 'recca@yahoo.com', 'recca', 0x2e2e2f426f6f7473747261702f696d672f3535393534365f3737373635393039323237333539335f323831353431353838383138323236313033305f6e2e6a7067),
(4, 'Rico', 'Valencio', 'M', 'Bulacao', '09234815395', 'rico@yahoo.com', 'rico', NULL),
(5, 'joefel', 'paclibar', 'M', 'Orgello Cebu City', '09234815395', 'paclibar@gmail.com', 'paclibar', NULL),
(6, 'boom', 'song', 'M', 'boomsong', '34234343', 'boom@gmail.com', 'boom', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `announcement`
--

CREATE TABLE IF NOT EXISTS `announcement` (
  `an_id` int(11) NOT NULL AUTO_INCREMENT,
  `an_details` varchar(999) DEFAULT NULL,
  `an_time` datetime DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `admin_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`an_id`),
  KEY `code` (`co_id`),
  KEY `admin` (`admin_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `assessment`
--

CREATE TABLE IF NOT EXISTS `assessment` (
  `info_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `info_region` varchar(50) DEFAULT NULL,
  `info_province` varchar(50) DEFAULT NULL,
  `info_district` varchar(50) DEFAULT NULL,
  `info_city` varchar(50) DEFAULT NULL,
  `info_provider` varchar(50) DEFAULT NULL,
  `info_address` varchar(100) DEFAULT NULL,
  `info_typeofprovider` varchar(50) DEFAULT NULL,
  `info_classification_provider` varchar(50) DEFAULT NULL,
  `info_industry_sector` varchar(50) DEFAULT NULL,
  `info_prog_reg_stat` varchar(50) DEFAULT NULL,
  `info_prog_title` varchar(80) DEFAULT NULL,
  `info_ctpr` varchar(50) DEFAULT NULL,
  `info_training_calendar_mode` varchar(50) DEFAULT NULL,
  `info_delivery_mode` varchar(80) DEFAULT NULL,
  `info_voucher_no` varchar(25) DEFAULT NULL,
  `info_date_started` varchar(25) DEFAULT NULL,
  `info_date_finished` varchar(25) DEFAULT NULL,
  `info_date_assessed` varchar(25) DEFAULT NULL,
  `info_assessment_result` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`info_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `assessment`
--

INSERT INTO `assessment` (`info_id`, `user_id`, `info_region`, `info_province`, `info_district`, `info_city`, `info_provider`, `info_address`, `info_typeofprovider`, `info_classification_provider`, `info_industry_sector`, `info_prog_reg_stat`, `info_prog_title`, `info_ctpr`, `info_training_calendar_mode`, `info_delivery_mode`, `info_voucher_no`, `info_date_started`, `info_date_finished`, `info_date_assessed`, `info_assessment_result`) VALUES
(4, 1003, 'sdfdsf', 'dfdsf', 'kjlkjkjklj', 'kjlkjkjkl', 'kjlkjkjkjk', 'lklkjkjkljkl', 'lkjkjlkjlk', 'lkjkljkjlkjlk', 'jkjlkjlkjkl', 'kjkljlkjlkjkl', 'lkjkljkljlk', 'jkljlkjkj', 'kjlkjlkjkljk', 'ljlkjkljkljk', 'klkjlk', '2018-03-17', '2018-03-16', '2018-03-23', 'fdsfsdf');

-- --------------------------------------------------------

--
-- Table structure for table `course_offer`
--

CREATE TABLE IF NOT EXISTS `course_offer` (
  `co_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_name` varchar(25) DEFAULT NULL,
  `co_desc` varchar(100) DEFAULT NULL,
  `co_limit` int(11) DEFAULT NULL,
  `co_img` blob,
  `co_active` int(1) DEFAULT NULL,
  PRIMARY KEY (`co_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `course_offer`
--

INSERT INTO `course_offer` (`co_id`, `co_name`, `co_desc`, `co_limit`, `co_img`, `co_active`) VALUES
(1, 'HouseKeeping NCII', 'HouseKeeping NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f686f7573652e6a7067, 1),
(2, 'Cookery NCII', 'Cookery NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f636f6f6b2e6a7067, 1),
(3, 'Food & Beverage Services ', 'Food & Beverage Services NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f6261722e6a7067, 1),
(4, 'Bartending NCII', 'Bartending NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f6261722e6a7067, 1),
(5, 'Welding (SMAW) NC I', 'Welding (SMAW) NC I', 50, 0x2e2e2f426f6f7473747261702f696d672f636f757273652f494d475f32303138303130385f3133323530395f427572737430362e6a7067, 1),
(6, 'Computer System Servicing', 'Computer System Servicing NCII', 50, 0x2e2e2f426f6f7473747261702f696d672f656d672f636f6d2e6a7067, 1),
(8, 'Welding (SMAW) NCI', 'Welding (SMAW) NCI', 50, 0x2e2e2f426f6f7473747261702f696d672f636f757273652f46425f494d475f313531333035303630353637362e6a7067, 1),
(9, 'Automotive NCII', 'Automotive NCII', 34, 0x2e2e2f426f6f7473747261702f696d672f636f757273652f46425f494d475f313531333035303630353637362e6a7067, 1),
(15, 'Electrical NCII', 'Electrical NCII', 30, 0x2e2e2f426f6f7473747261702f696d672f636f757273652f46425f494d475f313531333035303634323036332e6a7067, 1),
(16, 'Welding (SMAW) NCI', 'hoi', 20, 0x2e2e2f426f6f7473747261702f696d672f636f757273652f494d475f32303138303130385f3133323530395f427572737430322e6a7067, 0),
(17, 'Automotive NCII', 'Automotive NCII', 250, 0x2e2e2f426f6f7473747261702f696d672f636f757273652f46425f494d475f313531333035303934363438302e6a7067, 1),
(19, 'gdgdgg', 'dgdgd', 45, 0x2e2e2f426f6f7473747261702f696d672f636f757273652f46425f494d475f313531333035303630353637362e6a7067, 0);

-- --------------------------------------------------------

--
-- Table structure for table `drop_retrieve`
--

CREATE TABLE IF NOT EXISTS `drop_retrieve` (
  `std_id` int(11) NOT NULL AUTO_INCREMENT,
  `st_d_remark` varchar(999) DEFAULT NULL,
  `st_r_remark` varchar(999) DEFAULT NULL,
  `st_d_date` datetime DEFAULT NULL,
  `st_r_date` datetime DEFAULT NULL,
  `en_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`std_id`),
  KEY `enrollment_id` (`en_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Dumping data for table `drop_retrieve`
--

INSERT INTO `drop_retrieve` (`std_id`, `st_d_remark`, `st_r_remark`, `st_d_date`, `st_r_date`, `en_id`) VALUES
(14, 'absent', 'want to school', '2018-03-12 07:40:47', '2018-03-12 07:41:02', 46),
(15, 'change course   ', NULL, '2018-03-13 08:37:58', NULL, 48);

-- --------------------------------------------------------

--
-- Table structure for table `enrollment`
--

CREATE TABLE IF NOT EXISTS `enrollment` (
  `en_id` int(11) NOT NULL AUTO_INCREMENT,
  `en_fname` varchar(25) DEFAULT NULL,
  `en_lname` varchar(25) DEFAULT NULL,
  `en_mi` varchar(25) DEFAULT NULL,
  `en_num_street` varchar(50) DEFAULT NULL,
  `en_barangay` varchar(50) DEFAULT NULL,
  `en_district` varchar(25) DEFAULT NULL,
  `en_city` varchar(25) DEFAULT NULL,
  `en_province` varchar(50) DEFAULT NULL,
  `en_region` varchar(50) DEFAULT NULL,
  `en_email_add` varchar(50) DEFAULT NULL,
  `en_contact` varchar(15) DEFAULT NULL,
  `en_nationality` varchar(25) DEFAULT NULL,
  `en_gender` char(1) DEFAULT NULL,
  `en_civilstatus` varchar(15) DEFAULT NULL,
  `en_empstatus` varchar(15) DEFAULT NULL,
  `en_bdate` date DEFAULT NULL,
  `en_age` int(3) DEFAULT NULL,
  `en_birthplace` varchar(100) DEFAULT NULL,
  `en_father_fname` varchar(25) DEFAULT NULL,
  `en_father_lname` varchar(25) DEFAULT NULL,
  `en_mother_fname` varchar(25) DEFAULT NULL,
  `en_mother_lname` varchar(25) DEFAULT NULL,
  `en_edattainment` varchar(70) DEFAULT NULL,
  `en_lts` varchar(70) DEFAULT NULL,
  `en_taken_where` varchar(25) DEFAULT NULL,
  `en_taken_when` varchar(25) DEFAULT NULL,
  `en_stud_voucher_no` varchar(25) DEFAULT NULL,
  `en_scholar_package` varchar(70) DEFAULT NULL,
  `en_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `ref_id` int(11) DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `en_status` int(1) DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `sched_id` int(11) DEFAULT NULL,
  `tr_id` int(11) DEFAULT NULL,
  `en_active` int(1) DEFAULT NULL,
  PRIMARY KEY (`en_id`),
  KEY `ref_id` (`ref_id`),
  KEY `co_id` (`co_id`),
  KEY `session` (`session_id`),
  KEY `schedule` (`sched_id`),
  KEY `trainer` (`tr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=52 ;

--
-- Dumping data for table `enrollment`
--

INSERT INTO `enrollment` (`en_id`, `en_fname`, `en_lname`, `en_mi`, `en_num_street`, `en_barangay`, `en_district`, `en_city`, `en_province`, `en_region`, `en_email_add`, `en_contact`, `en_nationality`, `en_gender`, `en_civilstatus`, `en_empstatus`, `en_bdate`, `en_age`, `en_birthplace`, `en_father_fname`, `en_father_lname`, `en_mother_fname`, `en_mother_lname`, `en_edattainment`, `en_lts`, `en_taken_where`, `en_taken_when`, `en_stud_voucher_no`, `en_scholar_package`, `en_date`, `ref_id`, `co_id`, `en_status`, `session_id`, `sched_id`, `tr_id`, `en_active`) VALUES
(46, 'Christopher', 'Barro', 'Alejaga', '090', 'Biasong', 'II', 'Talisay', 'Cebu', 'VII', 'barro@yahoo.com', '09234815395', 'Pilipino', 'M', 'Married', 'Employed', '2018-03-08', 22, 'Mohon Talisay City Cebu', 'Rodel', 'Barro', 'Marna', 'Barro', NULL, 'Solo Parent', '', '', '', '', '2018-03-07 16:56:54', NULL, 6, 1, NULL, NULL, 1, 1),
(48, 'Editha', 'Carino', 'Padilla', '090', 'Biasong', 'II', 'Talisay', 'Cebu', 'VII', 'editha@gmail.com', '09234815395', 'Pilipino', 'F', 'Married', 'Unemplyed', '1980-09-08', 50, 'ZN Del Norte', 'Lino', 'Padilla', 'Elpedia', 'Padilla', 'College Undergraduate', 'Solo Parent', '', '', '', '', '2018-03-09 06:14:13', NULL, 6, 2, NULL, NULL, 1, 1),
(49, 'Ghe Mariefe', 'Trazona', 'Millor', '089', 'Biasong', 'II', 'Talisay', 'Cebu', 'VII', 'ghe@yahoo.com', '09234815395', 'Pilipino', 'F', 'Single', 'Unemplyed', '1997-11-16', 20, 'Mohon Talisay City Cebu', 'Noli', 'Millor', 'Josephine', 'Millor', 'College Undergraduate', 'Others', '', '', '', '', '2018-03-09 06:35:16', NULL, 1, 0, NULL, NULL, NULL, 1),
(51, 'Kevin', 'Patalinghug', 'Sabellano', '102', 'Biasong', 'II', 'Talisay', 'Cebu', 'VII', 'kevin@gmail.com', '09234185395', 'Pilipino', 'M', 'Single', 'Employed', '1993-07-16', 24, 'Mohon Talisay City Cebu', 'Danny', 'Patalinghug', 'Elie', 'Patalinghug', 'College Undergraduate', 'Others', '', '', '', '', '2018-03-10 01:56:09', 1001, 6, 3, NULL, NULL, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE IF NOT EXISTS `schedule` (
  `sched_id` int(11) NOT NULL AUTO_INCREMENT,
  `sched_week_start` varchar(15) DEFAULT NULL,
  `sched_week_end` varchar(15) DEFAULT NULL,
  `sched_time_start` varchar(10) DEFAULT NULL,
  `sched_time_end` varchar(10) DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `stud_limit` int(3) NOT NULL,
  PRIMARY KEY (`sched_id`),
  KEY `session_schedule` (`session_id`),
  KEY `course_id` (`co_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `session`
--

CREATE TABLE IF NOT EXISTS `session` (
  `session_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_id` int(11) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `session_status` int(1) DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  KEY `co_id_session` (`co_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `session`
--

INSERT INTO `session` (`session_id`, `co_id`, `start_date`, `end_date`, `session_status`) VALUES
(22, 6, '2018-03-12', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `trainor`
--

CREATE TABLE IF NOT EXISTS `trainor` (
  `tr_id` int(11) NOT NULL AUTO_INCREMENT,
  `tr_lname` varchar(50) DEFAULT NULL,
  `tr_fname` varchar(50) DEFAULT NULL,
  `tr_gender` char(1) DEFAULT NULL,
  `tr_age` int(3) DEFAULT NULL,
  `tr_contact` varchar(15) DEFAULT NULL,
  `tr_address` varchar(100) DEFAULT NULL,
  `tr_active` int(1) DEFAULT NULL,
  PRIMARY KEY (`tr_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `trainor`
--

INSERT INTO `trainor` (`tr_id`, `tr_lname`, `tr_fname`, `tr_gender`, `tr_age`, `tr_contact`, `tr_address`, `tr_active`) VALUES
(1, 'Carino', 'Ransom', 'M', 23, '09234185395', 'Biasong, Talisay City, Cebu', 1),
(2, 'Trazona', 'Ghe Mariefe', 'F', 20, '09234185395', 'Biasong, Talisay City, Cebu', 1),
(3, 'Bonje', 'Ronald', 'M', 23, '09323245232', 'Lahug Cebu City', 1),
(4, 'song boom', 'boomsong ', 'M', 22, '093544233563', 'Talisay', 0),
(5, 'panesboom', 'booompanes', 'F', 23, '09233223323', 'Bisag asa ', 0),
(6, 'meadd', 'add me', 'M', 22, '09234235236', 'bisag asa lng gud', 0);

-- --------------------------------------------------------

--
-- Table structure for table `trainor_course`
--

CREATE TABLE IF NOT EXISTS `trainor_course` (
  `tr_course` int(11) NOT NULL AUTO_INCREMENT,
  `tr_id` int(11) DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `hr_limit` int(11) DEFAULT NULL,
  `tr_course_date` datetime DEFAULT NULL,
  PRIMARY KEY (`tr_course`),
  KEY `trainor_course_id` (`tr_id`),
  KEY `course_trainor_id` (`co_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `trainor_course`
--

INSERT INTO `trainor_course` (`tr_course`, `tr_id`, `co_id`, `hr_limit`, `tr_course_date`) VALUES
(12, 1, 6, 500, '2018-03-12 06:36:05'),
(13, 2, 6, 500, '2018-03-12 06:45:37'),
(14, 3, 8, 500, '2018-03-21 01:37:48');

-- --------------------------------------------------------

--
-- Table structure for table `trainor_schedule`
--

CREATE TABLE IF NOT EXISTS `trainor_schedule` (
  `tr_sched` int(11) NOT NULL AUTO_INCREMENT,
  `tr_sched_day` varchar(15) DEFAULT NULL,
  `tr_sched_start_time` time DEFAULT NULL,
  `tr_sched_end_time` time DEFAULT NULL,
  `tr_hour` int(11) DEFAULT NULL,
  `tr_id` int(11) DEFAULT NULL,
  `co_id` int(11) DEFAULT NULL,
  `tr_sched_date` datetime DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tr_sched`),
  KEY `course_trainor` (`co_id`),
  KEY `trainor` (`tr_id`),
  KEY `session_idd` (`session_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `trainor_schedule`
--

INSERT INTO `trainor_schedule` (`tr_sched`, `tr_sched_day`, `tr_sched_start_time`, `tr_sched_end_time`, `tr_hour`, `tr_id`, `co_id`, `tr_sched_date`, `session_id`) VALUES
(18, 'Monday', '07:30:00', '15:30:00', 8, 1, 6, '2018-03-12 06:36:52', 22),
(19, 'Tuesday', '13:30:00', '19:30:00', 6, 2, 6, '2018-03-12 06:46:20', 22),
(20, 'Wednesday', '07:30:00', '14:30:00', 7, 1, 6, '2018-03-12 06:47:06', 22),
(21, 'Friday', '14:30:00', '19:30:00', 5, 1, 6, '2018-03-12 06:47:57', 22),
(22, 'Monday', '08:00:00', '16:00:00', 8, 3, 8, '2018-03-21 01:38:36', NULL),
(23, 'Wednesday', '09:00:00', '17:00:00', 8, 3, 8, '2018-03-21 01:39:07', NULL),
(24, 'Friday', '13:30:00', '17:30:00', 4, 3, 8, '2018-03-21 01:39:48', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_fname` varchar(25) DEFAULT NULL,
  `user_lname` varchar(25) DEFAULT NULL,
  `user_gender` char(1) DEFAULT NULL,
  `user_address` varchar(50) DEFAULT NULL,
  `user_bdate` date DEFAULT NULL,
  `user_age` int(11) DEFAULT NULL,
  `user_contact` varchar(15) DEFAULT NULL,
  `user_email` varchar(25) DEFAULT NULL,
  `user_password` varchar(25) DEFAULT NULL,
  `user_img` blob,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1006 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_fname`, `user_lname`, `user_gender`, `user_address`, `user_bdate`, `user_age`, `user_contact`, `user_email`, `user_password`, `user_img`) VALUES
(12, 'Ransom', 'Carino', 'M', 'Biasong, Talisay City, Cebu', '1995-05-05', 22, '09234815395', 'padillaransom@gmail.com', 'ransom', NULL),
(1003, 'Jhudey', 'Carino', 'M', 'Talisay', '2001-02-03', NULL, '09234815395', 'jhudey@yahoo.com', 'jhudey', NULL),
(1004, 'Recca Jane', 'Valencia', 'F', 'Sibonga', '1997-03-31', NULL, '09123242222', 'recca@yahoo.com', 'recca', NULL),
(1005, 'Ronald', 'Bonje', 'M', 'Lahug Cebu City', '1994-03-22', NULL, '09233026191', 'ronald@yahoo.com', 'ronald', NULL);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activities`
--
ALTER TABLE `activities`
  ADD CONSTRAINT `act_course` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE;

--
-- Constraints for table `announcement`
--
ALTER TABLE `announcement`
  ADD CONSTRAINT `admin` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`admin_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `code` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE;

--
-- Constraints for table `assessment`
--
ALTER TABLE `assessment`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON UPDATE CASCADE;

--
-- Constraints for table `drop_retrieve`
--
ALTER TABLE `drop_retrieve`
  ADD CONSTRAINT `enrollment_id` FOREIGN KEY (`en_id`) REFERENCES `enrollment` (`en_id`) ON UPDATE CASCADE;

--
-- Constraints for table `enrollment`
--
ALTER TABLE `enrollment`
  ADD CONSTRAINT `co_id` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `schedule` FOREIGN KEY (`sched_id`) REFERENCES `schedule` (`sched_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `session` FOREIGN KEY (`session_id`) REFERENCES `session` (`session_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `trainer` FOREIGN KEY (`tr_id`) REFERENCES `trainor` (`tr_id`) ON UPDATE CASCADE;

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `course_id` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `session_schedule` FOREIGN KEY (`session_id`) REFERENCES `session` (`session_id`) ON UPDATE CASCADE;

--
-- Constraints for table `session`
--
ALTER TABLE `session`
  ADD CONSTRAINT `co_id_session` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE;

--
-- Constraints for table `trainor_course`
--
ALTER TABLE `trainor_course`
  ADD CONSTRAINT `course_trainor_id` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `trainor_course_id` FOREIGN KEY (`tr_id`) REFERENCES `trainor` (`tr_id`) ON UPDATE CASCADE;

--
-- Constraints for table `trainor_schedule`
--
ALTER TABLE `trainor_schedule`
  ADD CONSTRAINT `course_trainor` FOREIGN KEY (`co_id`) REFERENCES `course_offer` (`co_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `session_idd` FOREIGN KEY (`session_id`) REFERENCES `session` (`session_id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `trainor` FOREIGN KEY (`tr_id`) REFERENCES `trainor` (`tr_id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
