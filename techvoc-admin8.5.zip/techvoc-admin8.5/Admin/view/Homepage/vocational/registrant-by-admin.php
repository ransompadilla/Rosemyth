<div class="content">
    <div class="container-fluid">
        <div class="row">
        	
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                   <h4 class="title">REGISTRANT</h4>
                                    <!-- <p id="result"></p> -->
                                   
                                </div>
                                <div class="card-content">
                                    <div class="tab-content">
                                       
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>IDNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>COURSE</th>
                                                        <th>STATUS</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $stat="";$ref = "";
                                                    if(count($registrants) > 0){
                                                        
                                                        foreach ($registrants as $ens) {

                                                        	if($ens['en_status'] == 1 and $ens['session_id'] != NULL){
                                                       
                                                                if($ens['en_gender'] =="M" || $ens['user_gender'] =="M"){
                                                                    $gen="Male";
                                                                }
                                                                else{$gen="Female";}
                                                            if($ens['ref_id'] == NULL){
                                                            	$ref = $name;
                                                            }else{
                                                            	$ref = $ens['ref_id'];
                                                            }
                                                            	echo '<tr data-toggle="#" data-target="#'.$ens['ref_id'].'">
                                                              <td>'.$ref.'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['co_name'].'</td>
                                                              <td><button id="'.$ens['en_id'].'" class="btnDrop btn btn-danger">Drop</button></td>
                                                              </tr>';
                                                            }
                                                            
                                                          }
                                                        
                                                    	
                                                    }
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                            
                                        </div>
                                        
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>
    </div>
