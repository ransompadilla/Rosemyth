<?php
  if(isset($_GET['id'])){
    $course = $this->model->GetCourseByID(array($_GET['id']));
      $unsched_student_course = $this->model->GetUnSchedStudenyByCourse($_GET['id']);
      $donesched_student_course = $this->model->GetDoneSchedStudenyByCourse($_GET['id']);
      $count_reg = $this->model->CountRegistrantByCourse($_GET['id']);
      $count_drop = $this->model->CountEnrolledDropByCourse($_GET['id']);
      $drop_stud = $this->model->GetDropStudentByCourse($_GET['id']);
      $sched_course = $this->model->GetScheduleByCourse($_GET['id']);
      $gen = ""; $str="";
      $session = $this->model->GetOpenSessionByCourse(array($_GET['id']));
      if($session){
        $start = strtotime($session['start_date']);
        $end = strtotime($session['end_date']);
        $start_d = Date('F/d/Y', $start);
        $end_d = Date('F/d/Y', $end);

        $str = $start_d." - ".$end_d;
      }
      else{$str="<b>NOTE: Please set a new Session to set SCHEDULE.</b>";}
    }
?>
<div class="content">
    <div class="container-fluid">
        <div class="row">
        
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                    <div class="nav-tabs-navigation">

                                        <div class="nav-tabs-wrapper">
                                          <h3 ><?php echo $course['co_name'];?></h3>
                                            <ul class="nav nav-tabs" data-tabs="tabs">
                                                <li class="active">
                                                    <a href="#no_sched" data-toggle="tab">
                                                        <i class="material-icons">bug_report</i> <?php echo count($unsched_student_course);?> No Schedule
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                                <li class="">
                                                    <a href="#training" data-toggle="tab">
                                                        <i class="material-icons">code</i><?php echo count($donesched_student_course);?> Scheduled/Enrolled
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                               <li class="">
                                                    <a href="#reserved" data-toggle="tab">
                                                        <i class="material-icons">code</i><?php echo count($count_reg);?> RESERVED
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                                <li class="">
                                                    <a href="#dropped" data-toggle="tab">
                                                        <i class="material-icons">code</i><?php echo count($count_drop);?> Dropped
                                                        <div class="ripple-container"></div>
                                                    </a>
                                                </li>
                                            </ul>
                                            <!-- <i id="result" class="float-right">result</i> -->
                                        </div>
                                    </div>
                                </div>
                                <div class="card-content">
                                    <div class="tab-content">
                                      
                                        <div class="tab-pane active" id="no_sched">
                                          
                                            <table class="order-table table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>REFNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>EMAIL</th>
                                                        <th>CONTACT</th>
                                                        <th>STATUS</th>
                                                        <th>PAYMENT</th>
                                                        <th>SET SCHED</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $stat="";$ref = "";$stat2="";$stat3="";
                                                    if(count($unsched_student_course) > 0){
                                                        
                                                        foreach ($unsched_student_course as $ens) {
                                                          if($ens['en_status'] == 1){
                                                            $stat = '<a class="btn btn-xs btn-success" href="#">Training</a>';
                                                          }
                                                          else if($ens['en_status'] == 2){
                                                            $stat = '<a class="btn btn-xs btn-success" href="#">Drop</a>';
                                                          }
                                                                if($ens['en_gender'] =="M"){
                                                                    $gen="Male";
                                                                }
                                                                else{$gen="Female";}
                                                            if($ens['ref_id'] == ""){$ref="WALK-IN";}
															                              else{$ref=$ens['ref_id'];}
                                                              if($ens['en_stud_voucher_no'] != ""){
                                                              $stat2 = '<a class="btn btn-xs btn-info" href="#">Scholar</a>';
                                                            }
                                                            else{
                                                              $stat2 = '<a class="btn btn-xs btn-default" href="#">Regular</a>';
                                                            }
                                                            if($ens['en_status'] == 3){
                                                              $stat3 = '<a class="btn btn-xs btn-default" href="#">Partial</a>';
                                                            }
                                                            else if($ens['en_status'] == 1){
                                                              $stat3 = '<a class="btn btn-xs btn-info" href="#">Fullypaid</a>';
                                                            }
                                                                echo '<tr data-toggle="#" data-target="#'.$ens['en_id'].'">
                                                              <td>'.$ref.'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['en_email_add'].'</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              <td>'.$stat2.'</td>
                                                              <td>'.$stat3.'</td>
                                                              <td><a data-toggle="modal" class="btn btn-xs btn-success" href="#set_schedule'.$ens['en_id'].'">SET</a></td>
                                                              </tr>';
                                                          }
                                                      
                                                    }
                                                    ?>
                                                  
                                                   <!--   -->
                                                </tbody>
                                            </table>
                                           
                                           <div id="unschedPrintTable">
                                                <!-- INSERT HEADER IMG HERE -->
                                                <div class="center" style="text-align: center;">

                                                <img src="../Bootstrap/img/alumni/bc.jpg" alt="FB" style="width: 100%; height: 35%;"  />
                                                <p>Description1 : </p>
                                                <p>Description2 : </p>
                                                <p>Description3 : </p>
                                                <p>Description4 : </p>
                                                </div>
                                                <!-- END -->
                                                 <table class="table table-stripped" id="print-table">

                                                  <thead>
                                                    <tr>
                                                        <th>REFNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>EMAIL</th>
                                                        <th>CONTACT</th>
                                                        <th>STATUS</th>
                                                        <th>PAYMENT</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody>
                                                  
                                                    <?php
                                                     $reff="";
                                                    if(count($unsched_student_course) > 0){
                                                        foreach ($donesched_student_course as $ens) {
                                                          if($ens['en_active'] == 1){
                                                           
                                                          
                                                          if($ens['ref_id'] == ""){
                                                           $reff = "WALK-IN";
                                                          }
                                                          else{$reff = $ens['ref_id'];}

                                                        echo '<tr>
                                                              <td>'.$reff.'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['en_email_add'].'</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              
                                                              <td>'.$stat.'('.$stat2.') </td>
                                                              <td>'.$stat3.'</td>
                                                              </tr>';
                                                        }
                                                      } 
                                                          
                                                    }
                                                    
                                                    ?>
                                                  </tbody>
                                                </table> 
                                              </div>
                                             <a class="btn btn-primary" href="#" id="print" onclick="javascript:printLayer('unschedPrintTable')"><i class="fa fa-print"> Print</i></a>
                                        </div>
                                        <div class="tab-pane" id="training">
                                           <table class="order-table table" id="print-table">
                                                <thead>
                                                    <tr id="printme">
                                                        <th>REFNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>CONTACT</th>
                                                        <th>TRAINER</th>
                                                        <th>STATUS</th>
                                                        <th></th>
                                                        <th>PAYMENT</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $stat="";$ref="";$stat2="";$stat3="";
                                                    if(count($donesched_student_course) > 0){
                                                        
                                                        foreach ($donesched_student_course as $ens) {
                                                          // if($ens['sched_time_start'] < 12){
                                                          //   $s_time = $ens['sched_time_start']." AM";
                                                          // }
                                                          // else{
                                                          //   $s_time = $ens['sched_time_start']." PM";
                                                          // }
                                                          // if($ens['sched_time_end'] < 12){
                                                          //   $e_time = $ens['sched_time_end']." AM";
                                                          // }
                                                          // else{
                                                          //   $e_time = $ens['sched_time_end']." PM";
                                                          // }

                                                          if($ens['en_status'] == 1 || $ens['en_status'] == 3){
                                                            $stat = '<a class="btn btn-xs btn-success" href="#">Enrolled</a>';
                                                          }
                                                          else if($ens['en_status'] == 2){
                                                            $stat = '<a class="btn btn-xs btn-danger" href="#">Drop</a>';
                                                          }
                                                                if($ens['en_gender'] =="M"){
                                                                    $gen="Male";
                                                                }
                                                                else{$gen="Female";}
                                                            if($ens['ref_id'] == ""){
                                                              $ref = "WALK-IN";
                                                            }
                                                            else{$ref= $ens['ref_id'];}
                                                            if($ens['en_stud_voucher_no'] != ""){
                                                              $stat2 = '<a class="btn btn-xs btn-info" href="#">Scholar</a>';
                                                            }
                                                            else{
                                                              $stat2 = '<a class="btn btn-xs btn-default" href="#">Regular</a>';
                                                            }
                                                            if($ens['en_status'] == 3){
                                                              $stat3 = '<a class="btn btn-xs btn-default" href="#">Partial</a>';
                                                            }
                                                            else if($ens['en_status'] == 1){
                                                              $stat3 = '<a class="btn btn-xs btn-info" href="#">Fullypaid</a>';
                                                            }

                                                            if($ens['tr_id'] != "" && $ens['en_status'] != 2){
                                                                echo '<tr data-toggle="modal" data-target="#'.$ens['en_id'].'">
                                                              <td>'.$ref.'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              <td>'.$ens['tr_fname'].' '.$ens['tr_lname'].'</td>
                                                              <td>'.$stat.'</td>
                                                              <td>'.$stat2.'</td>
                                                              <td>'.$stat3.'</td>
                                                              </tr>';
                                                          }
                                                      }
                                                    }
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
											<button class="btnDownload btn btn-info" id="<?php echo $_GET['id']?>">Download to excel</button>
                      <div id="trainingPrintTable">
                           <!-- INSERT HEADER IMG HERE -->
                                                <div class="center" style="text-align: center;">

                                                <img src="../Bootstrap/img/alumni/bc.jpg" alt="FB" style="width: 100%; height: 35%;"  />
                                                <p>Description1 : </p>
                                                <p>Description2 : </p>
                                                <p>Description3 : </p>
                                                <p>Description4 : </p>
                                                </div>
                                                <!-- END -->                     
                                                 <table class="table table-stripped" id="print-table">

                                                  <thead>
                                                    <tr>
                                                        <th>REFNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>CONTACT</th>
                                                        <th>STATUS</th>
                                                        <th>PAYMENT</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody>
                                                  
                                                    <?php
                                                     $reff="";
                                                    if(count($donesched_student_course) > 0){
                                                        foreach ($donesched_student_course as $ens) {
                                                          if($ens['en_active'] == 1){
                                                           
                                                          
                                                          if($ens['ref_id'] == ""){
                                                           $reff = "WALK-IN";
                                                          }
                                                          else{$reff = $ens['ref_id'];}

                                                        echo '<tr>
                                                              <td>'.$reff.'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              
                                                              <td>'.$stat.'('.$stat2.') </td>
                                                              <td>'.$stat3.'</td>
                                                              </tr>';
                                                        }
                                                      } 
                                                          
                                                    }
                                                    
                                                    ?>
                                                  </tbody>
                                                </table> 
                                              </div>
                                             <a class="btn btn-primary" href="#" id="print" onclick="javascript:printLayer('trainingPrintTable')"><i class="fa fa-print"> Print</i></a>
											
                                        </div>
                                        <div class="tab-pane" id="reserved">
                                            <table class="order-table table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>REFNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>COURSE</th>
                                                        <th>CONTACT</th>
                                                        <th>STATUS</th>
                                                        <th>SETTINGS</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $gen = "";$ref="";$active="";$stat2="";$stat3="";
                                                    if(count($count_reg) > 0){
                                                       
                                                        foreach ($count_reg as $ens) {
                                                        echo "<input type='hidden' id='co_id' value='".$ens['co_id']."'>";
                            
                                                          if($ens['session_id'] != ""){
                                                          if($ens['en_status'] == 1){
                                                            $stat = '<a class="btn btn-xs btn-success" href="#">Enrolled</a>';
                                                          }
                                                          else if($ens['en_status'] == 2){
                                                            $stat = '<a class="btn btn-xs btn-danger" href="#">Drop</a>';
                                                          }
                                                        }
                                                        else{
                                                          if($ens['en_status'] == 0){
                                                            $stat = '<a class="btn btn-xs btn-warning" href="#">Reserved</a>';
                                                          }
                                                          else{
                                                            $stat = '<a class="btn btn-xs btn-primary" href="#">Unschedule</a>';
                                                          }
                                                          
                                                        }
                                                            if($ens['en_status'] == 0){
                                                              
                                                                if($ens['en_gender'] =="M"){
                                                                    $gen="Males";
                                                                }
                                                                else{$gen="Female";}
                                                            if($ens['ref_id'] == NULL){
                                                              $ref = "WALK-IN";
                                                            }else{
                                                              $ref = $ens['ref_id'];
                                                            }
                                                            if($ens['en_active']==0){
                                                              $active = "<button id='".$ens['en_id']."' class='un_active2 btn btn-xs btn-danger'>UNACTIVE</button>";
                                                            }
                                                            else{
                                                              $active = '<span id="active" class="pull-right"><a href="index.php?q=vocational/update-registrant&id='.$ens['en_id'].'" class="fa fa-edit" ></a> <a id="'.$ens['en_id'].'"  class="deletebycourse fa fa-trash" href="#" ></a></span>';
                                                            }
                                                            if($ens['en_stud_voucher_no'] != ""){
                                                              $stat2 = '<a class="btn btn-xs btn-info" href="#">Scholar</a>';
                                                            }
                                                            else{
                                                              $stat2 = '<a class="btn btn-xs btn-default" href="#">Regular</a>';
                                                            }
                                                            
                                                                echo '<tr data-toggle="#" data-target="#'.$ens['en_id'].'">
                                                              <td>'.$ref.'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['co_name'].'</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              <td>'.$stat2.'</td>
                                                              <td>'.$active.'</td>
                                                              </tr>';
                                                          }
                                                        } 
                                                    }
                                                    
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                            <div id="reservedPrintTable">
                                                <!-- INSERT HEADER IMG HERE -->
                                                <div class="center" style="text-align: center;">

                                                <img src="../Bootstrap/img/alumni/bc.jpg" alt="FB" style="width: 100%; height: 35%;"  />
                                                <p>Description1 : </p>
                                                <p>Description2 : </p>
                                                <p>Description3 : </p>
                                                <p>Description4 : </p>
                                                </div>
                                                <!-- END -->
                                                 <table class="table table-stripped" id="print-table">

                                                  <thead>
                                                    <tr>
                                                      <th>TRANSACTION-NO</th><th>NAME</th><th>COURSE</th><th>STATUS</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody>
                                                  
                                                    <?php
                                                     
                                                    if(count($count_reg) > 0){
                                                        foreach ($count_reg as $ens) {
                                                          if($ens['en_active'] == 1){
                                                           
                                                          
                                                          if($ens['ref_id'] == ""){
                                                            echo '<tr>
                                                                <td>WALK-IN</td>
                                                                <td>'.$ens['en_lname'].', '.$ens['en_fname'].'</td>
                                                                <td>'.$ens['co_name'].'</td>
                                                                <td> ______ </td>
                                                                </tr>';
                                                          }
                                                          else{
                                                            echo '<tr>
                                                                <td>'.$ens['ref_id'].'</td>
                                                                <td>'.$ens['en_lname'].', '.$ens['en_fname'].'</td>
                                                                <td>'.$ens['co_name'].'</td>
                                                                <td> ______ </td>
                                                                </tr>';
                                                          }
                                                        }
                                                        } 
                                                          
                                                    }
                                                    
                                                    ?>
                                                  </tbody>
                                                </table> 
                                              </div>
                                             <a class="btn btn-primary" href="#" id="print" onclick="javascript:printLayer('reservedPrintTable')"><i class="fa fa-print"> Print</i></a>
                                        </div>
                                     <div class="tab-pane" id="dropped">

                                            <table class="order-table table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>REFNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>COURSE</th>
                                                        <th>CONTACT</th>
                                                        <th>STATUS</th>
                                                        <th></th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $gen = "";$ref="";$active="";$stat="";$stat2="";$stat3="";
                                                    if(count($count_drop) > 0){
                                                       
                                                        foreach ($count_drop as $ens) {
                                                        echo "<input type='hidden' name='en_id' value='".$ens['en_id']."'>";
                            
                                                          if($ens['session_id'] != ""){
                                                          
                                                        }
                                                       
                                                              echo '<input type="hidden" id="en_id" value="'.$ens['en_id'].'">';
                                                                if($ens['en_gender'] =="M"){
                                                                    $gen="Males";
                                                                }
                                                                else{$gen="Female";}
                                                            if($ens['en_status'] == 1){
                                                            $stat = '<a class="btn btn-xs btn-success" href="#">Enrolled</a>';
                                                          }
                                                          else if($ens['en_status'] == 2){
                                                            $stat = '<a class="btn btn-xs btn-danger" href="#">Drop</a>';
                                                          } 
                                                            if($ens['ref_id'] == NULL){
                                                              $ref = "WALK-IN";
                                                            }else{
                                                              $ref = $ens['ref_id'];
                                                            }
                                                            if($ens['en_active']==0){
                                                              $active = "<button id='un_active' class='btn btn-xs btn-danger'>UNACTIVE</button>";
                                                            }
                                                            else{
                                                              $active = '<span id="active" class="pull-right"><a href="index.php?q=vocational/update-registrant&id='.$ens['en_id'].'" class="fa fa-edit" ></a> <a id="delete"  class="fa fa-trash" href="#" ></a></span>';
                                                            }
                                                            if($ens['en_stud_voucher_no'] != ""){
                                                              $stat2 = '<a class="btn btn-xs btn-info" href="#">Scholar</a>';
                                                            }
                                                            else{
                                                              $stat2 = '<a class="btn btn-xs btn-default" href="#">Regular</a>';
                                                            }
                                                            if($ens['en_status'] == 3){
                                                              $stat3 = '<a class="btn btn-xs btn-default" href="#">Partial</a>';
                                                            }
                                                            else if($ens['en_status'] == 1){
                                                              $stat3 = '<a class="btn btn-xs btn-info" href="#">Fullypaid</a>';
                                                            }
                                                                echo '<tr data-toggle="#" data-target="#'.$ens['en_id'].'">
                                                              <td>'.$ref.'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['co_name'].'</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              
                                                              <td>'.$stat.'</td>
                                                              <td>'.$stat2.'</td>
                                                              <td>'.$stat3.'</td>
                                                              </tr>';
                                                          }
                                                        } 
                                                    
                                                    
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                            
                                            <div id="droppedPrintTable">
                                                <!-- INSERT HEADER IMG HERE -->
                                                <div class="center" style="text-align: center;">

                                                <img src="../Bootstrap/img/alumni/bc.jpg" alt="FB" style="width: 100%; height: 35%;"  />
                                                <p>Description1 : </p>
                                                <p>Description2 : </p>
                                                <p>Description3 : </p>
                                                <p>Description4 : </p>
                                                </div>
                                                <!-- END -->
                                                 <table class="table table-stripped" id="print-table">

                                                  <thead>
                                                    <tr>
                                                      <th>REFNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>COURSE</th>
                                                        <th>CONTACT</th>
                                                        <th>STATUS</th>
                                                        <th>PAYMENT</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody>
                                                  
                                                   <?php
                                                     $reff="";$stat="";$stat2="";$stat3="";
                                                    if(count($drop_stud) > 0){
                                                        foreach ($drop_stud as $ens) {
                                                          if($ens['en_active'] == 1){
                                                           
                                                          
                                                          if($ens['ref_id'] == ""){
                                                           $reff = "WALK-IN";
                                                          }
                                                          else{$reff = $ens['ref_id'];}
                                                          if($ens['en_status'] == 1){
                                                            $stat = '<a class="btn btn-xs btn-success" href="#">Enrolled</a>';
                                                          }
                                                          else if($ens['en_status'] == 2){
                                                            $stat = '<a class="btn btn-xs btn-danger" href="#">Drop</a>';
                                                          }
                                                          if($ens['en_stud_voucher_no'] != ""){
                                                              $stat2 = '<a class="btn btn-xs btn-info" href="#">Scholar</a>';
                                                            }
                                                            else{
                                                              $stat2 = '<a class="btn btn-xs btn-default" href="#">Regular</a>';
                                                            }
                                                            if($ens['en_status'] == 3){
                                                              $stat3 = '<a class="btn btn-xs btn-default" href="#">Partial</a>';
                                                            }
                                                            else if($ens['en_status'] == 1){
                                                              $stat3 = '<a class="btn btn-xs btn-info" href="#">Fullypaid</a>';
                                                            }
                                                        if($ens['en_status'] == 2){

                                                        echo '<tr>
                                                              <td>'.$reff.'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$ens['en_age'].'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['co_name'].'</td>
                                                              <td>'.$ens['en_contact'].'</td>
                                                              
                                                              <td>'.$stat.'('.$stat2.') </td>
                                                              <td>'.$stat3.'</td>
                                                              </tr>';
                                                        }

                                                        }
                                                      } 
                                                          
                                                    }
                                                    
                                                    ?>
                                                  </tbody>
                                                </table> 
                                              </div>
                                             <a class="btn btn-primary" href="#" id="print" onclick="javascript:printLayer('droppedPrintTable')"><i class="fa fa-print"> Print</i></a>
                                        </div>
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>
       <!-- Modal -->
       <?php
         $enrollment = $this->model->GetEnrollmentID();
         $course_scheds = $this->model->GetMonitorScheduleByCourseID($_GET['id']);
         foreach ($enrollment as $en) {
           # code...
            
              
                 echo '<div class="modal fade" id="set_schedule'.$en['en_id'].'" role="dialog">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content" style="width:100%; margin-left: -80px; margin-top: -80px;">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title">SET SCHEDULE</h4>
                </div>
                <div class="modal-body" >
                  <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                   <h4 class="title">Schedule</h4>
                                    
                                </div>
                                <div class="card-content" >
                                    <div class="tab-content">
                                       
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>TRAINER</th>
                                                        <th>TOTAL HOUR</th>
                                                        <th>NO OF STUDENT</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>';
                                                    if(count($course_scheds) > 0){
                                                      foreach ($course_scheds as $cs) {
                                                        $noOfStud = $this->model->CountScheduleEnrolled($cs['tr_id'], $_GET['id']);
                                                        echo '<tr>
                                                            <td>'.$cs['tr_fname'].' '.$cs['tr_lname'].'</td>
                                                            <td>'.$cs['t_hour'].'</td>
                                                            <td>'.count($noOfStud).'</td>
                                                          </tr>';
                                                      }
                                                    }  
                                                echo '</tbody>
                                            </table>
                                            
                                        </div>
                                        
                                </div>
                            </div>
                </div>

                <div class="modal-footer" style="padding:20px">
                <form method="POST">
                <input type="hidden" name="en_id" value="'.$en['en_id'].'" />
                <input type="hidden" name="co_id" value="'.$_GET['id'].'" />
                <div class="col-md-offset-4">
                  <select name="tr_id" class="form-control" required="">
                    <option> Choose Trainer</option>';
                    if(count($course_scheds) > 0){
                      foreach($course_scheds as $sc){
                      echo '<option value="'.$sc['tr_id'].'">'.$sc['tr_fname'].' '.$sc['tr_lname'].'</option>';
                     }
                    }
                    
                  echo '</select>
                  </div>
                  <button type="submit" name="set_schedule_en" class="btn btn-primary">SET</button>
                  </form>

                </div>
              </div>
              
            </div>
          </div>';
              }

            
      
    ?>
        <?php
          if(count($all_student) > 0){
            foreach ($all_student as $e_stud) {
                $student = $this->model->GetEnrolliesByENID(array($e_stud['en_id']));
                 echo '<div class="modal fade" id="'.$e_stud['en_id'].'" role="dialog">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content" style="width:150%; margin-left: -80px; margin-top: -80px;">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title"></h4>
                </div>
                <div class="modal-body" >
                  <div class="row">
                
                <div class="col-sm-12">
                <div class="panel panel-info">
                    <div class="panel-heading">Manpower Profile:</div>
                    <div class="panel-body">
                      <div class="row">
                    <div class="col-sm-3 form-group">
                      <b>First Name : </b><i> '.$student['en_fname'].'</i>
                      
                    </div>
                    <div class="col-sm-3 form-group">
                      <b>Last Name : </b><i> '.$student['en_lname'].'</i>
                    </div>
                    <div class="col-sm-3 form-group">
                      <b>Middle Name : </b><i> '.$student['en_mi'].'</i>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-sm-4 form-group">
                      <b>Number, Street : </b><i> '.$student['en_num_street'].'</i>
                    </div>  
                    <div class="col-sm-4 form-group">
                      <b>Barangay :</b> <i> '.$student['en_barangay'].'</i>
                      
                    </div>  
                    <div class="col-sm-4 form-group">
                      <b>District : </b><i> '.$student['en_district'].'</i>
                      
                    </div>    
                  </div>
                  <div class="row">
                    <div class="col-sm-4 form-group">
                      <b>City/Municipality : </b><i> '.$student['en_city'].'</i>
                    </div>  
                    <div class="col-sm-4 form-group">
                      <b>Province :</b> <i> '.$student['en_province'].'</i>
                      
                    </div>  
                    <div class="col-sm-4 form-group">
                      <b>Nationality : </b><i> '.$student['en_nationality'].'</i>
                      
                    </div>    
                  </div>
                    </div>
                  </div>
                  <div class="panel panel-info">
                    <div class="panel-heading">Personal Information:</div>
                    <div class="panel-body">
                      <div class="row">
                      <div class="col-sm-2 form-group">
                        <b>Sex : </b>'.$student['en_gender'].'
                      </div>  
                      <div class="col-sm-4 form-group">
                        <b>Civil Status : </b>'.$student['en_civilstatus'].'
                      </div>  
                      <div class="col-sm-6 form-group">
                        <b>Employment Status : </b>'.$student['en_empstatus'].'
                        
                      </div>  
                      
                    </div>
                    <div class="row">
                      <div class="col-sm-6 form-group">
                        <b>Birth Date : </b>'.$student['en_bdate'].'
                      </div>
                      <div class="col-sm-6 form-group">
                        <b>Age : </b>'.$student['en_age'].'
                      </div>
                    </div>
                    <div class="form-group">
                     <b>Birth Place : </b> '.$student['en_birthplace'].'
                    </div>
                    <div class="row">
                       <div class="col-sm-6 form-group">
                        <b> Father First Name : </b><i> '.$student['en_father_fname'].'</i>
                        
                      </div>
                      <div class="col-sm-6 form-group">
                        <b> Father Last Name : </b><i> '.$student['en_father_lname'].'</i>
                      </div>
                      
                  </div>
                  <div class="row">
                    <div class="col-sm-6 form-group">
                      <b>Mother First Name : </b><i> '.$student['en_mother_fname'].'</i>
                      
                    </div>
                    <div class="col-sm-6 form-group">
                      <b>Mother Last Name : </b><i> '.$student['en_mother_lname'].'</i>
                    </div>
                  </div>
                  </div>
                  
                  </div>  
                  <div class="panel panel-info">
                    <div class="panel-heading">Educational Attainment Before the Training <i class="small text-muted">(Trainee)</i></div>
                    <div class="panel-body">
                      <div class="row">
                    <div class="col-sm-10 form-group">
                      <b>Educational Attainment: </b>'.$student['en_edattainment'].'
                    </div>  
                    
                  </div>
                    </div>
                  </div>
                  <div class="panel panel-info">
                    <div class="panel-heading">Leaner/Trainee/Student <i class="small text-muted">(Clients) Classification</i></div>
                    <div class="panel-body">
                      <div class="row">
                    <div class="col-sm-6 form-group">
                      <b>Classification : </b>'.$student['en_lts'].'
                    </div>  
                  </div>
                    </div>
                  </div>
                  <div class="panel panel-info">
                    <div class="panel-heading">Taken NCAEIYP4SC Before?</div>
                    <div class="panel-body">
                      <div class="row">
                        <div class="col-sm-6 form-group">
                      <b>Where : </b>'.$student['en_taken_where'].'
                    </div>
                    <div class="col-sm-6 form-group">
                      <b>When : </b>'.$student['en_taken_when'].'
                      
                    </div>
                  </div>
                    </div>
                  </div>
                  <div class="panel panel-info">
                    <div class="panel-heading">Student/Scholar Voucher Number <i class="small text-muted">(For Scholar Only)</i></div>
                    <div class="panel-body">
                      <div class="row">
                        <div class="col-sm-6 form-group">
                      <b>Voucher Number : </b>'.$student['en_stud_voucher_no'].'
                    </div>
                    <div class="col-sm-6 form-group">
                      <b>Scholarship Package : </b>'.$student['en_scholar_package'].'
                      
                    </div>
                  </div>
                    </div>
                  </div>
                  
        
                </div>
              </div>
                </div>

                <div class="modal-footer">
                <a href="#extension'.$e_stud['en_id'].'" data-toggle="modal" class="btn btn-lg btn-info">More info</a>
                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
              </div>
              
            </div>
          </div>';
              }
            }
      
    ?>

    <?php
          if(count($all_student) > 0){
            foreach ($all_student as $e_stud) {
                $student = $this->model->GetEnrolliesByENID(array($e_stud['en_id']));
                 echo '<div class="modal fade" id="extension'.$e_stud['en_id'].'" role="dialog">
            <div class="modal-dialog">
            
              <!-- Modal content-->
              <div class="modal-content" style="width:150%; margin-left: -80px; margin-top: -80px;">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal">&times;</button>
                  <h4 class="modal-title"></h4>
                </div>
                <form method="POST">
                              <input type="hidden" name="user_id" value="'.$student['ref_id'].'">
                              <input type="hidden" name="co_id" value="'.$student['co_id'].'">
                <div class="modal-body" >
                  <div class="row">
                    <div class="col-sm-12">
                      <div class="panel panel-info">
                        <div class="panel-heading">School Information: </div>
                        <div class="panel-body">
                          <div class="row">
                                <div class="col-sm-2 form-group">
                            </div>
                            <div class="col-sm-3 form-group">
                              <input type="text" name="region" placeholder="Region" class="form-control" required="">
                            </div>
                            <div class="col-sm-3 form-group">
                              <input type="text" name="province" placeholder="Province" class="form-control" required="">
                            </div>
                            <div class="col-sm-3 form-group">
                              <input type="text" name="district" placeholder="Congressional District" class="form-control" required="">
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-sm-2 form-group">
                              
                            </div>
                            <div class="col-sm-5 form-group">
                              <input type="text" name="city" placeholder="City" class="form-control" required="">
                            </div>
                            <div class="col-sm-5 form-group">
                              <input type="text" name="provider" placeholder="Name of Provider" class="form-control" required="">
                            </div>
                            
                          </div>

                          <div class="row">
                            <div class="col-sm-2 form-group">
                              
                            </div>
                            <div class="col-sm-10 form-group">
                              <input type="text" name="address" placeholder="Complete Address" class="form-control" required="">
                            </div>
                            
                          </div>

                          <div class="row">
                            <div class="col-sm-2 form-group">
                            </div>
                            <div class="col-sm-3 form-group">
                              <input type="text" name="type_provider" placeholder="Type of Provider" class="form-control" required="">
                            </div>
                            <div class="col-sm-3 form-group">
                              <input type="text" name="classification_provider" placeholder="Classification of Provider" class="form-control" required="">
                            </div>
                            <div class="col-sm-3 form-group">
                              <input type="text" name="industry_sector" placeholder="Industry Sector of Qualification" class="form-control" required="">
                            </div>
                          </div>

                          <div class="row">
                            <div class="col-sm-2 form-group">
                            </div>
                            <div class="col-sm-5 form-group">
                              <input type="text" name="prog_reg_stat" placeholder="Program Registration Status" class="form-control" required="">
                            </div>
                            <div class="col-sm-5 form-group">
                              <input type="text" name="prog_title" placeholder="Qualification/ Program Title" class="form-control" required="">
                            </div>
                            
                          </div>

                          <div class="row">
                            <div class="col-sm-2 form-group">
                            </div>
                            <div class="col-sm-3 form-group">
                              <input type="text" name="ctpr" placeholder="CTPR" class="form-control" required="">
                            </div>
                            <div class="col-sm-3 form-group">
                              <input type="text" name="training_calendar_code" placeholder="Training Calendar Code" class="form-control" required="">
                            </div>
                            <div class="col-sm-3 form-group">
                              <input type="text" name="delivery_mode" placeholder="Delivery Mode" class="form-control" required="">
                            </div>
                          </div>

                        </div>
                        </div>
                        <div class="panel panel-info">
                          <div class="panel-heading">Voucher</div>
                            <div class="panel-body">
                              <div class="row">
                                <div class="col-sm-2 form-group">
                                </div>
                                <div class="col-sm-10 form-group">
                                  <input type="text" name="voucher_no" placeholder="Voucher Number" class="form-control" required="">
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-sm-2 form-group">
                                </div>
                                <div class="col-sm-5 form-group">
                                  <input type="date" name="date_started" placeholder="Date Started" class="form-control" required="">
                                </div>
                                <div class="col-sm-5 form-group">
                                  <input type="date" name="date_finished" placeholder="Date Finished" class="form-control" required="">
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-sm-2 form-group">
                                </div>
                                <div class="col-sm-10 form-group">
                                  <input type="date" name="date_assessed" placeholder="Date Assessed" class="form-control" required="">
                                </div>
                              </div>

                              <div class="row">
                                <div class="col-sm-2 form-group">
                                </div>
                                <div class="col-sm-10 form-group">
                                  <input type="text" name="assessment_result" placeholder="Assessment Result" class="form-control" required="">
                                </div>
                              </div>

                            </div>
                      </div>
                    </div>
                  </div>
                 
        
                </div>
                <div class="modal-footer">
                <button type="submit" name="submit_assessment" class="btn btn-lg btn-info">Submit</button> 

                  <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
                </form>
              </div>
              
            </div>
          </div>';
              }
            }
      
    ?>
    </div>
</div>
 

 
