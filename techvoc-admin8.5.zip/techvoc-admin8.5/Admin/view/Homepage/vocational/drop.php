<div class="content">
    <div class="container-fluid">
        <div class="row">
        	
                        <div class="col-md-12">
                            <div class="card card-nav-tabs">
                                <div class="card-header" data-background-color="purple">
                                   <h4 class="title">DROP/UPDATE</h4>
                                    <!-- <p id="result"></p> -->
                                    <!-- <p class="category">Users (<?php echo count($all_users);?>)</p> -->
                                </div>
                                <div class="card-content">
                                    <div class="tab-content">
                                       
                                            <table class="table" id="enrolled-table">
                                                <thead>
                                                    <tr>
                                                        <th>REFNO</th>
                                                        <th>NAME</th>
                                                        <th>AGE</th>
                                                        <th>GENDER</th>
                                                        <th>ADDRESS</th>
                                                        <th>COURSE</th>
                                                        <th>STATUS</th>
                                                        <th>DROP REMARKS</th>
                                                        <th>DROP DATE</th>
                                                        <th>RETRIEVE REMARKS</th>
                                                        <th>RETRIEVE DATE</th>
                                                    </tr>
                                                </thead>
                                               
                                                <tbody>
                                                    <?php
                                                    $stat="";$ref="";
                                                    if(count($stud_training) > 0){
                                                        
                                                        foreach ($stud_training as $ens) {
                                                            $drop_ret = $this->model->GetDropRetrieveRemarks(array($ens['en_id']));
                                                        	if($ens['en_status'] > 0){
                                                       
                                                                if($ens['en_gender'] =="M"){
                                                                    $gen="Males";
                                                                }
                                                                else{$gen="Female";}
                                                                if($ens['ref_id'] == ""){
                                                                    $ref="WALK-IN";
                                                                }
                                                                else{$ref=$ens['ref_id'];}
                                                                 $dateOfBirth = $ens['en_bdate'];
                                                                $today = date("Y-m-d");
                                                                $diff = date_diff(date_create($dateOfBirth), date_create($today));
                                                                $age = $diff->format('%y');
                                                                if($ens['en_status'] == 2){
                                                                    $stat = '<button data-toggle="modal" data-target="#retrieve'.$ens['en_id'].'" class="btn btn-xs btn-danger">Dropped</button>';
                                                                }
                                                                else if($ens['en_status'] == 1 || $ens['en_status'] == 3){
                                                                    $stat = '<button data-toggle="modal" data-target="#drop'.$ens['en_id'].'" class=" btn btn-xs btn-warning">Drop</button>';
                                                                }
                                                            	echo '<tr>
                                                              <td>'.$ref.'</td>
                                                              <td>'.$ens['en_lname'].', '.$ens['en_fname'].' '.$ens['en_mi'].'</td>
                                                              <td>'.$age.'</td>
                                                              <td>'.$gen.'</td>
                                                              <td>'.$ens['en_num_street'].', '.$ens['en_barangay'].', '.$ens['en_district'].', '.$ens['en_city'].', '.$ens['en_province'].' '.$ens['en_region'].'</td>
                                                              <td>'.$ens['co_name'].'</td>
                                                              <td><a class="btn btn-xs btn-info" href="index.php?q=vocational/update-registrant&id='.$ens['en_id'].'">Update</a> | '.$stat.'</td>
                                                              <td>'.$drop_ret['st_d_remark'].'</td>
                                                              <td>'.$drop_ret['st_d_date'].'</td>
                                                              <td>'.$drop_ret['st_r_remark'].'</td>
                                                              <td>'.$drop_ret['st_r_date'].'</td>
                                                              </tr>';
                                                            }
                                                            
                                                          }
                                                        
                                                    	
                                                    }
                                                    ?>
                                                  
                                                    
                                                </tbody>
                                            </table>
                                            
                                        </div>
                                        
                                </div>
                            </div>
                        </div>
                      
                    </div>
          
        </div>
    </div>
<!-- Modal -->
<?php 
    for($i=0;$i<=$max_en;$i++){
    $drop_count = count($this->model->GetDropCount($i));
        echo '<div id="drop'.$i.'" class="modal fade" role="dialog">
              <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Do you want to  DROP?</h4>
                  </div>
                      <div class="modal-body">
                      <form method="POST">
                      <input type="hidden" name="en_id" value="'.$i.'">
                          <label>Remark: </label><br>
                          <textarea name="remark" style="width: 100%;">
                              
                          </textarea>
                          <button type="submit" name="drop_student" class="btn btn-danger">Drop</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </form>
                    </div>
                </div>

              </div>
            </div>';

            echo '<div id="retrieve'.$i.'" class="modal fade" role="dialog">
              <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Do you want to RETRIEVE?</h4>
                  </div>
                  <form method="POST">
                      <div class="modal-body">
                        <input type="hidden" name="en_id" value="'.$i.'">
                        <label>Remark: </label><br>
                        <textarea name="remark" style="width: 100%;">
                            
                        </textarea>
                      </div>
                      <div class="modal-footer">
                        <button type="submit" name="retrieve_student" class="btn btn-info">Retrieve</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                      </div>
                  </form>
                </div>

              </div>
            </div>';
    }
?>
