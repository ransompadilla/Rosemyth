<?php
	include_once("model/Model.php");
	class Controller{
		public	$model;
		public	function __construct(){		
			$this->model = new Model();
		}
		public function invoke(){
			$this->Search();
			 $this->Delete();
			 $this->Update();
			//  //$this->Retrieve();
			$this->Download();
		    $this->Create();
		    $this->Logout();
		    $this->ValidateLogin();
			 

			
			$this->AUTH();
		}
		
		public function AUTH(){
			if(isset($_GET['auth'])){
				$auth = rtrim($_GET['auth'], '/');
				include 'view/Auth/'.$auth.'.php';
			}
			else if(isset($_GET['q'])){
				$this->Retrieve(); 	
			 }
			 else{
			
				include 'view/Auth/Login.php';
				
			}	
			
		}
		//
		public function ValidateLogin(){
			if(isset($_POST['login_admin'])){
				$email = $_POST['email'];
				$password = $_POST['password'];
				$row = $this->model->ValidateadminLogin(array($email,$password));
				if(count($row) > 1){
                setcookie("admin_id", $row['admin_id'], time() + 86400, "/"); // 86400 = 1 day
                header("Location: index.php?q=Home");
            }
            else{
                header('location: index.php?auth=Authentication');
            }
			}
		}
		public function Logout(){
			if(isset($_GET['logout'])){
				$this->model->admin_Logout();
			}
		}
		//
		public function Create(){
			if(isset($_POST['add_trainer'])){
				
				$fname = $_POST['tr_fname'];
				$lname = $_POST['tr_lname'];
				$gender = $_POST['tr_gender'];
				$age = $_POST['tr_age'];
				$address = $_POST['tr_address'];
				$contact = $_POST['tr_contact'];

					$this->model->AddTrainer(array($fname,$lname,$gender,$age,$contact,$address));
			        setcookie("flag", "ok", time() + 3, "/");
				
					header("Location: index.php?q=vocational/manage/trainer");
			}
			//REGISTER admin
			if(isset($_POST['register_admin'])){
				
				$fname = $_POST['fname'];
				$lname = $_POST['lname'];
				$gender = $_POST['gender'];
				$address = $_POST['address'];
				$contact = $_POST['contact'];
				$email = $_POST['email'];
				$password = $_POST['pword'];

				if($this->model->CheckEmail(array($email)) == NULL){
					$this->model->Registeradmin(array($fname,$lname,$gender,$address,$contact, $email, $password));
			        setcookie("flag", "ok", time() + 3, "/");
				}
				else{
					setcookie("flag", "used", time() + 3, "/");
				}
					header("Location: index.php?auth=Register");
			}
			if(isset($_POST['open_session'])){
				$course = $_POST['course'];
				$start_date = $_POST['start_date'];
				$end_date = $_POST['end_date'];
				$check_session = $this->model->CheckSession(array($course,1));
				if($check_session == "false"){
					$this->model->OpenSession(array($course, $start_date, $end_date, 1));
					header("Location: index.php?q=Home");
				}
				else{
					echo '<script>alert("You wish to open new Session ? please close the existing session. thanks")</script>';
				}	
				
			}
			if(isset($_POST['submit_assessment'])){
				$co_id = $_POST['co_id'];
				$user_id = $_POST['user_id'];
				$region = $_POST['region'];
				$province = $_POST['province'];
				$district = $_POST['district'];
				$city = $_POST['city'];
				$provider = $_POST['provider'];
				$address = $_POST['address'];
				$type_provider = $_POST['type_provider'];

				$classification_provider = $_POST['classification_provider'];
				$industry_sector = $_POST['industry_sector'];
				$prog_reg_stat = $_POST['prog_reg_stat'];
				$prog_title = $_POST['prog_title'];
				$ctpr = $_POST['ctpr'];
				$training_calendar_code = $_POST['training_calendar_code'];

				$delivery_mode = $_POST['delivery_mode'];
				$voucher_no = $_POST['voucher_no'];
				$date_started = $_POST['date_started'];
				$date_finished = $_POST['date_finished'];
				$date_assessed = $_POST['date_assessed'];
				$assessment_result = $_POST['assessment_result'];

				$this->model->RegisterAssessment(array($region,
            $province,
            $district,
            $city,
            $provider,
            $address,
            $type_provider,
            $classification_provider,
            $industry_sector,
            $prog_reg_stat,
            $prog_title,
            $ctpr,
            $training_calendar_code,
            $delivery_mode,
            $voucher_no,
            $date_started,
            $date_finished,
            $date_assessed,
            $assessment_result,
            $user_id));
				header('Location: index.php?q=vocational/course&id='.$co_id.'');
			}
			if(isset($_POST['close_session'])){
				$course = $_POST['course'];
				$this->model->CloseSession(array($course));
				header("Location: index.php?q=vocational/manage/schedules");
			}

			//ENROLL STUDENT
			if(isset($_POST['enroll_student'])){
				date_default_timezone_set('Asia/Manila');

				$fname = $_POST['fname'];
				$lname = $_POST['lname'];
				$mi = $_POST['mi'];

				$num_street = $_POST['num-street'];
				$barangay = $_POST['barangay'];
				$district = $_POST['district'];
				$city = $_POST['city'];
				$province = $_POST['province'];
				$region = $_POST['region'];

				$email_add = $_POST['emailAdd'];
				$contact = $_POST['contact'];
				$nationality = $_POST['nationality'];


				$gender = $_POST['gender'];
				$civilstatus = $_POST['civilstatus'];
				$empstatus = $_POST['empstatus'];

				$bdate = $_POST['bdate'];
				$age = $_POST['age'];
				$place_birth = $_POST['place_birth'];

				$fa_fname = $_POST['fa_fname'];
				$fa_lname = $_POST['fa_lname'];

				$mo_fname = $_POST['mo_fname'];
				$mo_lname = $_POST['mo_lname'];

				$edattain = $_POST['edattain'];

				$lts = $_POST['lts'];

				$taken_where = $_POST['taken_where'];
				$taken_when = $_POST['taken_when'];

				$course = $_POST['course'];

				$voucher_number = $_POST['voucher_number'];
				$scholar_package = $_POST['scholar_package'];


					$this->model->EnrollStudent(array($fname,
						$lname,
						$mi,
						$num_street,
						$barangay,
						$district,
						$city,
						$province,
						$region,
						$email_add,
						$contact,
						$nationality,
						$gender,
						$civilstatus,
						$empstatus,
						$bdate,
						$age,
						$place_birth,
						$fa_fname,
						$fa_lname,
						$mo_fname,
						$mo_lname,
						$edattain,
						$lts,
						$taken_where,
						$taken_when,
						$voucher_number,
						$scholar_package, 
						 $course,
						 0,1));
			        setcookie("flag", "ok", time() + 3, "/");
				
					header("Location: index.php?q=vocational/add_registrant");
			}
			if(isset($_POST['add_schedule'])){
				$session_id = $_POST['session_id'];
				$co_id = $_POST['co_id'];
				$week_day_start = $_POST['week_day_start'];
				$week_day_end = $_POST['week_day_end'];
				$start_hour = $_POST['start_hour'];
				$end_hour = $_POST['end_hour'];
				$stud_limit = $_POST['stud_limit'];
			
				$this->model->AddSchedule(array($week_day_start, $week_day_end, $start_hour, $end_hour, $session_id, $co_id,$stud_limit));
					setcookie("flag", "ok", time() + 3, "/");
				header("location: index.php?q=vocational/manage/schedules&id=".$co_id."");
				
			}
			if(isset($_POST['upload_activities'])){
				$act_title = $_POST['act_title'];
				$act_desc = $_POST['act_desc'];
				$co_id = $_POST['co_id'];
				
				$target_dir = "../Bootstrap/img/activities/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        $uploadOk = 1;
				    } else {
				    	$msg = "a";
				    	$uploadOk = 0;
				        
				        
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
					$msg = "b";
					$uploadOk = 0;
				       
				}
				// Check file size
				if ($_FILES["fileToUpload"]["size"] > 100000000) {
					$msg = "c";
					$uploadOk = 0;
				        
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
					$msg = "d";
				$uploadOk = 0;
				       
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
					$msg = "e";
				       
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				        $uploadOk = 1;
				    } else {
				    	$msg = "f";
				    	$uploadOk = 0;
				        
				    }
				}
					$this->model->AddActivities(array($act_title,$act_desc,$target_file,$co_id));
					header("location: index.php?q=vocational/manage/activities");
				
			}
			
			// add course
				if(isset($_POST['add_course'])){
				$co_limit = $_POST['co_limit'];
				$co_name = $_POST['co_name'];
				$co_desc = $_POST['co_desc'];
				
				$target_dir = "../Bootstrap/img/course/";
				$target_file = $target_dir . basename($_FILES["course_img"]["name"]);
				$uploadOk = 1;
				$msg = "";
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["course_img"]["tmp_name"]);
				    if($check !== false) {
				        $uploadOk = 1;
				    } else {
				    	$msg = "a";
				    	$uploadOk = 0;
				        setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses");
				        
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
					$msg = "b";
					$uploadOk = 0;
				     setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses");  
				}
				// Check file size
				if ($_FILES["course_img"]["size"] > 10000000) {
					$msg = "c";
					$uploadOk = 0;
				    setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses"); 
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
					$msg = "d";
					$uploadOk = 0;
				     setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses"); 
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
					$msg = "e";
				    setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses");   
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["course_img"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["course_img"]["name"]). " has been uploaded.";
				        $uploadOk = 1;
				    } else {
				    	$msg = "f";
				    	$uploadOk = 0;
				        setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses");
				    }
				}

					$this->model->AddCourse(array($co_name,$co_desc,$co_limit,$target_file));
				    setcookie("flag", "ok", time() + 3, "/");
					header("location: index.php?q=vocational/manage/courses");
				
			}
			if(isset($_POST['drop_student'])){
				date_default_timezone_set('Asia/Manila');
				$date = Date("y-m-d h:i:sa");
				$remark = $_POST['remark'];
				$en_id = $_POST['en_id'];
					$this->model->DropStudent(array($en_id));
					$this->model->AddToDrop(array($remark, $date, $en_id));
					header("Location: index.php?q=vocational/drop");
				
				
			}
			if(isset($_POST['retrieve_student'])){
				date_default_timezone_set('Asia/Manila');
				$date = Date("y-m-d h:i:sa");
				$remark = $_POST['remark'];
				$en_id = $_POST['en_id'];
					$this->model->RetrieveDropStudent(array($en_id));
					$this->model->RetrieveStudent(array($remark, $date, $en_id));
					header("Location: index.php?q=vocational/drop");
				
				
			}
			if(isset($_POST['add_trainor_course'])){

				date_default_timezone_set('Asia/Manila');
				$date = Date("y-m-d h:i:sa");
				$tr_id = $_POST['tr_id'];
				$co_id = $_POST['co_id'];
				$hr_limit = $_POST['hr_limit'];
				$checked = $this->model->CheckTrainorCourse(array($tr_id, $co_id));
				if($checked == 0){
					setcookie("flag", "tr_ok", time() + 3, "/");
					$this->model->AddTrainorCourse(array($tr_id, $co_id, $hr_limit, $date));
					header("Location: index.php?q=vocational/manage/courses");
				}
				else{
					setcookie("flag", "tr_notok", time() + 3, "/");
					header("Location: index.php?q=vocational/manage/courses");
				}
				
			}
			if(isset($_POST['trainor_sched'])){

				date_default_timezone_set('Asia/Manila');
				$date = Date("y-m-d h:i:sa");
				$tr_id = $_POST['tr_id'];
				$co_id = $_POST['co_id'];
				$star_time = $_POST['start_time'];
				$end_time = $_POST['end_time'];
					if($star_time < 12){
						$s_time = $star_time." AM";
					}
					else{
					   	$s_time = $star_time." PM";
					}
					if($end_time < 12){
					  	$e_time = $end_time." AM";
					}
					else{
					  	$e_time = $end_time." PM";
					}
					$hour = ($e_time - $s_time) ;	
				$day = $_POST['day'];
					setcookie("flag", "tr_ok", time() + 3, "/");
					$this->model->AddTrainorSchedule(array($day, $star_time, $end_time, $hour, $tr_id, $co_id, $date));
					header("Location: index.php?q=vocational/manage/schedules");
				
			}
			if(isset($_POST['start_session'])){

				$co_id = $_POST['co_id'];
				$start_time = $_POST['start_time'];

					setcookie("flag", "ses_ok", time() + 3, "/");
					$this->model->AddSession(array($start_time, $co_id, 1));
					header("Location: index.php?q=vocational/manage/schedules");
				
			}
		}
		
		public function Retrieve(){
				if(isset($_COOKIE['admin_id'])){
				date_default_timezone_set('Asia/Manila');
				$date = Date("m/j/Y");
				 $std1 = strtotime($date);
    //               $date1 = Date("F j, Y",$d);

    //               $date2 = Date("y-m-d",$d);
			        $admin_id=$_COOKIE['admin_id'];
			         $name = $this->model->getadminNameByID(array($admin_id));
			        // $img = $this->model->getadminImgByID(array($admin_id));
			         $adminInfo = $this->model->getadminInformation(array($admin_id));
			         $v_courses = $this->model->GetVocationalCourses();
			         $announcement = $this->model->GetAnnouncement();
			         $registrants = $this->model->GetStudentWantTOEnroll();
			         $enrolled_student = $this->model->GetStudentEnrolled();
			         $studentDropped = $this->model->GetStudentDropped();
			         $studentDroppedCount = $this->model->GetStudentDroppedCount();
			         $all_student = $this->model->GetAllStudentEnrollies();
			         $count_user = $this->model->CountUser();
			         $all_users = $this->model->GetAllUsers();
			         $assessment = $this->model->GetAssessment();
			         $schedule = $this->model->GetSchedule();
			         $maxSchedID = $this->model->GetMaxScheduleID();
			         $maxEN = $this->model->GetMaxEnrollmentID();
			         $act = $this->model->GetAllActivities();
			         $stud_training = $this->model->GetStudentTraining();
			         $trainor = $this->model->GetTrainors();
			         $courseWithTrainor = $this->model->GetCourseWithTrainor();
			         $sched_details = $this->model->GetScheduleDetails();
			         $monitor_sched = $this->model->GetMonitorSchedule();
			         $count_drop = $this->model->GetDropCountAll();
			         $reg_payment = $this->model->GetRegistrantPayment();
			         $detail_sched = $this->model->GetMonitorScheduleDetails();
			         $tr_sched = $this->model->GetTrainorSchedule();
			         $max_en = "";
			         $maxSched="";
			         foreach ($maxSchedID as $val) {$maxSched = $val['maxSchedID'];}
			         foreach ($maxEN as $v) {$max_en = $v['max_en'];}
			         $flag="";
			         if(isset($_COOKIE['flag'])){
			         	$flag = $_COOKIE['flag'];
			         }
			        if(isset($_GET['q'])){
			        	
			        	$homepage = null;
							$flag = rtrim($_GET['q'], '/');
							$page = array("Home","profile/profile", "profile/ChangeProfile", "profile/ChangePassword", "vocational/courses","vocational/course","vocational/enrollment","vocational/enrollies", "vocational/payment", "vocational/assessment", "vocational/users", "vocational/drop", "vocational/excel","vocational/add_registrant","vocational/registrant-by-admin","vocational/update-registrant","vocational/manage/schedules","vocational/manage/activities","vocational/manage/courses", "vocational/manage/trainer");
							for($i=0;$i<count($page);$i++){
								if($flag == $page[$i]){
									$homepage = $flag;
									if($homepage == "Vocational/Enrollment"){
										include 'view/Homepage/'.$homepage.'.php';
									}
									else{
										include 'view/Homepage/adminHeader.php';
										include 'view/Homepage/'.$homepage.'.php';
										include 'view/Homepage/adminFooter.php';
									}
										
									
								}
								else $homepage = $homepage;
						}
					 		
			 		
						 		
					}
					
				}
			
		    else{
		      header('location: index.php');
		    }				

		}
		public function Update(){
			if(isset($_POST['update_trainer'])){
				$tr_id = $_POST['tr_id'];
				$fname = $_POST['tr_fname'];
				$lname = $_POST['tr_lname'];
				$gender = $_POST['tr_gender'];
				$age = $_POST['tr_age'];
				$address = $_POST['tr_address'];
				$contact = $_POST['tr_contact'];

					$this->model->UpdateTrainer(array($fname,$lname,$gender,$age,$contact,$address,$tr_id));
			        setcookie("flag", "ok", time() + 3, "/");
				
					header("Location: index.php?q=vocational/manage/trainer");
			}
			if(isset($_GET['payment'])){
				$en_id = $_GET['payment'];
				$this->model->UpdatePaymentStatus(array($en_id));
				
				header('Location: index.php?q=vocational/payment');

			}
			if(isset($_GET['drop'])){
				$en_id = $_GET['drop'];
				$this->model->DropStudent(array($en_id));
				
				header('Location: index.php?q=vocational/drop');

			}
			//
			if(isset($_POST['update_admin'])){
				$admin_id = $_POST['admin_id'];
				$admin_fname = $_POST['fname'];
				$admin_lname = $_POST['lname'];
				$address = $_POST['address'];
				$gender = $_POST['gender'];
				$contact = $_POST['contact'];

				$folder = "../Bootstrap/file/";
				$temp = explode(".", $_FILES["uploaded"]["name"]);
				$newfilename = round(microtime(true)).'.'. end($temp);
				$db_path ="$folder".$newfilename  ;
				$listtype = array(
				'.doc'=>'application/msword',
				'.docx'=>'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
				'.rtf'=>'application/rtf',
				'.pdf'=>'application/pdf'); 
				if ( is_uploaded_file( $_FILES['uploaded']['tmp_name'] ) ){
					if($key = array_search($_FILES['uploaded']['type'],$listtype)){
						if (move_uploaded_file($_FILES['uploaded']  ['tmp_name'],"$folder".$newfilename)){
						echo "The file ". basename( $_FILES["uploaded"]["name"]). " has been uploaded.";
						}
					}
					else {
					echo "File Type Should Be .Docx or .Pdf or .Rtf Or .Doc";
					}
				}
				$target_dir = "../Bootstrap/img/";
				$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
				$uploadOk = 1;
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
				    if($check !== false) {
				        echo "File is an image - " . $check["mime"] . ".";
				        $uploadOk = 1;
				    } else {
				        echo "File is not an image.";
				        $uploadOk = 0;
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
				    echo "Sorry, file already exists.";
				    $uploadOk = 0;
				}
				// Check file size
				if ($_FILES["fileToUpload"]["size"] > 100000000) {
				    echo "Sorry, your file is too large.";
				    $uploadOk = 0;
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
				    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
				    $uploadOk = 0;
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
				    echo "Sorry, your file was not uploaded.";
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
				    } else {
				        echo "Sorry, there was an error uploading your file.";
				    }
				}
					$this->model->UpdateadminInfo(array($admin_fname,$admin_lname, $address, $gender,$contact, $target_file, $admin_id));
			        setcookie("flag", "1", time() + 5, "/");
					header("Location: index.php?q=profile/profile");
				
				
			}
			//Change Email
			if(isset($_POST['change_admin_email'])){
		    $admin_id = $_POST['admin_id'];
			$email = $_POST['email'];
			$password = $_POST['password'];
			$c_password = $_POST['current_password'];
		    $data = array($email,$admin_id);
		    $check_email = $this->model->CheckadminEmail(array($email));
		    $check_pass = $this->model->CheckadminPassword(array($c_password, $admin_id));
	        //setcookie("emp_email", $email, time() + 86400, "/");
	        if($check_email == NULL && $check_pass == "Checked"){
				$this->model->ChangeadminEmail($data);
				setcookie("update", "ok", time() + 5, "/");
		        setcookie("emp_email", $email, time() + 86400, "/");
				header('Location: index.php?homepage=Profile&next=1');
			}
			else{
				setcookie("update", "used", time() + 5, "/");
				header('Location: index.php?homepage=Profile&next=1');
			}
		}
		//ChangePassword
		if(isset($_POST['change_admin_password'])){
		    $admin_id = $_POST['admin_id'];
			$password = $_POST['password'];
			$c_password = $_POST['current_password'];
		    $found = $this->model->CheckadminPassword(array($c_password, $admin_id));
			if($found){
				$data = array($password,$admin_id);
	        	$this->model->ChangeadminPassword($data);
				setcookie("update", "ok", time() + 5, "/");
				header('Location: index.php?homepage=Profile/Profile');
			
			}
			else {

				setcookie("update", "notok", time() + 5, "/");
				header('Location: index.php?homepage=Profile/ChangePassword');
			}
		    
		}
		if(isset($_POST['set_schedule_en'])){
			
			$co_id = $_POST['co_id'];
			$en_id = $_POST['en_id'];
			$tr_id = $_POST['tr_id'];
			if($tr_id != ""){
				
				$this->model->SetSessionSched(array($tr_id, $en_id));
				header('Location: index.php?q=vocational/course&id='.$co_id.'');
			}
			else{
				echo "<script>alert('No Open Session');</script>";
				header('Location: index.php?q=vocational/course&id='.$co_id.'');
			}

		}
		if(isset($_POST['update_schedule'])){
				$co_id = $_POST['co_id'];
				$sched_id = $_POST['sched_id'];
				$week_day_start = $_POST['week_day_start'];
				$week_day_end = $_POST['week_day_end'];
				$start_hour = $_POST['start_hour'];
				$end_hour = $_POST['end_hour'];
				$limit = $_POST['stud_limit'];

				$this->model->UpdateSchedule(array($week_day_start,$week_day_end,$start_hour,$end_hour,$co_id,$limit, $sched_id));
				header("LOCATION: index.php?q=vocational/manage/schedules");
		}
		if(isset($_GET['activate_registrant'])){
				$en_id = $_GET['activate_registrant'];
				$this->model->ActivateRegistrant(array($en_id));
				header('Location: index.php?q=vocational/enrollies');
		}
		if(isset($_GET['activate_registrant_bycourse'])){
				$co_id = $_GET['co_id'];
				$en_id = $_GET['activate_registrant_bycourse'];
				$this->model->ActivateRegistrant(array($en_id));
				header('Location: index.php?q=vocational/course&id='.$co_id.'');
		}
		if(isset($_POST['update_registrant'])){
				date_default_timezone_set('Asia/Manila');
				$en_id = $_POST['en_id'];

				$fname = $_POST['fname'];
				$lname = $_POST['lname'];
				$mi = $_POST['mi'];

				$num_street = $_POST['num-street'];
				$barangay = $_POST['barangay'];
				$district = $_POST['district'];
				$city = $_POST['city'];
				$province = $_POST['province'];
				$region = $_POST['region'];

				$email_add = $_POST['emailAdd'];
				$contact = $_POST['contact'];
				$nationality = $_POST['nationality'];


				$gender = $_POST['gender'];
				$civilstatus = $_POST['civilstatus'];
				$empstatus = $_POST['empstatus'];

				$bdate = $_POST['bdate'];
				$age = $_POST['age'];
				$place_birth = $_POST['place_birth'];

				$fa_fname = $_POST['fa_fname'];
				$fa_lname = $_POST['fa_lname'];

				$mo_fname = $_POST['mo_fname'];
				$mo_lname = $_POST['mo_lname'];

				$edattain = $_POST['edattain'];

				$lts = $_POST['lts'];

				$taken_where = $_POST['taken_where'];
				$taken_when = $_POST['taken_when'];

				$course = $_POST['course'];

				$voucher_number = $_POST['voucher_number'];
				$scholar_package = $_POST['scholar_package'];


					$this->model->UpdateRegistrant(array($fname,
						$lname,
						$mi,
						$num_street,
						$barangay,
						$district,
						$city,
						$province,
						$region,
						$email_add,
						$contact,
						$nationality,
						$gender,
						$civilstatus,
						$empstatus,
						$bdate,
						$age,
						$place_birth,
						$fa_fname,
						$fa_lname,
						$mo_fname,
						$mo_lname,
						$edattain,
						$lts,
						$taken_where,
						$taken_when,
						$voucher_number,
						$scholar_package, 
						 $course,$en_id
						));
			        setcookie("flag", "ok", time() + 3, "/");
			
				header('Location: index.php?q=vocational/update-registrant&id='.$en_id.'');
		}
			if(isset($_POST['partial'])){
				$en_id = $_POST['en_id'];
				$this->model->UpdatePaymentPartial(array($en_id));
			}
			if(isset($_POST['fullypaid'])){
				$en_id = $_POST['en_id'];
				$this->model->UpdatePaymentFullypaid(array($en_id));
				
			}
			if(isset($_POST['update_course'])){

				$co_limit = $_POST['co_limit'];
				$co_id = $_POST['co_id'];
				$co_name = $_POST['co_name'];
				$co_desc = $_POST['co_desc'];
				
				$target_dir = "../Bootstrap/img/course/";
				$target_file = $target_dir . basename($_FILES["course_img"]["name"]);
				$uploadOk = 1;
				$msg = "";
				$imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
				// Check if image file is a actual image or fake image
				//if(isset($_POST["submit"])) {
				    $check = getimagesize($_FILES["course_img"]["tmp_name"]);
				    if($check !== false) {
				        $uploadOk = 1;
				    } else {
				    	$msg = "a";
				    	$uploadOk = 0;
				        setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses");
				        
				    }
				//}
				// Check if file already exists
				if (file_exists($target_file)) {
					$msg = "b";
					$uploadOk = 0;
				     setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses");  
				}
				// Check file size
				if ($_FILES["course_img"]["size"] > 1000000000) {
					$msg = "c";
					$uploadOk = 0;
				    setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses"); 
				}
				// Allow certain file formats
				if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
				&& $imageFileType != "gif" ) {
					$msg = "d";
					$uploadOk = 0;
				     setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses"); 
				}
				// Check if $uploadOk is set to 0 by an error
				if ($uploadOk == 0) {
					$msg = "e";
				    setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses");   
				// if everything is ok, try to upload file
				} else {
				    if (move_uploaded_file($_FILES["course_img"]["tmp_name"], $target_file)) {
				        echo "The file ". basename( $_FILES["course_img"]["name"]). " has been uploaded.";
				        $uploadOk = 1;
				    } else {
				    	$msg = "f";
				    	$uploadOk = 0;
				        setcookie("flag", $msg, time() + 3, "/");
						header("Location: index.php?q=vocational/manage/courses");
				    }
				}

					$this->model->UpdateCourse(array($co_name,$co_desc,$co_limit,$target_file, $co_id));
				   
						header("Location: index.php?q=vocational/manage/courses");
				
			}

			if(isset($_POST['update_trainor_sched'])){

				date_default_timezone_set('Asia/Manila');
				$date = Date("y-m-d h:i:sa");
				$tr_sched = $_POST['tr_sched'];
				$tr_id = $_POST['tr_id'];
				$co_id = $_POST['co_id'];
				$star_time = $_POST['start_time'];
				$end_time = $_POST['end_time'];
					if($star_time < 12){
						$s_time = $star_time." AM";
					}
					else{
					   	$s_time = $star_time." PM";
					}
					if($end_time < 12){
					  	$e_time = $end_time." AM";
					}
					else{
					  	$e_time = $end_time." PM";
					}
					$hour = ($e_time - $s_time) ;	
				$day = $_POST['day'];
					
					$this->model->UpdateTrainorSchedule(array($day, $star_time, $end_time, $hour, $tr_id, $co_id, $date, $tr_sched));
					header("Location: index.php?q=vocational/manage/schedules");
				
			}
			if(isset($_GET['activate_trainer'])){
				$tr_id = $_GET['activate_trainer'];
				$this->model->ActivateTrainer(array($tr_id));
				header('Location: index.php?q=vocational/manage/trainer');
			}
		}
		public function Delete(){
			if(isset($_GET['delete_registrant'])){
				$en_id = $_GET['delete_registrant'];
				$this->model->DeleteRegistrant(array($en_id));
				header('Location: index.php?q=vocational/enrollies');
			}
			if(isset($_GET['delete_registrant_bycourse'])){
				$co_id = $_GET['co_id'];
				$en_id = $_GET['delete_registrant_bycourse'];
				$this->model->DeleteRegistrant(array($en_id));
				header('Location: index.php?q=vocational/course&id='.$co_id.'');
			}
			if(isset($_GET['delete_sched'])){
				$sched_id = $_GET['delete_sched'];
				$this->model->DeleteSchedule(array($sched_id));
				header('Location: index.php?q=vocational/manage/schedules');
			}
			if(isset($_GET['delete_course'])){
				$co_id = $_GET['delete_course'];
				$this->model->DeleteCourse(array($co_id));
				header('Location: index.php?q=vocational/manage/courses');
			}
			if(isset($_GET['delete_trainer'])){
				$tr_id = $_GET['delete_trainer'];
				$this->model->DeleteTrainer(array($tr_id));
				header('Location: index.php?q=vocational/manage/trainer');
			}
		}
		public function Download(){
			if(isset($_POST['download-excel'])){
				$co_id = $_POST['co_id'];
				header("location: index.php?q=vocational/excel&id=".$co_id."");
			}
		}
		public function Search(){
			
		}
	}
?>